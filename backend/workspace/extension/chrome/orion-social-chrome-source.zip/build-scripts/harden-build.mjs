import { readFile, rm, writeFile } from 'node:fs/promises';
import { transform } from 'esbuild';

const bundlePath = new URL('../build/main.js', import.meta.url);
const prerenderRoutesPath = new URL('../build/prerendered-routes.json', import.meta.url);
const source = String(await readFile(bundlePath, 'utf8'));
const result = await transform(source, {
  charset: 'utf8',
  drop: ['console', 'debugger'],
  format: 'esm',
  legalComments: 'none',
  minify: true,
  sourcefile: 'main.js',
  sourcemap: false,
  target: 'es2022',
  treeShaking: true
});

const forbiddenOutput = [
  [/\bdebugger\b/, 'debugger statement'],
  [/\beval\s*\(/, 'eval()'],
  [/new\s+Function\s*\(/, 'new Function()'],
  [/sourceMappingURL/, 'source map reference'],
  [/http:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?/i, 'insecure local HTTP endpoint']
];

for (const [pattern, description] of forbiddenOutput) {
  if (pattern.test(result.code)) {
    throw new Error(`Production hardening failed: ${description} found in main.js`);
  }
}

if (!result.code.includes('orion-url')) {
  throw new Error('Production hardening failed: saved Orion URL support is missing');
}

await writeFile(bundlePath, result.code, { mode: 0o644 });
await rm(prerenderRoutesPath, { force: true });

const savedBytes = Buffer.byteLength(source) - Buffer.byteLength(result.code);
console.log(`Production bundle hardened (${savedBytes} bytes removed)`);
