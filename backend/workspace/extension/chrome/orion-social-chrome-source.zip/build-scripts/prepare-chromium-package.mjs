import { createHash, createPublicKey } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const GOOGLE_UPDATE_NAMESPACE = ['http:', '', 'www.google.com/update2/response'].join('/');

const [
  sourceDirectory,
  signingKeyFile,
  updateUrlValue,
  crxUrlValue,
  updatesFile
] = process.argv.slice(2);

if (!sourceDirectory || !signingKeyFile) {
  throw new Error(
    'Usage: node prepare-chromium-package.mjs '
    + '<source-directory> <signing-key> [<update-url> <crx-url> <updates-file>]'
  );
}

const updateArguments = [updateUrlValue, crxUrlValue, updatesFile];
const shouldGenerateUpdates = updateArguments.every(Boolean);

if (!shouldGenerateUpdates && updateArguments.some(Boolean)) {
  throw new Error('Chromium update URL, CRX URL, and updates file must be provided together');
}

function validateHttpUrl(value, label) {
  let parsed;

  try {
    parsed = new URL(value);
  }
  catch {
    throw new Error(`${label} must be an absolute HTTP(S) URL: ${value}`);
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error(`${label} must use HTTP or HTTPS: ${value}`);
  }

  if (parsed.username || parsed.password || parsed.hash) {
    throw new Error(`${label} cannot contain credentials or a fragment: ${value}`);
  }

  return parsed.href;
}

function xmlAttribute(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function extensionId(publicKeyBase64) {
  const digest = createHash('sha256').update(publicKeyBase64, 'base64').digest('hex').slice(0, 32);
  return [...digest]
    .map(character => String.fromCharCode('a'.charCodeAt(0) + Number.parseInt(character, 16)))
    .join('');
}

const sourcePath = resolve(sourceDirectory);
const manifestPath = resolve(sourcePath, 'manifest.json');
const updateUrl = shouldGenerateUpdates
  ? validateHttpUrl(updateUrlValue, 'Chromium update URL')
  : undefined;
const crxUrl = shouldGenerateUpdates
  ? validateHttpUrl(crxUrlValue, 'Chromium CRX URL')
  : undefined;
const privateKey = String(readFileSync(resolve(signingKeyFile), 'utf8'));
const publicKeyPem = String(createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }));
const publicKeyBase64 = publicKeyPem.replace(/-----BEGIN PUBLIC KEY-----|-----END PUBLIC KEY-----|\s/g, '');
const id = extensionId(publicKeyBase64);
const manifest = JSON.parse(String(readFileSync(manifestPath, 'utf8')));

if (typeof manifest.version !== 'string' || !/^\d+(?:\.\d+){0,3}$/.test(manifest.version)) {
  throw new Error(`Invalid Chromium extension version: ${String(manifest.version)}`);
}

manifest.key = publicKeyBase64;
if (shouldGenerateUpdates) {
  manifest.update_url = updateUrl;
}
else {
  delete manifest.update_url;
}
writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o644 });

if (shouldGenerateUpdates) {
  const updatesXml = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<gupdate xmlns="${GOOGLE_UPDATE_NAMESPACE}" protocol="2.0">`,
    `  <app appid="${id}">`,
    `    <updatecheck codebase="${xmlAttribute(crxUrl)}" version="${xmlAttribute(manifest.version)}" />`,
    '  </app>',
    '</gupdate>',
    ''
  ].join('\n');

  writeFileSync(resolve(updatesFile), updatesXml, { mode: 0o644 });
}
process.stdout.write(id);
