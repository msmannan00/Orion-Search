import { inject, Injectable } from '@angular/core';
import { ExtensionManager } from './extension.manager';
import { ExtensionCommand, ExtensionResult } from './model/extension.model';
import { CrawlEntry, RuntimeApi } from './model/activity.model';

interface ActivityStorage {
  get(keys: string): Promise<Record<string, unknown>>;
  set(items: Record<string, unknown>): Promise<void>;
}

const INVOKE_TIMEOUT_MS = 80_000;

@Injectable({ providedIn: 'root' })
export class ExtensionRoute {
  private readonly manager = inject(ExtensionManager);

  #activityWrite: Promise<void> = Promise.resolve();

  async handle(message: string): Promise<ExtensionResult | null> {
    let command: ExtensionCommand | null = null;

    try {
      command = JSON.parse(message) as ExtensionCommand;
    }
    catch {
      return null;
    }

    if (!command?.command) {
      return null;
    }

    const startedAt = Date.now();
    const platform = command.platform ?? '';
    const url = command.url ?? '';
    const id = command.request_id ?? `${platform}|${url}|${startedAt}`;
    this.#recordActivity({ id, platform, url, status: 'crawling', startedAt, finishedAt: null });

    const result = await this.#invoke(command);

    const status = result.error ? 'failed' : result.items.length > 0 ? 'done' : 'empty';
    this.#recordActivity({ id, platform, url, status, startedAt, finishedAt: Date.now() });

    return { ...result, request_id: command.request_id };
  }

  async #invoke(command: ExtensionCommand): Promise<ExtensionResult> {
    let timer: ReturnType<typeof setTimeout> | null = null;
    const guard = new Promise<ExtensionResult>((resolve) => {
      timer = setTimeout(() => resolve({
        platform: command.platform ?? '',
        type: command.type ?? '',
        implemented: false,
        items: [],
        error: 'crawl_timeout'
      }), INVOKE_TIMEOUT_MS);
    });

    try {
      return await Promise.race([this.manager.invoke(command), guard]);
    }
    catch (error) {
      return { platform: command.platform ?? '', type: command.type ?? '', implemented: false, items: [], error: String((error as Error)?.message ?? error) };
    }
    finally {
      if (timer) {
        clearTimeout(timer);
      }
    }
  }

  #recordActivity(entry: CrawlEntry): void {
    const scope = globalThis as unknown as {
      chrome?: { storage?: { local?: ActivityStorage }; runtime?: RuntimeApi['runtime'] };
      browser?: { storage?: { local?: ActivityStorage }; runtime?: RuntimeApi['runtime'] };
    };
    const storage = (scope.browser ?? scope.chrome)?.storage?.local;
    if (storage) {
      const identity = (e: CrawlEntry): string => e.id ?? `${e.platform || ''}|${e.url || ''}|${e.startedAt}`;
      this.#activityWrite = this.#activityWrite.then(async () => {
        try {
          const data = await storage.get('orion_activity');
          const items = Array.isArray(data['orion_activity']) ? (data['orion_activity'] as CrawlEntry[]) : [];
          const index = items.findIndex(item => identity(item) === identity(entry));
          if (index >= 0) {
            items[index] = entry;
          }
          else {
            items.unshift(entry);
          }
          await storage.set({ 'orion_activity': items.slice(0, 40) });
        }
        catch (error) {
          void error;
        }
      }).catch(() => undefined);
      return;
    }
    const runtime = (scope.chrome ?? scope.browser)?.runtime;
    try {
      runtime?.sendMessage?.({ type: 'orion-activity-record', entry }, () => void runtime.lastError);
    }
    catch (error) {
      void error;
    }
  }
}
