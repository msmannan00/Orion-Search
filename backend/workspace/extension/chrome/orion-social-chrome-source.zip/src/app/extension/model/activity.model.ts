export interface CrawlEntry {
  id?: string;
  platform: string;
  url: string;
  status: string;
  startedAt: number;
  finishedAt: number | null;
}

export interface ActivityResponse {
  items?: CrawlEntry[];
  active?: number;
}

export interface RuntimeApi {
  runtime?: {
    sendMessage?(message: unknown, callback: (response: ActivityResponse) => void): void;
    lastError?: unknown;
  };
}
