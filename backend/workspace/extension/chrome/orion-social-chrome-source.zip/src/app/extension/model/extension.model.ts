export const CRAWL_TYPES = [
  'details',
  'posts',
  'videos',
  'shorts',
  'reels',
  'images',
  'comments',
  'followers',
  'friends',
  'repositories',
  'projects',
  'albums',
  'tracks',
  'games',
  'streams',
  'answers',
  'reviews',
  'pins',
  'papers',
  'products',
  'organizations',
  'advertisements',
  'connections',
] as const;

export type CrawlType = typeof CRAWL_TYPES[number];

export interface CrawlPayload {
  url?: string;
  username?: string;
  limit?: number;
  cursor?: string;
  seed?: unknown;
  session?: unknown;
  [key: string]: unknown;
}

export interface social_profile_details {
  crawl_type: CrawlType[];
  real_name: string;
  bio: string;
  description: string;
  location: string;
  profile_url: string;
  total_posts: string;
  total_followers: string;
  total_likes: string;
  avatar: string;
  banner: string;
  [key: string]: unknown;
}

export interface social_resource {
  type: CrawlType;
  resource_id: string;
  url: string;
  parent_url: string;
  title: string;
  caption: string;
  author: string;
  datetime: string;
  media_type: string;
  media_url: string;
  thumbnail_url: string;
  likes: string;
  shares: string;
  views: string;
  [key: string]: unknown;
}

export interface ExtensionCommand {
  command: string;
  platform: string;
  type: string;
  url?: string;
  username?: string;
  payload?: CrawlPayload;
  request_id?: string;
}

export interface CrawlPage {
  items: social_resource[];
  next_cursor?: string;
}

export interface ExtensionResult {
  platform: string;
  type: CrawlType | string;
  implemented: boolean;
  items: unknown[];
  next_cursor?: string;
  has_more?: boolean;
  error?: string;
  login_url?: string;
  request_id?: string;
}
