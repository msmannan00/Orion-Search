import { Component, computed, DestroyRef, effect, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { exhaustMap, from, switchMap, timer } from 'rxjs';
import { CrawlEntry, RuntimeApi } from '../extension/model/activity.model';
import { AuthService } from '../shared/service/auth.service';

const SESSION_POLL_INTERVAL_MS = 5_000;
const ACTIVITY_POLL_INTERVAL_MS = 1_000;
const AUTH_GRACE_MS = 12_000;
const SCAN_HOLD_MS = 12_000;
const CRAWL_STALE_MS = 180_000;

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.html'
})
export class Home {
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);
  private readonly destroyRef = inject(DestroyRef);
  private returningToLogin = false;

  readonly crawlActivity = signal<CrawlEntry[]>([]);
  readonly activityOpen = signal(false);
  readonly activeCrawls = computed(() => this.crawlActivity().filter((entry) => entry.status === 'crawling').length);
  readonly #crawlingHeld = signal(false);
  readonly crawling = this.#crawlingHeld.asReadonly();
  readonly connected = this.auth.authenticated;
  readonly systemConnected = this.auth.systemConnected;
  readonly orionUrl = this.auth.orionUrl;
  readonly orionUrls = this.auth.orionUrls;
  readonly selectableSites = computed(() => {
    const isLocal = (u: string): boolean => /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|$)/i.test(u);
    const selected = this.orionUrl();
    const unique = Array.from(new Set(this.orionUrls().filter((u): u is string => typeof u === 'string' && !!u)));
    return unique.filter(u => u === selected || !isLocal(u));
  });
  readonly socketState = this.auth.socketState;
  readonly version = this.#manifestVersion();
  readonly orionLoginUrl = this.auth.orionLoginUrl;
  readonly title = computed(() => this.crawling() ? 'Crawling…' : !this.connected() ? 'Connecting…' : this.systemConnected() ? 'Ready for tasks' : 'Waiting for Orion');
  readonly message = computed(() => this.crawling()
    ? 'Running a scrape task in the background.'
    : !this.connected()
      ? 'Reconnecting to Orion.'
      : this.systemConnected()
        ? 'Connected and listening for new work.'
        : 'Sign in to Orion to start receiving work.');

  constructor() {
    const warnOnPending = (event: BeforeUnloadEvent): void => {
      if (!this.crawling()) {
        return;
      }

      event.preventDefault();
    };

    globalThis.addEventListener('beforeunload', warnOnPending);
    this.destroyRef.onDestroy(() => globalThis.removeEventListener('beforeunload', warnOnPending));

    let notConnectedTimer: ReturnType<typeof setTimeout> | null = null;
    effect(() => {
      if (this.connected()) {
        if (notConnectedTimer) {
          clearTimeout(notConnectedTimer);
          notConnectedTimer = null;
        }
        return;
      }
      if (!notConnectedTimer) {
        notConnectedTimer = setTimeout(() => {
          notConnectedTimer = null;
          if (!this.connected()) {
            this.#returnToLogin();
          }
        }, AUTH_GRACE_MS);
      }
    });
    this.destroyRef.onDestroy(() => {
      if (notConnectedTimer) {
        clearTimeout(notConnectedTimer);
      }
    });

    timer(0, 1000).pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.#refreshCrawlingState());

    timer(0, SESSION_POLL_INTERVAL_MS).pipe(exhaustMap(() => this.auth.check()),
      takeUntilDestroyed(this.destroyRef)).subscribe();
    timer(0, ACTIVITY_POLL_INTERVAL_MS).pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.#pollActivity());
  }

  switchSite(url: string): void {
    if (!url || url === this.orionUrl()) {
      return;
    }

    void this.auth.selectOrionUrl(url);
  }

  toggleActivity(): void {
    this.activityOpen.update((open) => !open);
  }

  #manifestVersion(): string {
    const scope = globalThis as unknown as { chrome?: { runtime?: { getManifest?(): { version?: string } } }; browser?: { runtime?: { getManifest?(): { version?: string } } } };
    try {
      return (scope.browser ?? scope.chrome)?.runtime?.getManifest?.().version ?? '';
    }
    catch (error) {
      void error;
      return '';
    }
  }

  hostOf(url: string): string {
    try {
      return new URL(url).host;
    }
    catch (error) {
      void error;
      return url;
    }
  }

  timeOf(entry: CrawlEntry): string {
    return new Date(entry.finishedAt ?? entry.startedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  dateTimeOf(entry: CrawlEntry): string {
    return new Date(entry.finishedAt ?? entry.startedAt).toISOString();
  }

  statusLabel(status: string): string {
    if (status === 'crawling') {
      return 'Running';
    }
    if (status === 'done') {
      return 'Complete';
    }
    if (status === 'empty') {
      return 'No data';
    }
    return 'Failed';
  }

  statusBadgeClass(status: string): string {
    if (status === 'crawling') {
      return 'text-warning';
    }
    if (status === 'done') {
      return 'text-success';
    }
    if (status === 'empty') {
      return 'text-ink-muted';
    }
    return 'text-danger';
  }

  signOut(): void {
    this.#logoutAndReturn();
  }

  #refreshCrawlingState(): void {
    const now = Date.now();
    this.#crawlingHeld.set(this.crawlActivity().some((entry) => {
      if (entry.status === 'crawling') {
        return now - (entry.startedAt ?? 0) < CRAWL_STALE_MS;
      }
      return now - (entry.finishedAt ?? 0) < SCAN_HOLD_MS;
    }));
  }

  #pollActivity(): void {
    const scope = globalThis as unknown as { chrome?: RuntimeApi; browser?: RuntimeApi };
    const runtime = (scope.chrome ?? scope.browser)?.runtime;
    try {
      runtime?.sendMessage?.({ type: 'orion-activity' }, (response) => {
        void runtime.lastError;
        if (response && Array.isArray(response.items)) {
          this.crawlActivity.set(response.items);
          this.#refreshCrawlingState();
        }
      });
    }
    catch (error) {
      void error;
    }
  }

  #logoutAndReturn(): void {
    if (this.returningToLogin) {
      return;
    }

    this.returningToLogin = true;
    this.auth.logout().pipe(switchMap(() => from(this.router.navigate(['/']))),
      takeUntilDestroyed(this.destroyRef)).subscribe();
  }

  #returnToLogin(): void {
    if (this.returningToLogin) {
      return;
    }

    this.returningToLogin = true;
    void this.router.navigate(['/']);
  }
}
