import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, from, of, switchMap, tap } from 'rxjs';
import { AuthService } from '../shared/service/auth.service';

const HOST_ACCESS = { origins: ['<all_urls>'] };

interface ExtensionPermissions {
  contains(permissions: { origins: string[] }): Promise<boolean>;
  request(permissions: { origins: string[] }): Promise<boolean>;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html'
})
export class Login {
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);
  private readonly destroyRef = inject(DestroyRef);

  readonly busy = signal(false);
  readonly checking = signal(true);
  readonly accessGranted = signal(true);
  readonly error = this.auth.error;
  readonly orionUrls = this.auth.orionUrls;
  orionUrl = '';
  username = '';
  password = '';

  constructor() {
    void this.#permissions()?.contains(HOST_ACCESS).then((granted) => this.accessGranted.set(granted), () => undefined);
    from(this.auth.loadOrionUrl()).pipe(switchMap((url) => {
      this.orionUrl = url || this.orionUrls()[0] || '';
      return url ? this.auth.check() : of(false);
    }),
    switchMap((authenticated) => {
      if (!authenticated) {
        this.auth.error.set('');
        return of(false);
      }
      return this.auth.refresh();
    }),
    switchMap((authenticated) => {
      if (!authenticated) {
        return of(false);
      }
      return from(this.router.navigate(['/home']));
    }),
    finalize(() => {
      this.checking.set(false);
      if (!this.orionUrl) {
        this.auth.error.set('Open your Orion site to connect it to this extension.');
      }
    }),
    takeUntilDestroyed(this.destroyRef)).subscribe();
  }

  grantAccess(): void {
    void this.#permissions()?.request(HOST_ACCESS).then((granted) => this.accessGranted.set(granted), () => undefined);
  }

  signIn(): void {
    this.busy.set(true);
    from(this.auth.selectOrionUrl(this.orionUrl)).pipe(switchMap(() => this.auth.login(this.username, this.password)), tap(() => {
      this.password = '';
    }),
    switchMap((loggedIn) => {
      if (!loggedIn) {
        return of(false);
      }

      return from(this.router.navigate(['/home']));
    }),
    finalize(() => this.busy.set(false)),
    takeUntilDestroyed(this.destroyRef)).subscribe();
  }

  #permissions(): ExtensionPermissions | null {
    const scope = globalThis as unknown as { chrome?: { permissions?: ExtensionPermissions }; browser?: { permissions?: ExtensionPermissions } };
    return (scope.browser ?? scope.chrome)?.permissions ?? null;
  }
}
