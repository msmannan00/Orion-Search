import { HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { catchError, defer, map, Observable, of, tap } from 'rxjs';
import { ApiService } from './api.service';

interface ExtensionSession {
  system_connected?: boolean;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly api = inject(ApiService);

  readonly authenticated = signal(false);
  readonly systemConnected = signal(false);
  readonly error = signal('');
  readonly orionUrl = this.api.orionUrl;
  readonly orionUrls = this.api.orionUrls;
  readonly socketState = this.api.socketState;
  readonly orionLoginUrl = this.api.loginUrl;

  loadOrionUrl(): Promise<string> {
    return this.api.load();
  }

  selectOrionUrl(url: string): Promise<void> {
    return this.api.select(url);
  }

  login(username: string, password: string): Observable<boolean> {
    return this.#call(this.api.post<{ access_token?: string }>('extension/login', { username, password })
      .pipe(tap((result) => this.#storeToken(result))));
  }

  check(): Observable<boolean> {
    return this.#call(this.api.get<ExtensionSession>('extension/session')
      .pipe(tap((session: ExtensionSession) => this.systemConnected.set(!!session?.system_connected))));
  }

  refresh(): Observable<boolean> {
    return this.#call(this.api.post<{ access_token?: string }>('extension/refresh', null)
      .pipe(tap((result) => this.#storeToken(result))));
  }

  logout(): Observable<void> {
    return this.#call(this.api.post<unknown>('extension/logout', null)).pipe(tap(() => {
      this.authenticated.set(false);
      void this.api.clearToken();
    }),
    map(() => undefined));
  }

  #storeToken(result: { access_token?: string } | unknown): void {
    const token = (result as { access_token?: string })?.access_token;
    if (typeof token === 'string' && token) {
      void this.api.setToken(token);
    }
  }

  #call(request: Observable<unknown>): Observable<boolean> {
    return defer(() => {
      this.error.set('');
      return request;
    }).pipe(tap(() => {
      this.authenticated.set(true);
    }),
    map(() => true),
    catchError((requestError: unknown) => this.#handleError(requestError)));
  }

  #handleError(requestError: unknown): Observable<boolean> {
    if (requestError instanceof HttpErrorResponse) {
      const detail = requestError.error && typeof requestError.error === 'object'
        ? requestError.error.detail
        : '';

      if (requestError.status === 401 && detail === 'orion_login_required') {
        window.open(this.orionLoginUrl(), '_blank', 'noopener,noreferrer');
      }

      if (requestError.status === 401 || requestError.status === 403) {
        this.authenticated.set(false);
      }

      this.error.set(detail === 'orion_login_required'
        ? ''
        : requestError.status === 401 || requestError.status === 403
          ? String(detail || 'User not logged in system.')
          : requestError.status === 0
            ? 'Orion is not reachable.'
            : `Orion is not reachable (${requestError.status}).`);
    }
    else {
      this.authenticated.set(false);
      this.systemConnected.set(false);
      this.error.set('Orion is not reachable.');
    }

    return of(false);
  }
}
