import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../../app/extension/model/extension.model';
import { TabController } from '../tab_management/tab.controller';
import { Identity } from '../helper/identity';

export interface LoginMarkers {
  signedIn: string[];
  signedOut?: string[];
  username?: string;
  cookie?: string;
  usernameCookie?: string;
}

export interface Crawler {
  readonly platform: string;

  readonly base: string;

  readonly loginUrl?: string;

  readonly profiling?: boolean;

  readonly visibilityCrawling?: boolean;

  readonly authwall: Record<CrawlType, boolean>;

  readonly loginMarkers?: LoginMarkers;

  verifyLogin(): Promise<boolean>;

  identity?(tab: TabController): Promise<Identity>;

  details(payload: CrawlPayload): Promise<social_profile_details[]>;

  fetch_social_resource?(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage>;

  fetch_advertisements?(payload: CrawlPayload): Promise<social_resource[] | CrawlPage>;

  fetch_connections?(payload: CrawlPayload): Promise<social_resource[] | CrawlPage>;

  invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage>;
}
