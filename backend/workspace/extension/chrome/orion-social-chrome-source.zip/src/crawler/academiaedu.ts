import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityRedirect } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { papers } from './resource/academiaedu/academiaedu';

export class AcademiaEdu implements Crawler {
  readonly platform = 'academiaedu';
  readonly base = 'https://www.academia.edu';
  readonly loginUrl = 'https://www.academia.edu/login';
  readonly authwall = ALL_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'papers':
        return papers(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const host = /^https?:\/\/([^/]+\.academia\.edu)/i.exec(url ?? '')?.[1] ?? 'independent.academia.edu';
      const response = await fetch(`https://${host}/${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => Number((new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;
      const displayName = (meta('og:title') || decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '')).replace(/\s*-\s*Academia\.edu$/i, '').trim();
      if (!displayName || /^Academia\.edu$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://${host}/${username}`,
        total_posts: '',
        total_followers: String((number('followers_count') || number('follower_count')) || ''),
        total_likes: '',
        avatar: embedded('photo') || meta('og:image'),
        banner: '',
        crawl_type: ['details', 'papers'],
        platform: this.platform,
        username: username,
        institution: host.replace(/\.academia\.edu$/, ''),
        department: embedded('department_name') || embedded('department'),
        position: embedded('position'),
        papers: number('paper_count') || number('works_count'),
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityRedirect(tab, 'https://www.academia.edu/settings', /\/login/i);
  }



  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.academia.edu/settings', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
