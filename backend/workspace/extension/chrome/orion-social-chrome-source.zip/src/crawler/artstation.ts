import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { openSession } from './tab_management/tab.controller';
import { followers, friends, projects } from './resource/artstation/artstation';

export class ArtStation implements Crawler {
  readonly platform = 'artstation';
  readonly base = 'https://www.artstation.com';
  readonly loginUrl = 'https://www.artstation.com/users/sign_in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    const tab = await openSession('https://www.artstation.com/');
    if (!tab) {
      return [];
    }

    try {
      const response = await tab.fetch(`https://www.artstation.com/users/${encodeURIComponent(username)}.json`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const data = JSON.parse(response.body);
      if (!data?.id) {
        return [];
      }

      const social: any[] = Array.isArray(data.social_profiles) ? data.social_profiles : [];
      const skills: any[] = Array.isArray(data.skills) ? data.skills : [];
      const software: any[] = Array.isArray(data.software_items) ? data.software_items : [];
      const experience: any[] = Array.isArray(data.experience_items) ? data.experience_items : [];

      return [{
        real_name: data.full_name || data.username || username,
        bio: data.headline ?? '',
        description: data.headline ?? '',
        location: [data.city, data.country].filter(Boolean).join(', '),
        profile_url: data.permalink ?? `https://www.artstation.com/${username}`,
        total_posts: String((data.projects_count ?? 0) || ''),
        total_followers: String((data.followers_count ?? 0) || ''),
        total_likes: String((data.likes_count ?? 0) || ''),
        avatar: data.large_avatar_url ?? data.medium_avatar_url ?? '',
        banner: data.default_cover_url ?? '',
        crawl_type: ['details', 'projects', 'followers', 'friends'],
        platform: this.platform,
        username: data.username ?? username,
        user_id: data.id ?? 0,
        full_name: data.full_name ?? '',
        headline: data.headline ?? '',
        city: data.city ?? '',
        country: data.country ?? '',
        website: data.artstation_website ?? '',
        about: (data.profile?.about ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        followers_count: data.followers_count ?? 0,
        likes_count: data.likes_count ?? 0,
        projects_count: data.projects_count ?? 0,
        collections_count: data.collections_count ?? 0,
        social_profiles: social.map((s: any) => `${s.platform ?? s.name ?? ''}: ${s.url ?? s.value ?? ''}`).filter((v: string) => v.trim() !== ':').join(' | '),
        social_count: social.length,
        skills: skills.map((s: any) => s.name ?? '').filter(Boolean).join(', '),
        software: software.map((s: any) => s.name ?? '').filter(Boolean).join(', '),
        experience: experience.map((e: any) => [e.title, e.company_name ?? e.company].filter(Boolean).join(' @ ')).filter(Boolean).join(' | '),
        has_public_email: data.has_public_email ?? false,
        is_staff: data.is_staff ?? false,
        is_pro: data.is_plus_member ?? data.pro_member ?? false,
        created_at: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.artstation.com/api/v2/user_sessions/current_user.json', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id || data?.username);
    }
    catch {
      return false;
    }
  }
}
