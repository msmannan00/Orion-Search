import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { maintained, repositories } from './resource/aur/aur';

export class AUR implements Crawler {
  readonly platform = 'aur';
  readonly base = 'https://aur.archlinux.org';
  readonly loginUrl = 'https://aur.archlinux.org/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const results = await maintained(username);
      if (!results.length) {
        return [];
      }

      const votes = results.reduce((sum: number, pkg: any) => sum + Number(pkg?.NumVotes ?? 0), 0);
      return [{
        real_name: username,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://aur.archlinux.org/packages/?K=${encodeURIComponent(username)}&SeB=m`,
        total_posts: String(results.length || ''),
        total_followers: '',
        total_likes: String(votes || ''),
        avatar: '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: username,
        package_count: results.length,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://aur.archlinux.org/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
