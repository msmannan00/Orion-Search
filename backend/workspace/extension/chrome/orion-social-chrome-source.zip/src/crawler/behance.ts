import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityStays } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { projects } from './resource/behance/behance';

export class Behance implements Crawler {
  readonly platform = 'behance';
  readonly base = 'https://www.behance.net';
  readonly loginUrl = 'https://www.behance.net/';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.behance.net/${encodeURIComponent(username)}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => {
        const found = new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };

      let user: any = null;
      try {
        const store = /id="beconfig-store_state">([\s\S]*?)<\/script>/.exec(html);
        if (store) {
          user = JSON.parse(store[1])?.profile?.user ?? null;
        }
      }
      catch {
        user = null;
      }

      if (user && user.username) {
        const stats: any = user.stats ?? {};
        const webLinks: any[] = Array.isArray(user.webLinks) ? user.webLinks : [];
        const social: any[] = Array.isArray(user.socialReferences) ? user.socialReferences : [];
        const work: any[] = Array.isArray(user.workExperiences) ? user.workExperiences : [];
        return [{
          real_name: user.displayName || [user.firstName, user.lastName].filter(Boolean).join(' ') || user.username,
          bio: (user.bio ?? '').replace(/\s+/g, ' ').trim(),
          description: (user.bio ?? '').replace(/\s+/g, ' ').trim(),
          location: user.location ?? '',
          profile_url: `https://www.behance.net/${user.username}`,
          total_posts: '',
          total_followers: String((stats.followers ?? 0) || ''),
          total_likes: String((stats.appreciations ?? 0) || ''),
          avatar: user.images?.['276'] ?? user.images?.['138'] ?? meta('og:image'),
          banner: user.bannerImageUrl ?? '',
          crawl_type: ['details', 'projects'],
          platform: this.platform,
          username: user.username,
          user_id: user.id ?? 0,
          first_name: user.firstName ?? '',
          display_name: user.displayName ?? '',
          occupation: user.occupation ?? '',
          company: user.company ?? '',
          website: user.website ?? '',
          location_url: user.locationUrl ?? '',
          followers_count: stats.followers ?? 0,
          appreciations: stats.appreciations ?? 0,
          views: stats.views ?? 0,
          creator_pro: Boolean(user.creatorPro && (typeof user.creatorPro === 'object' ? Object.keys(user.creatorPro).length > 0 : user.creatorPro)),
          featured_freelancer: user.isFeaturedFreelancer ?? false,
          web_links: webLinks.map((l: any) => `${l.title ?? ''}: ${l.url ?? ''}`).filter((v: string) => v.trim() !== ':').join(' | '),
          social_links: social.map((s: any) => `${s.socialService ?? ''}: ${s.url ?? ''}`).filter((v: string) => v.trim() !== ':').join(' | '),
          social_count: social.length,
          work_experience: work.map((w: any) => [w.position ?? w.title, w.company ?? w.companyName].filter(Boolean).join(' @ ')).filter(Boolean).join(' | '),
          created_at: user.createdOn ? new Date(user.createdOn * 1000).toISOString() : '',
        }];
      }

      const displayName = embedded('display_name') || title.replace(/\s*::\s*Behance$/i, '');
      if (!displayName || /^Behance$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: embedded('about') || meta('og:description'),
        description: embedded('about') || meta('og:description'),
        location: embedded('location'),
        profile_url: `https://www.behance.net/${embedded('username') || username}`,
        total_posts: '',
        total_followers: String((number('followers')) || ''),
        total_likes: String((number('appreciations')) || ''),
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'projects'],
        platform: this.platform,
        username: embedded('username') || username,
        occupation: embedded('occupation'),
        company: embedded('company'),
        views: number('views'),
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityStays(tab, 'https://www.behance.net/settings', /\/settings/i);
  }



  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.behance.net/v3/users/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.id || data?.id);
    }
    catch {
      return false;
    }
  }
}
