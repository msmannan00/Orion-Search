export const CHALLENGE_FLAG = '__orionChallengeSeen';
export const CHALLENGE_INSTALLED = '__orionGuardedFetch';

export const CHALLENGE_HEADER_SIGNALS: [string, RegExp][] = [
  ['cf-mitigated', /challenge/i],
  ['x-datadome', /./],
  ['x-dd-b', /./],
  ['x-datadome-cid', /./],
  ['x-px', /./],
  ['x-px-block', /./],
  ['x-pxhd', /./],
  ['x-iinfo', /./],
  ['x-cdn', /incap/i],
  ['x-kpsdk-ct', /./],
  ['x-kpsdk-cd', /./],
  ['x-amzn-waf-action', /captcha|challenge/i],
  ['x-sucuri-block', /./],
];

export const CHALLENGE_WAF_SERVERS = /cloudflare|datadome|akamaighost|perimeterx|incapsula|imperva|sucuri|kasada|queue-it/i;

export const CHALLENGE_BLOCK_STATUS = new Set([401, 403, 429, 503]);

export const CHALLENGE_INTERSTITIAL_MAX = 15000;

export const CHALLENGE_STRONG_MARKERS = /(cf-browser-verification|cf[_-]chl|__cf_chl|cf_chl_opt|cdn-cgi\/challenge-platform|challenges\.cloudflare\.com|cf-turnstile|just a moment|checking (?:if the site connection is secure|your browser)|attention required!|enable javascript and cookies to continue|error 10(?:20|13|15)|access denied[\s\S]{0,80}powered by datadome|geo\.captcha-delivery|captcha-delivery\.com|please verify you are a human|px-captcha|client\.perimeterx\.net|incapsula incident|_incapsula_resource|access denied[\s\S]{0,80}don.?t have permission to access|queue-it\.net|queueittoken|you are now in line|unusual traffic (?:from|has)|are you a (?:robot|human)|verify you are (?:a )?human|security check to access|access to this page has been denied|ddos protection by|one more step)/i;

export const CHALLENGE_WEAK_MARKERS = /(g-recaptcha|grecaptcha|recaptcha\/(?:api|enterprise)\.js|www\.google\.com\/recaptcha|h-captcha|hcaptcha\.com|js\.hcaptcha|funcaptcha|arkose ?labs|api\.arkoselabs|fc-token|awswaf|token\.awswaf|aws-waf-token|datadome|perimeterx|_px(?:app|vid|hd)?|_abck|ak_bmsc|kasada|kpsdk|visid_incap|incap_ses)/i;
