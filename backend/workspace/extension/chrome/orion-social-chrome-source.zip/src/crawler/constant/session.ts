import { RuntimeApi } from '../../app/extension/model/session.model';

export const RUNTIME_API = ((globalThis as { chrome?: RuntimeApi }).chrome ?? (globalThis as { browser?: RuntimeApi }).browser) as RuntimeApi | undefined;

export const SAME_SITE: Record<string, string> = { no_restriction: 'None', lax: 'Lax', strict: 'Strict', unspecified: '' };
