import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { repositories } from './resource/cratesio/cratesio';

export class CratesIo implements Crawler {
  readonly platform = 'cratesio';
  readonly base = 'https://crates.io';
  readonly loginUrl = 'https://crates.io/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://crates.io/api/v1/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload?.user;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.name ?? data.login ?? username,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://crates.io/users/${data.login ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.avatar ?? '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: data.login ?? username,
        id: data.id ?? 0,
        github_url: data.url ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://crates.io/api/v1/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.id);
    }
    catch {
      return false;
    }
  }
}
