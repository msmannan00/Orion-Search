import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { papers, totalWorks } from './resource/dblp/dblp';

export class DBLP implements Crawler {
  readonly platform = 'dblp';
  readonly base = 'https://dblp.org';
  readonly loginUrl = 'https://dblp.org/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'papers':
        return papers(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const name = String(payload.username ?? '');
    if (!name) {
      return [];
    }

    try {
      const count = await totalWorks(name);
      if (!count) {
        return [];
      }

      return [{
        real_name: name,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://dblp.org/search?q=${encodeURIComponent(name)}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'papers'],
        platform: this.platform,
        username: name,
        works_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://dblp.org/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
