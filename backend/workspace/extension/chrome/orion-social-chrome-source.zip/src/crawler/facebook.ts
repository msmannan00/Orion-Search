import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { openSession, TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { ALL_AUTH } from './constant/crawlers';
import { advertisements, connections, followers, friends, images, posts, reels } from './resource/facebook/facebook';
import { detailsOf, profileHtml } from './resource/facebook/helper';

export class Facebook implements Crawler {
  readonly platform = 'facebook';
  readonly base = 'https://www.facebook.com';
  readonly loginUrl = 'https://www.facebook.com/login/';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    cookie: 'c_user',
    usernameCookie: 'c_user',
    signedIn: ['div[role="feed"]', '[aria-label="Your profile"]', 'a[href^="/me/"]'],
    signedOut: ['input[name="pass"]', 'form[action*="login"]', '#loginbutton'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'advertisements') {
      return this.fetch_advertisements(payload);
    }

    if (type === 'connections') {
      return this.fetch_connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'reels':
        return reels(payload);
      case 'images':
        return images(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async fetch_advertisements(payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    return advertisements(payload);
  }

  async fetch_connections(payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    return connections(payload);
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    const tab = username ? await openSession('https://www.facebook.com/') : null;
    if (!tab) {
      return [];
    }

    try {
      const html = await profileHtml(tab, username, '', /profile_header_renderer|property="og:title"/);
      const details = html ? detailsOf(username, html) : null;
      return details ? [details] : [];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const cookie = await tab.cookies();
    const id = (cookie.match(/(?:^|;\s*)c_user=([^;]+)/) || [])[1] || '';
    if (!id) {
      return NO_IDENTITY;
    }
    const response = await tab.fetch('https://www.facebook.com/me/');
    if (!response.ok || /name="pass"|type=["']password["']/i.test(response.body)) {
      return NO_IDENTITY;
    }
    const title = (response.body.match(/<title[^>]*>([^<]+)<\/title>/i) || [])[1] || '';
    const name = title.replace(/\s*[|\u00b7].*$/, '').trim();
    const username = name && !/log in|facebook/i.test(name) ? name : '';
    return { loggedIn: true, username };
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.facebook.com/me/', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      if (/\/login|\/checkpoint/i.test(response.url)) {
        return false;
      }

      const html = await response.text();
      return !/type=["']password["']/i.test(html);
    }
    catch {
      return false;
    }
  }
}
