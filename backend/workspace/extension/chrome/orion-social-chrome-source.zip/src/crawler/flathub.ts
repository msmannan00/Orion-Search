import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { developerTotal, projects } from './resource/flathub/flathub';

export class Flathub implements Crawler {
  readonly platform = 'flathub';
  readonly base = 'https://flathub.org';
  readonly loginUrl = 'https://flathub.org/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const developer = String(payload.username ?? '');
    if (!developer) {
      return [];
    }

    try {
      const count = await developerTotal(developer);
      if (!count) {
        return [];
      }

      return [{
        real_name: developer,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://flathub.org/apps/collection/developer/${encodeURIComponent(developer)}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'projects'],
        platform: this.platform,
        username: developer,
        app_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://flathub.org/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
