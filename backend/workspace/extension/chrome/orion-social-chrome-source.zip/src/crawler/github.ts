import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { TabController } from './tab_management/tab.controller';
import { followers, organizations, posts, projects, repositories } from './resource/github/github';

export class Github implements Crawler {
  readonly platform = 'github';
  readonly base = 'https://github.com';
  readonly loginUrl = 'https://github.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      case 'organizations':
        return organizations(payload);
      case 'followers':
        return followers(payload);
      case 'projects':
        return projects(payload);
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    const tab = new TabController();
    if (!await tab.launch()) {
      return [];
    }

    try {
      await tab.navigate(this.base);
      const response = await tab.fetch(`https://api.github.com/users/${encodeURIComponent(username)}`);
      if (!response.ok) {
        return [];
      }

      const data = JSON.parse(response.body);
      return [{
        real_name: data.name ?? data.login ?? username,
        bio: data.bio ?? '',
        description: data.bio ?? '',
        location: data.location ?? '',
        profile_url: data.html_url ?? `https://github.com/${username}`,
        total_posts: String((data.public_repos ?? 0) || ''),
        total_followers: String((data.followers ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar_url ?? '',
        banner: '',
        crawl_type: ['details', 'repositories', 'projects', 'posts', 'organizations', 'followers'],
        platform: this.platform,
        username: data.login ?? username,
        login: data.login ?? username,
        id: data.id ?? 0,
        node_id: data.node_id ?? '',
        account_type: data.type ?? '',
        site_admin: data.site_admin ?? false,
        gravatar_id: data.gravatar_id ?? '',
        html_url: data.html_url ?? '',
        api_url: data.url ?? '',
        name: data.name ?? '',
        company: data.company ?? '',
        blog: data.blog ?? '',
        email: data.email ?? '',
        twitter: data.twitter_username ?? '',
        hireable: data.hireable ?? false,
        public_repos: data.public_repos ?? 0,
        public_gists: data.public_gists ?? 0,
        followers: data.followers ?? 0,
        created_at: data.created_at ?? '',
        updated_at: data.updated_at ?? '',
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    const tab = new TabController();
    if (!await tab.launch()) {
      return false;
    }

    try {
      const url = await tab.navigate('https://github.com/settings/profile');
      if (/\/login|\/session/i.test(url)) {
        return false;
      }

      const html = await tab.html();
      return /name="user-login" content="[^"]+"/i.test(html);
    }
    finally {
      await tab.close();
    }
  }
}
