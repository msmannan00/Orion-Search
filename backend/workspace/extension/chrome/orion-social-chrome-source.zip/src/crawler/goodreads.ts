import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { posts, reviews } from './resource/goodreads/goodreads';

export class Goodreads implements Crawler {
  readonly platform = 'goodreads';
  readonly base = 'https://www.goodreads.com';
  readonly loginUrl = 'https://www.goodreads.com/user/sign_in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'reviews':
        return reviews(payload);
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const path = /goodreads\.com\/((?:author\/show|user\/show)\/[^/?#]+)/.exec(url ?? '')?.[1] ?? `user/show/${username}`;
      const response = await fetch(`https://www.goodreads.com/${path}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');

      const displayName = (meta('og:title') || title).replace(/\s*\(Author of .*\)$/i, '').replace(/\s*\|\s*Goodreads$/i, '').trim();
      if (!displayName || /^Goodreads$/i.test(displayName)) {
        return [];
      }

      const stat = (label: string): number => {
        const found = new RegExp(`([\\d,]+)\\s*(?:<[^>]+>\\s*)*${label}`, 'i').exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };
      const count = (label: string): number => {
        const found = new RegExp(`([\\d,]+)\\s*${label}`, 'i').exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };
      const avgRating = /([\d.]+)\s*avg rating/i.exec(html)?.[1] ?? '';

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://www.goodreads.com/${path}`,
        total_posts: String((count('ratings') || stat('ratings')) || ''),
        total_followers: String((stat('followers')) || ''),
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'reviews', 'posts'],
        platform: this.platform,
        username: path.split('/').pop() ?? username,
        ratings: count('ratings') || stat('ratings'),
        reviews: count('reviews') || stat('reviews'),
        friends: count('friends'),
        avg_rating: avgRating,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.goodreads.com/user/edit', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/user\/sign_in|\/user\/new/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
