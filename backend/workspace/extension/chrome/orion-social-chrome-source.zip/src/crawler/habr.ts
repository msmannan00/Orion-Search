import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { comments, connections, posts } from './resource/habr/habr';

export class Habr implements Crawler {
  readonly platform = 'habr';
  readonly base = 'https://habr.com';
  readonly loginUrl = 'https://habr.com/en/auth/login/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://habr.com/kek/v2/users/${encodeURIComponent(username)}/card/`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const data: any = await response.json();
      if (!data?.alias) {
        return [];
      }

      const counter: any = data.counterStats ?? {};
      const workplace: any[] = Array.isArray(data.workplace) ? data.workplace : [];
      const loc: any = data.location;
      const location = typeof loc === 'string'
        ? loc
        : (loc && typeof loc === 'object'
          ? [loc.city?.title ?? loc.city, loc.region?.title ?? loc.region, loc.country?.title ?? loc.country].filter((v: any) => v && typeof v === 'string').join(', ')
          : '');

      return [{
        real_name: data.fullname ?? data.alias ?? username,
        bio: data.speciality ?? '',
        description: data.speciality ?? '',
        location,
        profile_url: `https://habr.com/ru/users/${data.alias ?? username}/`,
        total_posts: String((counter.postCount ?? 0) || ''),
        total_followers: String((data.followStats?.followersCount ?? 0) || ''),
        total_likes: '',
        avatar: data.avatarUrl ?? '',
        banner: '',
        crawl_type: ['details', 'posts', 'comments', 'connections'],
        platform: this.platform,
        username: data.alias ?? username,
        full_name: data.fullname ?? '',
        speciality: data.speciality ?? '',
        rating: data.rating ?? 0,
        rating_position: data.ratingPos ?? 0,
        karma: data.scoreStats?.score ?? 0,
        votes_count: data.scoreStats?.votesCount ?? 0,
        reach: data.reach ?? '',
        followers_count: data.followStats?.followersCount ?? 0,
        post_count: counter.postCount ?? 0,
        comment_count: counter.commentCount ?? 0,
        favorite_count: counter.favoriteCount ?? 0,
        article_count: counter.publicationStats?.articleCount ?? 0,
        news_count: counter.publicationStats?.newsCount ?? 0,
        workplace: workplace.map((w: any) => w.title ?? '').filter(Boolean).join(', '),
        gender: data.gender ?? '',
        birthday: data.birthday ?? '',
        is_readonly: data.isReadonly ?? false,
        last_activity_at: data.lastActivityDateTime ?? '',
        registered_at: data.registerDateTime ?? '',
        created_at: data.registerDateTime ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://habr.com/kek/v2/auth/me/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.alias);
    }
    catch {
      return false;
    }
  }
}
