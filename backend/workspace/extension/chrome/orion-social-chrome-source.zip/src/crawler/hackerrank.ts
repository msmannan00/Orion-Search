import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { answers, projects } from './resource/hackerrank/hackerrank';

export class HackerRank implements Crawler {
  readonly platform = 'hackerrank';
  readonly base = 'https://www.hackerrank.com';
  readonly loginUrl = 'https://www.hackerrank.com/auth/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'answers':
        return answers(payload);
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.hackerrank.com/rest/contests/master/hackers/${encodeURIComponent(username)}/profile`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload?.model;
      if (!data?.username) {
        return [];
      }

      const languages: any = data.languages;

      return [{
        real_name: data.name ?? data.username ?? username,
        bio: data.short_bio ?? '',
        description: data.short_bio ?? '',
        location: data.country ?? '',
        profile_url: `https://www.hackerrank.com/profile/${data.username ?? username}`,
        total_posts: '',
        total_followers: String((data.followers_count ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar ?? '',
        banner: '',
        crawl_type: ['details', 'answers', 'projects'],
        platform: this.platform,
        username: data.username ?? username,
        user_id: data.id ?? 0,
        name: data.name ?? '',
        personal_first_name: data.personal_first_name ?? '',
        personal_last_name: data.personal_last_name ?? '',
        country: data.country ?? '',
        local_language: data.local_language ?? '',
        school: data.school ?? '',
        company: data.company ?? '',
        job_title: data.job_title ?? '',
        title: data.title ?? '',
        jobs_headline: data.jobs_headline ?? '',
        website: data.website ?? '',
        github_url: data.github_url ?? '',
        linkedin_url: data.linkedin_url ?? '',
        level: data.level ?? 0,
        followers_count: data.followers_count ?? 0,
        event_count: data.event_count ?? 0,
        hackerresume_count: data.hackerresume_count ?? 0,
        languages: Array.isArray(languages) ? languages.join(', ') : (languages && typeof languages === 'object' ? Object.keys(languages).join(', ') : String(languages ?? '')),
        online: data.online ?? false,
        is_admin: data.is_admin ?? false,
        subscription_plan: data.subscription_plan ?? '',
        created_at: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.hackerrank.com/rest/contests/master/hackers/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.model?.username);
    }
    catch {
      return false;
    }
  }
}
