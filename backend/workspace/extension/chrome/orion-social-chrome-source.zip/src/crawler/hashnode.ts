import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityJson } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { posts } from './resource/hashnode/hashnode';

export class Hashnode implements Crawler {
  readonly platform = 'hashnode';
  readonly base = 'https://hashnode.com';
  readonly loginUrl = 'https://hashnode.com/login';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://hashnode.com/@${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => Number((new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;
      const heading = meta('og:title');
      const handleMatch = /\(@([^)]+)\)/.exec(heading);
      const displayName = heading.replace(/\s*\(@[^)]*\)/, '').replace(/\s*\|\s*Hashnode$/i, '').trim() || embedded('name');
      if (!handleMatch || !displayName) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: embedded('tagline') || meta('og:description'),
        description: embedded('tagline') || meta('og:description'),
        location: embedded('location'),
        profile_url: `https://hashnode.com/@${handleMatch[1] || username}`,
        total_posts: String((number('numPosts') || number('postsCount')) || ''),
        total_followers: String((number('followersCount')) || ''),
        total_likes: '',
        avatar: embedded('photo') || embedded('profilePicture') || meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: handleMatch[1] || username,
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityJson(tab, 'https://hashnode.com/api/auth/session', (data) => {
      const user = data?.user;
      return user?.id ? { loggedIn: true, username: String(user.name || '') } : null;
    });
  }



  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://hashnode.com/api/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.username || data?.username);
    }
    catch {
      return false;
    }
  }
}
