import { Injectable } from '@angular/core';
import { CHALLENGE_BLOCK_STATUS, CHALLENGE_FLAG, CHALLENGE_HEADER_SIGNALS, CHALLENGE_INSTALLED, CHALLENGE_INTERSTITIAL_MAX, CHALLENGE_STRONG_MARKERS, CHALLENGE_WAF_SERVERS, CHALLENGE_WEAK_MARKERS } from '../constant/challenge';

@Injectable({ providedIn: 'root' })
export class ChallengeGuard {
  install(): void {
    const scope = globalThis as Record<string, unknown>;
    if (scope[CHALLENGE_INSTALLED]) {
      return;
    }

    const native = globalThis.fetch.bind(globalThis);
    globalThis.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
      const response = await native(input, init);
      if (await this.#isChallenge(response)) {
        scope[CHALLENGE_FLAG] = Number(scope[CHALLENGE_FLAG] ?? 0) + 1;
        throw new ChallengeError();
      }
      return response;
    };
    scope[CHALLENGE_INSTALLED] = true;
  }

  // A count rather than a flag: crawls can run side by side, and a flag let one
  // crawl's reset erase a challenge another had just hit. Each crawl takes a
  // marker before it starts and asks what happened since.
  marker(): number {
    return Number((globalThis as Record<string, unknown>)[CHALLENGE_FLAG] ?? 0);
  }

  since(marker: number): boolean {
    return this.marker() > marker;
  }

  async #isChallenge(response: Response): Promise<boolean> {
    for (const [header, pattern] of CHALLENGE_HEADER_SIGNALS) {
      const value = response.headers.get(header);
      if (value && pattern.test(value)) {
        return true;
      }
    }

    const blocked = CHALLENGE_BLOCK_STATUS.has(response.status);
    const wafServer = CHALLENGE_WAF_SERVERS.test(response.headers.get('server') ?? '');

    const contentType = response.headers.get('content-type') ?? '';
    if (!blocked && !contentType.includes('text/html') && !contentType.includes('text/plain')) {
      return false;
    }

    const body = await response.clone().text().catch(() => '');
    if (CHALLENGE_STRONG_MARKERS.test(body)) {
      return true;
    }

    if (blocked && wafServer && body.length > 0 && CHALLENGE_WEAK_MARKERS.test(body)) {
      return true;
    }

    return (blocked || body.length < CHALLENGE_INTERSTITIAL_MAX) && CHALLENGE_WEAK_MARKERS.test(body);
  }
}

export class ChallengeError extends Error {
  constructor() {
    super('challenge_detected');
    this.name = 'ChallengeError';
  }
}
