import { CrawlPayload } from '../../app/extension/model/extension.model';

export function limitOf(payload: CrawlPayload | null | undefined, fallback: number, max: number = fallback): number {
  const requested = Number(payload?.limit);
  if (!Number.isFinite(requested) || requested <= 0) {
    return fallback;
  }
  return Math.max(1, Math.min(Math.floor(requested), max));
}
