import { Injectable } from '@angular/core';
import { RUNTIME_API, SAME_SITE } from '../constant/session';
import { BrowserCookie, Captured } from '../../app/extension/model/session.model';

@Injectable({ providedIn: 'root' })
export class SessionExport {
  async export(url: string, seed?: unknown): Promise<{ filename: string; zip_base64: string; bytes: number; username: string } | null> {
    if (!url) {
      return null;
    }

    let host = '';
    try {
      host = new URL(url).hostname;
    }
    catch {
      return null;
    }

    const captured = await this.#capture(url, seed);
    if (!captured || !Array.isArray(captured.cookies)) {
      return null;
    }

    const seen = new Set<string>();
    const cookies = captured.cookies.filter((cookie: BrowserCookie) => {
      const key = `${cookie.name} ${cookie.domain} ${cookie.path}`;
      if (seen.has(key)) {
        return false;
      }

      seen.add(key);
      return true;
    }).map((cookie: BrowserCookie) => {
      const mapped: Record<string, unknown> = {
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        expires: cookie.expirationDate ?? -1,
        httpOnly: cookie.httpOnly,
        secure: cookie.secure,
      };

      const sameSite = SAME_SITE[cookie.sameSite ?? 'unspecified'];
      if (sameSite === 'None' || sameSite === 'Lax' || sameSite === 'Strict') {
        mapped['sameSite'] = sameSite;
      }
      return mapped;
    });

    const local = captured.localStorage ?? {};
    const session = captured.sessionStorage ?? {};
    const indexedDb = captured.indexedDB ?? {};
    const origin = captured.origin ?? new URL(url).origin;
    const origins = (Object.keys(local).length || Object.keys(session).length || Object.keys(indexedDb).length)
      ? [{
        origin,
        localStorage: Object.entries(local).map(([name, value]) => ({ name, value: String(value) })),
        sessionStorage: Object.entries(session).map(([name, value]) => ({ name, value: String(value) })),
        indexedDB: indexedDb,
      }]
      : [];

    const username = String(captured.username ?? '');
    const state = JSON.stringify({
      version: 1,
      url,
      host,
      origin,
      username,
      userAgent: String(captured.userAgent ?? ''),
      capturedAt: new Date().toISOString(),
      cookies,
      origins,
      localStorage: local,
      sessionStorage: session,
      indexedDB: indexedDb,
    }, null, 2);
    const zip = await this.#zip('session.json', new TextEncoder().encode(state));
    return { filename: `${host}-session.zip`, zip_base64: this.#base64(zip), bytes: zip.length, username };
  }

  async openVerifyTab(url: string, session?: unknown): Promise<{ tabId?: number; windowId?: number; error?: string }> {
    if (!url) {
      return { error: 'not logged in' };
    }
    const opened = await this.#send({ type: 'orion-verify-open', url, session }) as { tabId?: number; windowId?: number; error?: string } | null;
    return opened || { error: 'verify_window_failed' };
  }

  async closeVerifyTab(windowId?: number): Promise<void> {
    await this.#send({ type: 'orion-verify-close', windowId });
  }

  #send(message: Record<string, unknown>): Promise<unknown> {
    return new Promise((resolve) => {
      const runtime = RUNTIME_API?.runtime;
      if (!runtime?.sendMessage) {
        resolve(null);
        return;
      }
      runtime.sendMessage(message, (response) => {
        void runtime.lastError;
        resolve(response ?? null);
      });
    });
  }

  #capture(url: string, seed?: unknown): Promise<Captured | null> {
    return new Promise((resolve) => {
      const runtime = RUNTIME_API?.runtime;
      if (!runtime?.sendMessage) {
        resolve(null);
        return;
      }
      runtime.sendMessage({ type: 'orion-session', url, payload: seed ? { seed } : undefined }, (response) => {
        void runtime.lastError;
        resolve(response ?? null);
      });
    });
  }

  async #zip(name: string, data: Uint8Array): Promise<Uint8Array> {
    const compressed = await this.#deflate(data);
    const nameBytes = new TextEncoder().encode(name);
    const crc = this.#crc32(data);

    const local = this.#record(30 + nameBytes.length, (view, bytes) => {
      view.setUint32(0, 0x04034b50, true);
      view.setUint16(4, 20, true);
      view.setUint16(8, 8, true);
      view.setUint32(14, crc, true);
      view.setUint32(18, compressed.length, true);
      view.setUint32(22, data.length, true);
      view.setUint16(26, nameBytes.length, true);
      bytes.set(nameBytes, 30);
    });

    const central = this.#record(46 + nameBytes.length, (view, bytes) => {
      view.setUint32(0, 0x02014b50, true);
      view.setUint16(4, 20, true);
      view.setUint16(6, 20, true);
      view.setUint16(10, 8, true);
      view.setUint32(16, crc, true);
      view.setUint32(20, compressed.length, true);
      view.setUint32(24, data.length, true);
      view.setUint16(28, nameBytes.length, true);
      bytes.set(nameBytes, 46);
    });

    const localTotal = local.length + compressed.length;
    const eocd = this.#record(22, (view) => {
      view.setUint32(0, 0x06054b50, true);
      view.setUint16(8, 1, true);
      view.setUint16(10, 1, true);
      view.setUint32(12, central.length, true);
      view.setUint32(16, localTotal, true);
    });

    const out = new Uint8Array(localTotal + central.length + eocd.length);
    out.set(local, 0);
    out.set(compressed, local.length);
    out.set(central, localTotal);
    out.set(eocd, localTotal + central.length);
    return out;
  }

  #record(size: number, fill: (view: DataView, bytes: Uint8Array) => void): Uint8Array {
    const bytes = new Uint8Array(size);
    fill(new DataView(bytes.buffer), bytes);
    return bytes;
  }

  async #deflate(data: Uint8Array): Promise<Uint8Array> {
    const buffer = data.slice().buffer as ArrayBuffer;
    const stream = new Blob([buffer]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  #crc32(data: Uint8Array): number {
    let crc = 0xffffffff;
    for (let index = 0; index < data.length; index += 1) {
      crc ^= data[index];
      for (let bit = 0; bit < 8; bit += 1) {
        crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
      }
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  #base64(bytes: Uint8Array): string {
    let binary = '';
    for (let index = 0; index < bytes.length; index += 1) {
      binary += String.fromCharCode(bytes[index]);
    }
    return btoa(binary);
  }
}
