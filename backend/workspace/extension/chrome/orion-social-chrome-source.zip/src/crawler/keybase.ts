import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, organizations } from './resource/keybase/keybase';

export class Keybase implements Crawler {
  readonly platform = 'keybase';
  readonly base = 'https://keybase.io';
  readonly loginUrl = 'https://keybase.io/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'followers':
        return followers(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://keybase.io/_/api/1.0/user/lookup.json?usernames=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = Array.isArray(payload?.them) ? payload.them[0] : null;
      if (!data?.id) {
        return [];
      }

      const proofs: any[] = Array.isArray(data.proofs_summary?.all) ? data.proofs_summary.all : [];
      const group: any = data.proofs_summary?.by_presentation_group ?? {};
      const pick = (service: string) => group[service]?.[0]?.nametag ?? '';
      const crypto: any[] = Array.isArray(data.cryptocurrency_addresses?.bitcoin) ? data.cryptocurrency_addresses.bitcoin : [];
      const devices: any = data.devices ?? {};
      const publicKeys: any = data.public_keys ?? {};

      return [{
        real_name: data.profile?.full_name ?? data.basics?.username ?? username,
        bio: data.profile?.bio ?? '',
        description: data.profile?.bio ?? '',
        location: data.profile?.location ?? '',
        profile_url: `https://keybase.io/${data.basics?.username ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.pictures?.primary?.url ?? '',
        banner: '',
        crawl_type: ['details', 'followers', 'organizations'],
        platform: this.platform,
        username: data.basics?.username ?? username,
        username_cased: data.basics?.username_cased ?? '',
        keybase_id: data.id ?? '',
        full_name: data.profile?.full_name ?? '',
        status: data.basics?.status ?? 0,
        twitter: pick('twitter'),
        github: pick('github'),
        reddit: pick('reddit'),
        hackernews: pick('hackernews'),
        mastodon: pick('mastodon'),
        facebook: pick('facebook'),
        website: pick('dns') || pick('generic_web_site'),
        proofs: proofs.map((p: any) => `${p.proof_type ?? ''}:${p.nametag ?? ''}`).filter((v: string) => v !== ':').join(' | '),
        proofs_count: proofs.length,
        proof_services: proofs.map((p: any) => p.proof_type ?? '').filter(Boolean).join(', '),
        bitcoin_addresses: crypto.map((c: any) => c.address ?? '').filter(Boolean).join(', '),
        stellar_address: data.stellar?.primary?.account_id ?? '',
        pgp_key_ids: Array.isArray(publicKeys.pgp_public_keys) ? String(publicKeys.pgp_public_keys.length) : (publicKeys.primary?.key_fingerprint ?? ''),
        pgp_fingerprint: publicKeys.primary?.key_fingerprint ?? '',
        devices_count: Object.keys(devices).length,
        device_names: Object.values(devices).map((d: any) => d?.name ?? '').filter(Boolean).join(', '),
        created_at: data.basics?.ctime ? new Date(data.basics.ctime * 1000).toISOString() : '',
        updated_at: data.profile?.mtime ? new Date(data.profile.mtime * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://keybase.io/_/api/1.0/session.json', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.status?.code === 0 && data?.session);
    }
    catch {
      return false;
    }
  }
}
