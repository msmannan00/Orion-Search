import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, organizations, tracks } from './resource/lastfm/lastfm';
import { openSession } from './tab_management/tab.controller';

export class LastFm implements Crawler {
  readonly platform = 'lastfm';
  readonly base = 'https://www.last.fm';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'tracks':
        return tracks(payload);
      case 'albums':
        return albums(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    const tab = await openSession('https://www.last.fm/');
    if (!tab) {
      return [];
    }

    try {
      const response = await tab.fetch(`https://www.last.fm/user/${encodeURIComponent(username)}`);
      if (!response.ok) {
        return [];
      }

      const html = response.body;
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');

      if (!/Music Profile/i.test(title)) {
        return [];
      }

      const stat = (label: string): number => {
        const found = new RegExp(`data-header-stat-name="${label}"[\\s\\S]{0,400}?<h4[^>]*>\\s*([\\d,]+)`, 'i').exec(html) ?? new RegExp(`${label}[\\s\\S]{0,200}?([\\d,]{2,})`, 'i').exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };
      return [{
        real_name: title.replace(/[’']s Music Profile.*$/i, '').trim(),
        bio: meta('og:description'),
        description: meta('og:description'),
        location: '',
        profile_url: `https://www.last.fm/user/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: String((stat('loved')) || ''),
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'tracks', 'albums'],
        platform: this.platform,
        username: username,
        scrobbles: stat('scrobbles'),
        artists: stat('artists'),
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.last.fm/settings', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
