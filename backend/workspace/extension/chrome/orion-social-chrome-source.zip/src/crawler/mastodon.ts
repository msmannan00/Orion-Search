import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { connections, followers, friends, posts } from './resource/mastodon/mastodon';

export class Mastodon implements Crawler {
  readonly platform = 'mastodon';
  readonly base = 'https://mastodon.social';
  readonly loginUrl = 'https://mastodon.social/auth/sign_in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const origin = /^https?:\/\/[^/]+/.exec(url ?? '')?.[0] ?? 'https://mastodon.social';
      const response = await fetch(`${origin}/api/v1/accounts/lookup?acct=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      if (!data?.id) {
        return [];
      }

      const clean = (value: string): string => String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim();
      const fields = Array.isArray(data.fields) ? data.fields : [];
      const website = fields.find((f: any) => /site|web|url|blog|home/i.test(f.name ?? ''))?.value ?? '';

      return [{
        real_name: data.display_name || data.username || username,
        bio: clean(data.note),
        description: clean(data.note),
        location: fields.find((f: any) => /location|city|country|based/i.test(f.name ?? ''))?.value ?? '',
        profile_url: data.url ?? `${origin}/@${username}`,
        total_posts: String((data.statuses_count ?? 0) || ''),
        total_followers: String((data.followers_count ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar ?? '',
        banner: data.header ?? '',
        crawl_type: ['details', 'posts', 'followers', 'friends', 'connections'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? '',
        acct: data.acct ?? '',
        uri: data.uri ?? '',
        website: clean(website),
        avatar_static: data.avatar_static ?? '',
        header_static: data.header_static ?? '',
        statuses_count: data.statuses_count ?? 0,
        followers_count: data.followers_count ?? 0,
        bot: data.bot ?? false,
        group: data.group ?? false,
        locked: data.locked ?? false,
        discoverable: data.discoverable ?? false,
        indexable: data.indexable ?? false,
        noindex: data.noindex ?? false,
        hide_collections: data.hide_collections ?? false,
        roles: (Array.isArray(data.roles) ? data.roles : []).map((r: any) => r.name ?? '').filter(Boolean).join(', '),
        fields: fields.map((f: any) => `${f.name ?? ''}: ${clean(f.value)}`).filter((x: string) => x !== ': ').join(' | '),
        last_status_at: data.last_status_at ?? '',
        created_at: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://mastodon.social/api/v1/accounts/verify_credentials', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
