import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { posts } from './resource/medium/medium';

export class Medium implements Crawler {
  readonly platform = 'medium';
  readonly base = 'https://medium.com';
  readonly loginUrl = 'https://medium.com/m/signin';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://medium.com/feed/@${encodeURIComponent(username)}`, { headers: { Accept: 'application/rss+xml, application/xml, text/xml' } });
      if (!response.ok) {
        return [];
      }

      const xml = await response.text();
      const cdata = (value: string): string => value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
      const channel = xml.split('<item>')[0];
      const tag = (name: string, source = channel): string => cdata(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`, 'i').exec(source)?.[1] ?? '');
      const title = tag('title');
      if (!title) {
        return [];
      }

      const items = xml.split('<item>').slice(1);
      return [{
        real_name: title.replace(/^Stories by\s+/i, '').replace(/\s+on Medium$/i, ''),
        bio: tag('description'),
        description: tag('description'),
        location: '',
        profile_url: tag('link') || `https://medium.com/@${username}`,
        total_posts: String((items.length) || ''),
        total_followers: '',
        total_likes: '',
        avatar: tag('url', tag('image') ? new RegExp('<image>[\\s\\S]*?</image>').exec(channel)?.[0] ?? '' : ''),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: username,
        latestPost: items[0] ? tag('title', items[0]) : '',
        latestPostDate: items[0] ? tag('pubDate', items[0]) : '',
        updatedAt: tag('lastBuildDate'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://medium.com/me/settings', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/m\/signin|\/signin/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
