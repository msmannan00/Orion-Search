import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, friends, posts } from './resource/misskey/misskey';

export class Misskey implements Crawler {
  readonly platform = 'misskey';
  readonly base = 'https://misskey.io';
  readonly loginUrl = 'https://misskey.io/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch('https://misskey.io/api/users/show', {
        method: 'POST',
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username }),
      });
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      if (!data?.id) {
        return [];
      }

      const fields: any[] = Array.isArray(data.fields) ? data.fields : [];
      const roles: any[] = Array.isArray(data.roles) ? data.roles : [];
      const verifiedLinks: any[] = Array.isArray(data.verifiedLinks) ? data.verifiedLinks : [];
      const pinned: any[] = Array.isArray(data.pinnedNoteIds) ? data.pinnedNoteIds : [];

      return [{
        real_name: data.name || data.username || username,
        bio: data.description ?? '',
        description: data.description ?? '',
        location: data.location ?? '',
        profile_url: data.url ?? `https://misskey.io/@${data.username ?? username}`,
        total_posts: String((data.notesCount ?? 0) || ''),
        total_followers: String((data.followersCount ?? 0) || ''),
        total_likes: '',
        avatar: data.avatarUrl ?? '',
        banner: data.bannerUrl ?? '',
        crawl_type: ['details', 'posts', 'followers', 'friends'],
        platform: this.platform,
        username: data.username ?? username,
        user_id: data.id ?? '',
        host: data.host ?? '',
        uri: data.uri ?? '',
        moved_to: data.movedTo ?? '',
        also_known_as: Array.isArray(data.alsoKnownAs) ? data.alsoKnownAs.join(', ') : '',
        notes_count: data.notesCount ?? 0,
        followers_count: data.followersCount ?? 0,
        birthday: data.birthday ?? '',
        lang: data.lang ?? '',
        is_bot: data.isBot ?? false,
        is_cat: data.isCat ?? false,
        is_locked: data.isLocked ?? false,
        is_silenced: data.isSilenced ?? false,
        is_limited: data.isLimited ?? false,
        is_suspended: data.isSuspended ?? false,
        public_reactions: data.publicReactions ?? false,
        followers_visibility: data.followersVisibility ?? '',
        online_status: data.onlineStatus ?? '',
        fields: fields.map((f: any) => `${f.name ?? ''}:${f.value ?? ''}`).filter((v: string) => v !== ':').join(' | '),
        verified_links: verifiedLinks.join(', '),
        roles: roles.map((r: any) => r.name ?? '').filter(Boolean).join(', '),
        pinned_notes_count: pinned.length,
        memo: data.memo ?? '',
        created_at: data.createdAt ?? '',
        updated_at: data.updatedAt ?? '',
        last_fetched_at: data.lastFetchedAt ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://misskey.io/api/i', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
