import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { posts } from './resource/nostr/nostr';
import { openSession } from './tab_management/tab.controller';

export class Nostr implements Crawler {
  readonly platform = 'nostr';
  readonly base = 'https://njump.me';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const npub = /(npub1[02-9ac-hj-np-z]{58})/i.exec(url ?? '')?.[1] ?? (/^npub1/i.test(username) ? username : '');
      if (!npub) {
        return [];
      }

      const tab = await openSession('https://njump.me/');
      if (!tab) {
        return [];
      }
      const response = await tab.fetch(`https://njump.me/${npub}`);
      await tab.close();
      if (!response.ok) {
        return [];
      }

      const html = response.body;
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? '');
      const displayName = meta('og:title') || decode(/<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(html)?.[1] ?? '');
      if (!displayName) {
        return [];
      }

      const nip05 = /([\w.+-]+@[\w.-]+\.[a-z]{2,})/i.exec(html)?.[1] ?? '';
      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://njump.me/${npub}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image'),
        banner: decode(/banner\\?&#34;:\\*&#34;(https?:\/\/[^\\"&]+)/i.exec(html)?.[1] ?? ''),
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: npub,
        nip05: nip05,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const signer = (globalThis as unknown as { nostr?: { getPublicKey?: () => Promise<string> } }).nostr;
      if (!signer?.getPublicKey) {
        return false;
      }

      return Boolean(await signer.getPublicKey());
    }
    catch {
      return false;
    }
  }
}
