import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { packageList, repositories } from './resource/npmjs/npmjs';

export class Npm implements Crawler {
  readonly platform = 'npm';
  readonly base = 'https://www.npmjs.com';
  readonly loginUrl = 'https://www.npmjs.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const count = Object.keys(await packageList(username)).length;
      if (!count) {
        return [];
      }

      return [{
        real_name: username,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://www.npmjs.com/~${username}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: username,
        package_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.npmjs.com/settings/profile', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
