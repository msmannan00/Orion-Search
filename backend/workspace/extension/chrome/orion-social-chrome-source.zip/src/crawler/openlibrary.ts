import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { projects, userLists } from './resource/openlibrary/openlibrary';

export class OpenLibrary implements Crawler {
  readonly platform = 'openlibrary';
  readonly base = 'https://openlibrary.org';
  readonly loginUrl = 'https://openlibrary.org/account/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const count = (await userLists(username)).length;
      if (!count) {
        return [];
      }

      return [{
        real_name: username,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://openlibrary.org/people/${username}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'projects'],
        platform: this.platform,
        username,
        list_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://openlibrary.org/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
