import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { namespaceTotal, projects } from './resource/openvsx/openvsx';

export class OpenVSX implements Crawler {
  readonly platform = 'openvsx';
  readonly base = 'https://open-vsx.org';
  readonly loginUrl = 'https://open-vsx.org/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const namespace = String(payload.username ?? '');
    if (!namespace) {
      return [];
    }

    try {
      const count = await namespaceTotal(namespace);
      if (!count) {
        return [];
      }

      return [{
        real_name: namespace,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://open-vsx.org/namespace/${namespace}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'projects'],
        platform: this.platform,
        username: namespace,
        extension_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://open-vsx.org/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
