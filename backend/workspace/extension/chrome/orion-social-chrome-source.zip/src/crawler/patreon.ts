import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityJson } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { posts, products } from './resource/patreon/patreon';

export class Patreon implements Crawler {
  readonly platform = 'patreon';
  readonly base = 'https://www.patreon.com';
  readonly loginUrl = 'https://www.patreon.com/login';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'products':
        return products(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.patreon.com/api/campaigns?filter[vanity]=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const entry: any = Array.isArray(payload?.data) ? payload.data[0] : null;
      const data: any = entry?.attributes;
      if (!data) {
        return [];
      }

      return [{
        real_name: data.name ?? username,
        bio: data.summary ? String(data.summary).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : (data.creation_name ?? ''),
        description: data.summary ? String(data.summary).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : (data.creation_name ?? ''),
        location: '',
        profile_url: `https://www.patreon.com/${data.vanity ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.avatar_photo_url ?? '',
        banner: data.cover_photo_url ?? '',
        crawl_type: ['details', 'posts', 'products'],
        platform: this.platform,
        username: data.vanity ?? username,
        patrons: data.patron_count ?? 0,
        creationName: data.creation_name ?? '',
        isNsfw: data.is_nsfw ?? false,
        createdAt: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityJson(tab, 'https://www.patreon.com/api/current_user', (data) =>
      data?.data?.id ? { loggedIn: true, username: String(data.data.attributes?.vanity || data.data.attributes?.full_name || '') } : null);
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.patreon.com/api/current_user', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.data?.id);
    }
    catch {
      return false;
    }
  }
}
