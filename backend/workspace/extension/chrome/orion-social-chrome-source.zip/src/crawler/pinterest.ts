import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, pollQuery, tabJson } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { images, pins, videos } from './resource/pinterest/pinterest';

export class Pinterest implements Crawler {
  readonly platform = 'pinterest';
  readonly base = 'https://www.pinterest.com';
  readonly loginUrl = 'https://www.pinterest.com/login/';
  readonly authwall = NO_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    username: '[data-test-id="header-profile"] a, a[href^="/"][data-test-id="header-profile"]',
    signedIn: ['[data-test-id="header-profile"]', 'div[data-test-id="header-avatar"]'],
    signedOut: ['[data-test-id="simple-login-button"]', '[data-test-id="login-button"]', 'a[href*="/login"]'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'pins':
        return pins(payload);
      case 'images':
        return images(payload);
      case 'videos':
        return videos(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.pinterest.com/${encodeURIComponent(username)}/`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => {
        const found = new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };

      const displayName = embedded('full_name') || meta('og:title') || title.replace(/\s*-\s*Profil.*$/i, '');
      if (!displayName || /^Pinterest$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: embedded('about') || meta('og:description'),
        description: embedded('about') || meta('og:description'),
        location: embedded('location'),
        profile_url: `https://www.pinterest.com/${embedded('username') || username}/`,
        total_posts: String((number('pin_count')) || ''),
        total_followers: String((number('follower_count')) || ''),
        total_likes: '',
        avatar: embedded('image_xlarge_url') || embedded('image_large_url') || meta('og:image'),
        banner: /"profile_cover"\s*:\s*\{[\s\S]{0,200}?"url"\s*:\s*"([^"]+)"/.exec(html)?.[1] ?? '',
        crawl_type: ['details', 'pins', 'images', 'videos'],
        platform: this.platform,
        username: embedded('username') || username,
        boards: number('board_count'),
        website: embedded('website_url'),
        verified: /"verified_identity"\s*:\s*\{[^}]*"verified"\s*:\s*true/.test(html),
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const data = await tabJson(tab, 'https://www.pinterest.com/resource/UserSessionResource/get/', { Accept: 'application/json' });
    const user = data?.resource_response?.data;
    if (user && (user.id || user.username)) {
      return { loggedIn: true, username: String(user.username || '') };
    }
    const dom = await pollQuery(tab, '[data-test-id="header-profile"], [data-test-id="header-avatar"], [data-test-id="simple-login-button"], [data-test-id="login-button"]', (items) => {
      if (items.some((item) => /header-profile|header-avatar/.test(item.testid))) {
        return { loggedIn: true, username: '' };
      }
      if (items.some((item) => /login-button/.test(item.testid))) {
        return NO_IDENTITY;
      }
      return null;
    }, 8);
    return dom || NO_IDENTITY;
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.pinterest.com/resource/UserSessionResource/get/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.resource_response?.data?.id);
    }
    catch {
      return false;
    }
  }
}
