import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { packageCount, repositories } from './resource/pubdev/pubdev';

export class PubDev implements Crawler {
  readonly platform = 'pubdev';
  readonly base = 'https://pub.dev';
  readonly loginUrl = 'https://pub.dev/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const publisher = String(payload.username ?? '');
    if (!publisher) {
      return [];
    }

    try {
      const count = await packageCount(publisher);
      if (!count) {
        return [];
      }

      return [{
        real_name: publisher,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://pub.dev/publishers/${publisher}/packages`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: publisher,
        package_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://pub.dev/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
