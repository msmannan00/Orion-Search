import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, tabJson } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { comments, connections, organizations, posts } from './resource/reddit/reddit';

export class Reddit implements Crawler {
  readonly platform = 'reddit';
  readonly base = 'https://www.reddit.com';
  readonly loginUrl = 'https://www.reddit.com/login/';
  readonly authwall = { ...NO_AUTH };
  readonly profiling = true;

  readonly loginMarkers = {
    username: 'a[href^="/user/"]',
    signedIn: ['a[href^="/user/"]', 'button#expand-user-drawer-button', 'faceplate-tracker[source="account_menu"]'],
    signedOut: ['a[href*="/login"]', 'a[href*="/register"]'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.reddit.com/user/${encodeURIComponent(username)}/about.json`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = payload?.data;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.subreddit?.title || data.name || username,
        bio: data.subreddit?.public_description ?? '',
        description: data.subreddit?.public_description ?? '',
        location: '',
        profile_url: `https://www.reddit.com/user/${data.name ?? username}`,
        total_posts: '',
        total_followers: String((data.subreddit?.subscribers ?? 0) || ''),
        total_likes: String((data.total_karma ?? 0) || ''),
        avatar: String(data.icon_img ?? data.snoovatar_img ?? '').split('?')[0],
        banner: String(data.subreddit?.banner_img ?? '').split('?')[0],
        crawl_type: ['details', 'posts', 'comments', 'organizations', 'connections'],
        platform: this.platform,
        username: data.name ?? username,
        id: data.id ?? '',
        display_name: data.subreddit?.display_name ?? '',
        display_name_prefixed: data.subreddit?.display_name_prefixed ?? '',
        subreddit_url: data.subreddit?.url ? `https://www.reddit.com${data.subreddit.url}` : '',
        total_karma: data.total_karma ?? 0,
        link_karma: data.link_karma ?? 0,
        comment_karma: data.comment_karma ?? 0,
        awardee_karma: data.awardee_karma ?? 0,
        awarder_karma: data.awarder_karma ?? 0,
        verified: data.verified ?? false,
        has_verified_email: data.has_verified_email ?? false,
        is_gold: data.is_gold ?? false,
        is_mod: data.is_mod ?? false,
        is_employee: data.is_employee ?? false,
        accept_followers: data.accept_followers ?? false,
        hide_from_robots: data.hide_from_robots ?? false,
        snoovatar_img: String(data.snoovatar_img ?? '').split('?')[0],
        community_icon: String(data.subreddit?.community_icon ?? '').split('?')[0],
        header_img: String(data.subreddit?.header_img ?? '').split('?')[0],
        primary_color: data.subreddit?.primary_color ?? '',
        key_color: data.subreddit?.key_color ?? '',
        over_18: data.subreddit?.over_18 ?? false,
        subreddit_type: data.subreddit?.subreddit_type ?? '',
        previous_names: Array.isArray(data.subreddit?.previous_names) ? data.subreddit.previous_names : [],
        created_at: data.created_utc ? new Date(data.created_utc * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const data = await tabJson(tab, 'https://www.reddit.com/api/me.json', { Accept: 'application/json' });
    const name = data?.data?.name;
    return name ? { loggedIn: true, username: String(name) } : NO_IDENTITY;
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.reddit.com/api/me.json', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.data?.name);
    }
    catch {
      return false;
    }
  }
}
