import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function loc(value: any): string {
  if (value == null) {
    return '';
  }
  if (typeof value === 'string') {
    return value;
  }
  if (typeof value === 'object') {
    return String(value['en-US'] ?? value['en'] ?? Object.values(value)[0] ?? '');
  }
  return String(value);
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function search(username: string, page: number, size: number): Promise<any> {
  const response = await fetch(`https://addons.mozilla.org/api/v5/addons/search/?author=${encodeURIComponent(username)}&page=${page}&page_size=${size}&sort=users`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function authorCount(username: string): Promise<number> {
  const data = await search(username, 1, 1);
  return Number(data?.count ?? 0);
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const page = Math.floor(offset / limit) + 1;
    const data = await search(username, page, limit);
    const total = Number(data?.count ?? 0);
    const results: any[] = Array.isArray(data?.results) ? data.results : [];
    if (!results.length) {
      return EMPTY;
    }

    const items = results.map((addon: any): social_resource => {
      const slug = String(addon.slug ?? addon.id ?? '');
      const ratings = addon.ratings ?? {};
      const categories = addon.categories ?? {};
      const catList = Array.isArray(categories) ? categories : Object.values(categories).flat();
      return {
        type: 'projects',
        resource_id: String(addon.guid ?? slug),
        url: addon.url ?? `https://addons.mozilla.org/firefox/addon/${slug}/`,
        parent_url: `https://addons.mozilla.org/firefox/user/${username}/`,
        title: loc(addon.name) || slug,
        caption: clean(loc(addon.summary)),
        author: username,
        datetime: addon.last_updated ?? addon.created ?? '',
        media_type: 'addon',
        media_url: '',
        thumbnail_url: addon.icon_url ?? '',
        likes: String((ratings.count ?? 0) || ''),
        shares: '',
        views: String((addon.average_daily_users ?? 0) || ''),
        name: slug,
        addon_name: loc(addon.name),
        description: clean(loc(addon.summary) || loc(addon.description)),
        addon_type: addon.type ?? '',
        guid: addon.guid ?? '',
        homepage: loc(addon.homepage),
        average_daily_users: addon.average_daily_users ?? 0,
        weekly_downloads: addon.weekly_downloads ?? 0,
        rating_average: ratings.average ?? 0,
        rating_count: ratings.count ?? 0,
        categories: catList.map((cat: any) => String(cat)).join(', '),
        tags: Array.isArray(addon.tags) ? addon.tags.join(', ') : '',
        status: addon.status ?? '',
        last_updated: addon.last_updated ?? '',
        created: addon.created ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + results.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
