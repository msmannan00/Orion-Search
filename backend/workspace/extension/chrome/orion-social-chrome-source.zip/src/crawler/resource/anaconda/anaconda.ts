import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function packages(username: string): Promise<any[]> {
  const response = await fetch(`https://api.anaconda.org/packages/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data) ? data : [];
}

async function profile(username: string): Promise<any> {
  const response = await fetch(`https://api.anaconda.org/user/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function details(username: string): Promise<social_profile_details[]> {
  const pkgs = await packages(username);
  if (!pkgs.length) {
    return [];
  }

  const user = await profile(username) ?? {};
  const downloads = pkgs.reduce((sum: number, pkg: any) => sum + Number(pkg?.ndownloads ?? 0), 0);
  return [{
    real_name: clean(user.name) || username,
    bio: clean(user.description),
    description: clean(user.description),
    location: clean(user.location),
    profile_url: `https://anaconda.org/${username}`,
    total_posts: String(pkgs.length || ''),
    total_followers: '',
    total_likes: '',
    avatar: '',
    banner: '',
    crawl_type: ['details', 'repositories'],
    platform: 'anaconda',
    username: username,
    package_count: pkgs.length,
    total_downloads: downloads,
    company: clean(user.company),
    created_at: user.created_at ?? '',
  }];
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const all = await packages(username);
    if (!all.length) {
      return EMPTY;
    }

    all.sort((a: any, b: any) => Number(b?.ndownloads ?? 0) - Number(a?.ndownloads ?? 0));
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = all.slice(offset, offset + limit);

    const items = slice.map((pkg: any): social_resource => {
      const name = String(pkg.name ?? '');
      const platforms = Array.isArray(pkg.conda_platforms) ? pkg.conda_platforms : (Array.isArray(pkg.platforms) ? pkg.platforms : []);
      const types = Array.isArray(pkg.package_types) ? pkg.package_types : [];
      return {
        type: 'repositories',
        resource_id: String(pkg.full_name ?? `${username}/${name}`),
        url: pkg.html_url ?? `https://anaconda.org/${username}/${name}`,
        parent_url: `https://anaconda.org/${username}`,
        title: name,
        caption: clean(pkg.summary),
        author: username,
        datetime: '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: String((pkg.ndownloads ?? 0) || ''),
        name,
        description: clean(pkg.summary || pkg.description),
        latest_version: pkg.latest_version ?? '',
        license: pkg.license ?? '',
        home: pkg.home ?? '',
        dev_url: pkg.dev_url ?? '',
        doc_url: pkg.doc_url ?? '',
        source_git_url: pkg.source_git_url ?? '',
        ndownloads: pkg.ndownloads ?? 0,
        package_types: types.join(', '),
        platforms: platforms.join(', '),
        versions_count: Array.isArray(pkg.versions) ? pkg.versions.length : 0,
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < all.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
