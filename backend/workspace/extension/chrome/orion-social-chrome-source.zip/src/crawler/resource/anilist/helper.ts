import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { Cursor } from './model';

export async function graphql(tab: TabController, query: string, variables: Record<string, unknown>): Promise<any> {
  try {
    const response = await tab.fetch('https://graphql.anilist.co', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables }),
    });
    return response.ok ? (JSON.parse(response.body))?.data ?? null : null;
  }
  catch {
    return null;
  }
}

export async function userId(tab: TabController, username: string): Promise<number> {
  const data = await graphql(tab, 'query ($name: String) { User(name: $name) { id } }', { name: username });
  return Number(data?.User?.id ?? 0);
}

export function parseCursor(payload: CrawlPayload): Cursor {
  try {
    const raw = String(payload.cursor ?? '').trim();
    if (!raw) {
      return { p: 1, id: 0 };
    }
    const parsed = JSON.parse(raw);
    const p = Math.floor(Number(parsed?.p));
    const id = Math.floor(Number(parsed?.id));
    return { p: Number.isFinite(p) && p > 1 ? p : 1, id: Number.isFinite(id) && id > 0 ? id : 0 };
  }
  catch {
    return { p: 1, id: 0 };
  }
}

export async function pagedQuery(tab: TabController, payload: CrawlPayload, username: string, field: string, args: string, selection: string): Promise<{ id: number; entries: any[]; nextCursor?: string }> {
  const cursor = parseCursor(payload);
  const id = cursor.id || await userId(tab, username);
  if (!id) {
    return { id: 0, entries: [] };
  }

  const perPage = limitOf(payload, 25, 50);
  const data = await graphql(tab, `query ($id: Int!, $page: Int!, $perPage: Int!) { Page(page: $page, perPage: $perPage) { pageInfo { hasNextPage currentPage } ${field}(userId: $id${args}) { ${selection} } } }`, { id, page: cursor.p, perPage });

  const entries = (Array.isArray(data?.Page?.[field]) ? data.Page[field] : []) as any[];
  const hasNext = Boolean(data?.Page?.pageInfo?.hasNextPage) && entries.length > 0;
  return { id, entries, nextCursor: hasNext ? JSON.stringify({ p: cursor.p + 1, id } as Cursor) : undefined };
}

export function page(items: social_resource[], nextCursor?: string): CrawlPage {
  return { items, next_cursor: items.length && nextCursor ? nextCursor : undefined };
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function text(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}

export function person(username: string, type: 'followers' | 'friends', entry: any): social_resource {
  const anime = entry.statistics?.anime ?? {};
  const manga = entry.statistics?.manga ?? {};
  const options = entry.options ?? {};
  return {
    type,
    resource_id: String(entry.id ?? ''),
    url: entry.siteUrl ?? `https://anilist.co/user/${entry.name ?? ''}`,
    parent_url: `https://anilist.co/user/${username}`,
    title: entry.name ?? '',
    caption: text(entry.about).slice(0, 600),
    author: entry.name ?? '',
    datetime: stamp(entry.createdAt),
    media_type: 'user',
    media_url: entry.siteUrl ?? '',
    thumbnail_url: entry.avatar?.large ?? '',
    likes: '',
    shares: '',
    views: '',
    user_id: entry.id ?? 0,
    name: entry.name ?? '',
    about: text(entry.about).slice(0, 1000),
    avatar: entry.avatar?.large ?? '',
    avatar_medium: entry.avatar?.medium ?? '',
    banner: entry.bannerImage ?? '',
    donator_tier: entry.donatorTier ?? 0,
    donator_badge: entry.donatorBadge ?? '',
    moderator_roles: Array.isArray(entry.moderatorRoles) ? entry.moderatorRoles.join(', ') : '',
    is_follower: entry.isFollower ?? false,
    is_blocked: entry.isBlocked ?? false,
    unread_notifications: entry.unreadNotificationCount ?? 0,
    title_language: options.titleLanguage ?? '',
    display_adult_content: options.displayAdultContent ?? false,
    airing_notifications: options.airingNotifications ?? false,
    profile_color: options.profileColor ?? '',
    timezone: options.timezone ?? '',
    activity_merge_time: options.activityMergeTime ?? 0,
    staff_name_language: options.staffNameLanguage ?? '',
    anime_count: anime.count ?? 0,
    anime_mean_score: anime.meanScore ?? 0,
    anime_standard_deviation: anime.standardDeviation ?? 0,
    anime_minutes_watched: anime.minutesWatched ?? 0,
    anime_episodes_watched: anime.episodesWatched ?? 0,
    manga_count: manga.count ?? 0,
    manga_mean_score: manga.meanScore ?? 0,
    manga_standard_deviation: manga.standardDeviation ?? 0,
    manga_chapters_read: manga.chaptersRead ?? 0,
    manga_volumes_read: manga.volumesRead ?? 0,
    created_at: stamp(entry.createdAt),
    updated_at: stamp(entry.updatedAt),
  };
}
