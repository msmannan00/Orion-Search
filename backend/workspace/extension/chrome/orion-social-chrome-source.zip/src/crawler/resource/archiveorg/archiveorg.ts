import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

function field(username: string): string {
  return username.includes('@') ? 'uploader' : 'creator';
}

async function search(username: string, page: number, rows: number): Promise<any> {
  const query = `${field(username)}:(${username})`;
  const url = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(query)}&fl[]=identifier&fl[]=title&fl[]=mediatype&fl[]=publicdate&fl[]=downloads&fl[]=description&fl[]=creator&sort[]=publicdate+desc&rows=${rows}&page=${page}&output=json`;
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function itemCount(username: string): Promise<number> {
  const data = await search(username, 1, 0);
  return Number(data?.response?.numFound ?? 0);
}

export async function details(username: string): Promise<social_profile_details[]> {
  const count = await itemCount(username);
  if (!count) {
    return [];
  }

  return [{
    real_name: username,
    bio: '',
    description: '',
    location: '',
    profile_url: username.includes('@') ? `https://archive.org/details/@${username.split('@')[0]}` : `https://archive.org/search?query=creator%3A%28${encodeURIComponent(username)}%29`,
    total_posts: String(count || ''),
    total_followers: '',
    total_likes: '',
    avatar: '',
    banner: '',
    crawl_type: ['details', 'posts'],
    platform: 'archiveorg',
    username,
    item_count: count,
    matched_field: field(username),
  }];
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const rows = limitOf(payload, 25, 100);
    const data = await search(username, page, rows);
    const total = Number(data?.response?.numFound ?? 0);
    const docs: any[] = Array.isArray(data?.response?.docs) ? data.response.docs : [];
    if (!docs.length) {
      return EMPTY;
    }

    const items = docs.map((doc: any): social_resource => {
      const identifier = String(doc.identifier ?? '');
      const creator = Array.isArray(doc.creator) ? doc.creator.join(', ') : (doc.creator ?? '');
      return {
        type: 'posts',
        resource_id: identifier,
        url: `https://archive.org/details/${identifier}`,
        parent_url: `https://archive.org/details/@${username.split('@')[0]}`,
        title: clean(Array.isArray(doc.title) ? doc.title[0] : doc.title) || identifier,
        caption: clean(Array.isArray(doc.description) ? doc.description[0] : doc.description),
        author: clean(creator) || username,
        datetime: doc.publicdate ?? '',
        media_type: doc.mediatype ?? 'item',
        media_url: '',
        thumbnail_url: `https://archive.org/services/img/${identifier}`,
        likes: '',
        shares: '',
        views: String((doc.downloads ?? 0) || ''),
        content: clean(Array.isArray(doc.description) ? doc.description[0] : doc.description),
        item_mediatype: doc.mediatype ?? '',
        creator: clean(creator),
        downloads: doc.downloads ?? 0,
        public_date: doc.publicdate ?? '',
      };
    }).filter((item) => item.url && item.resource_id);

    const hasMore = page * rows < total;
    return { items, next_cursor: items.length && hasMore ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
