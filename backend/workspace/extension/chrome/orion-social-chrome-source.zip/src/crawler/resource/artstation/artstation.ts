import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, collect, people, text } from './helper';

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const username = String(payload.username ?? '');
    if (!username) {
      return EMPTY;
    }

    const tab = await openSession('https://www.artstation.com/');
    if (!tab) {
      return EMPTY;
    }

    try {
      const { entries: items, next_cursor } = await collect(tab, username, 'projects', payload, limitOf(payload, 25, 50));
      const fulls = await Promise.all(items.map((item: any) => api(tab, `/projects/${encodeURIComponent(item.hash_id ?? '')}.json`)));

      const resources = items.map((item: any, index: number): social_resource => {
        const full: any = fulls[index] ?? {};
        const assets: any[] = Array.isArray(full.assets) ? full.assets : [];
        const icons = item.icons ?? {};
        return {
          type: 'projects',
          resource_id: String(item.id ?? ''),
          url: item.permalink ?? full.permalink ?? '',
          parent_url: `https://www.artstation.com/${username}`,
          title: item.title ?? '',
          caption: text(item.description ?? full.description),
          author: full.user?.username ?? username,
          datetime: item.published_at ?? item.created_at ?? '',
          media_type: assets[0]?.asset_type ?? 'image',
          media_url: assets[0]?.image_url ?? full.cover_url ?? '',
          thumbnail_url: item.cover?.thumb_url ?? item.cover?.small_square_url ?? full.cover_url ?? '',
          likes: String((full.likes_count ?? item.likes_count ?? 0) || ''),
          shares: '',
          views: String((full.views_count ?? 0) || ''),
          project_id: item.id ?? 0,
          hash_id: item.hash_id ?? '',
          slug: item.slug ?? '',
          user_id: item.user_id ?? 0,
          user_name: full.user?.username ?? username,
          user_full_name: full.user?.full_name ?? '',
          user_headline: text(full.user?.headline),
          user_avatar: full.user?.large_avatar_url ?? full.user?.medium_avatar_url ?? '',
          user_is_pro: full.user?.pro_member ?? false,
          user_is_staff: full.user?.is_staff ?? false,
          description: text(item.description ?? full.description),
          views_count: full.views_count ?? 0,
          likes_count: full.likes_count ?? item.likes_count ?? 0,
          comments_count: full.comments_count ?? 0,
          assets_count: item.assets_count ?? assets.length,
          asset_urls: assets.map((asset: any) => asset?.image_url ?? '').filter(Boolean).join(', '),
          asset_types: [...new Set(assets.map((asset: any) => asset?.asset_type ?? '').filter(Boolean))].join(', '),
          asset_titles: assets.map((asset: any) => text(asset?.title)).filter(Boolean).join(' | '),
          asset_width: assets[0]?.width ?? 0,
          asset_height: assets[0]?.height ?? 0,
          has_image: icons.image ?? false,
          has_video: icons.video ?? false,
          has_video_clip: icons.video_clip ?? false,
          has_model3d: icons.model3d ?? false,
          has_marmoset: icons.marmoset ?? false,
          has_pano: icons.pano ?? false,
          tags: Array.isArray(full.tags) ? full.tags.map((tag: any) => tag?.name ?? tag).filter(Boolean).join(', ') : '',
          categories: Array.isArray(full.categories) ? full.categories.map((entry: any) => entry?.name ?? '').filter(Boolean).join(', ') : '',
          mediums: Array.isArray(full.mediums) ? full.mediums.map((entry: any) => entry?.name ?? '').filter(Boolean).join(', ') : '',
          medium: full.medium?.name ?? '',
          software: Array.isArray(full.software_items) ? full.software_items.map((entry: any) => entry?.name ?? '').filter(Boolean).join(', ') : '',
          collections: Array.isArray(full.collections) ? full.collections.map((entry: any) => entry?.name ?? '').filter(Boolean).join(', ') : '',
          cover_url: full.cover_url ?? '',
          cover_asset_id: item.cover_asset_id ?? 0,
          is_editor_pick: full.editor_pick ?? false,
          is_adult: item.adult_content ?? false,
          is_admin_adult: item.admin_adult_content ?? false,
          is_visible: full.visible ?? true,
          is_promotional: full.is_promotional ?? false,
          is_suppressed: full.suppressed ?? false,
          hide_as_adult: item.hide_as_adult ?? false,
          permalink: item.permalink ?? '',
          created_at: item.created_at ?? '',
          updated_at: item.updated_at ?? '',
          published_at: item.published_at ?? '',
        };
      }).filter((item) => item.url);

      return { items: resources, next_cursor: resources.length ? next_cursor : undefined };
    }
    finally {
      await tab.close();
    }
  }
  catch {
    return EMPTY;
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  return people(payload, 'followers');
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  return people(payload, 'friends');
}

