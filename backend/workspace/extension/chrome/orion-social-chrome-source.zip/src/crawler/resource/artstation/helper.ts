import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, MAX_UPSTREAM_PAGES } from './constant';
import { Cursor, Collected } from './model';

export async function api(tab: TabController, path: string): Promise<any> {
  const response = await tab.fetch(`https://www.artstation.com${path}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  try {
    return JSON.parse(response.body);
  }
  catch {
    return null;
  }
}

export function text(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}

export function positive(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : fallback;
}

export function parseCursor(payload: CrawlPayload): Cursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { page: 1, offset: 0, seen: 0 };
  }
  try {
    const parsed = JSON.parse(raw);
    return { page: Math.max(1, positive(parsed?.page, 1)), offset: positive(parsed?.offset, 0), seen: positive(parsed?.seen, 0) };
  }
  catch {
    return { page: 1, offset: 0, seen: 0 };
  }
}

export async function collect(tab: TabController, username: string, resource: string, payload: CrawlPayload, limit: number): Promise<Collected> {
  const cursor = parseCursor(payload);
  const entries: any[] = [];
  let total: number | null = null;
  let exhausted = false;

  for (let fetched = 0; fetched < MAX_UPSTREAM_PAGES && entries.length < limit; fetched++) {
    const list = await api(tab, `/users/${encodeURIComponent(username)}/${resource}.json?page=${cursor.page}`);
    const data = (Array.isArray(list?.data) ? list.data : []) as any[];
    const count = Number(list?.total_count);
    if (Number.isFinite(count)) {
      total = count;
    }
    if (!data.length || cursor.offset >= data.length) {
      exhausted = true;
      break;
    }

    const take = data.slice(cursor.offset, cursor.offset + (limit - entries.length));
    entries.push(...take);
    cursor.seen += take.length;
    if (cursor.offset + take.length >= data.length) {
      cursor.page += 1;
      cursor.offset = 0;
    }
    else {
      cursor.offset += take.length;
    }
  }

  const more = !exhausted && (cursor.offset > 0 || total === null || cursor.seen < total);
  return { entries, next_cursor: entries.length && more ? JSON.stringify(cursor) : undefined };
}

export function person(username: string, type: 'followers' | 'friends', entry: any): social_resource {
  const skills: any[] = Array.isArray(entry.skills) ? entry.skills : [];
  const software: any[] = Array.isArray(entry.software_items) ? entry.software_items : [];
  const samples: any[] = Array.isArray(entry.sample_projects) ? entry.sample_projects : [];
  const handle = entry.username ?? entry.subdomain ?? '';
  return {
    type,
    resource_id: String(entry.id ?? ''),
    url: handle ? `https://www.artstation.com/${handle}` : '',
    parent_url: `https://www.artstation.com/${username}`,
    title: entry.full_name ?? handle,
    caption: text(entry.headline),
    author: handle,
    datetime: '',
    media_type: 'user',
    media_url: handle ? `https://www.artstation.com/${handle}` : '',
    thumbnail_url: entry.large_avatar_url ?? entry.medium_avatar_url ?? '',
    likes: '',
    shares: '',
    views: '',
    user_id: entry.id ?? 0,
    username: handle,
    subdomain: entry.subdomain ?? '',
    full_name: entry.full_name ?? '',
    headline: text(entry.headline),
    city: entry.city ?? '',
    country: entry.country ?? '',
    location: entry.location ?? '',
    followers_count: entry.followers_count ?? 0,
    avatar: entry.large_avatar_url ?? '',
    avatar_medium: entry.medium_avatar_url ?? '',
    avatar_file: entry.avatar_file_name ?? '',
    cover_url: entry.default_cover_url ?? '',
    cover_file: entry.cover_file_name ?? '',
    is_pro_member: entry.pro_member ?? false,
    is_plus_member: entry.is_plus_member ?? false,
    is_staff: entry.is_staff ?? false,
    is_studio_account: entry.is_studio_account ?? false,
    is_school_account: entry.is_school_account ?? false,
    is_artist: entry.artist_role ?? false,
    has_recruiter_badge: entry.has_recruiter_badge ?? false,
    available_full_time: entry.available_full_time ?? false,
    available_contract: entry.available_contract ?? false,
    available_freelance: entry.available_freelance ?? false,
    availability: entry.availability ?? '',
    followed: entry.followed ?? false,
    skills: skills.map((skill: any) => skill?.name ?? '').filter(Boolean).join(', '),
    skills_count: skills.length,
    software: software.map((entry_item: any) => entry_item?.name ?? '').filter(Boolean).join(', '),
    software_count: software.length,
    sample_projects: samples.filter((sample: any) => typeof sample === 'string').join(', '),
    sample_count: samples.length,
  };
}

export async function people(payload: CrawlPayload, type: 'followers' | 'friends'): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }
  const tab = await openSession('https://www.artstation.com/');
  if (!tab) {
    return EMPTY;
  }
  try {
    const { entries, next_cursor } = await collect(tab, username, type === 'friends' ? 'following' : type, payload, limitOf(payload, 25, 100));
    const items = entries.map((entry: any) => person(username, type, entry)).filter((item) => item.url);
    return { items, next_cursor: items.length ? next_cursor : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
