export interface Cursor {
  page: number;
  offset: number;
  seen: number;
}

export interface Collected {
  entries: any[];
  next_cursor?: string;
}
