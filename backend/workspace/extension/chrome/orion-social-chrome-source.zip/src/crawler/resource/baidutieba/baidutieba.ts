import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, MAX_UPSTREAM_PAGES } from './constant';
import { position, thread, threadPage } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://tieba.baidu.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 25);
    let { pn, skip } = position(payload);
    const items: social_resource[] = [];
    let nextCursor: string | undefined;

    for (let fetched = 0; fetched < MAX_UPSTREAM_PAGES && items.length < limit; fetched++) {
      const page = await threadPage(tab, username, pn);
      if (!page) {
        break;
      }

      const mapped = page.list.map((entry: any) => thread(username, entry)).filter((item) => item.url);
      const taken = mapped.slice(skip, skip + (limit - items.length));
      items.push(...taken);

      const consumed = skip + taken.length;
      if (consumed < mapped.length) {
        nextCursor = JSON.stringify({ pn, skip: consumed });
        break;
      }
      if (!page.hasMore) {
        nextCursor = undefined;
        break;
      }

      pn += 1;
      skip = 0;
      nextCursor = JSON.stringify({ pn, skip });
    }

    return { items, next_cursor: items.length && nextCursor ? nextCursor : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
