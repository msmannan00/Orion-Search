import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { Position } from './model';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function positive(value: unknown, fallback: number): number {
  const parsed = Math.floor(Number(value));
  return Number.isFinite(parsed) && parsed >= fallback ? parsed : fallback;
}

export function position(payload: CrawlPayload): Position {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { pn: 1, skip: 0 };
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return { pn: positive(parsed.pn, 1), skip: positive(parsed.skip, 0) };
    }
    return { pn: positive(parsed, 1), skip: 0 };
  }
  catch {
    return { pn: positive(raw, 1), skip: 0 };
  }
}

export async function threadPage(tab: TabController, username: string, pn: number): Promise<{ list: any[]; hasMore: boolean } | null> {
  const response = await tab.fetch(`https://tieba.baidu.com/home/get/getthread?un=${encodeURIComponent(username)}&pn=${pn}&id=&_=${Date.now()}`, {
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) {
    return null;
  }

  const data = JSON.parse(response.body);
  const list = (Array.isArray(data?.data?.thread_list) ? data.data.thread_list : []) as any[];
  return { list, hasMore: Boolean(Number(data?.data?.has_more)) };
}

export function thread(username: string, entry: any): social_resource {
  const media: any[] = Array.isArray(entry.media) ? entry.media : [];
  return {
    type: 'posts',
    resource_id: String(entry.thread_id ?? entry.id ?? ''),
    url: entry.thread_id ? `https://tieba.baidu.com/p/${entry.thread_id}` : '',
    parent_url: `https://tieba.baidu.com/home/main?un=${encodeURIComponent(username)}`,
    title: clean(entry.title),
    caption: clean(entry.abstract ?? entry.content),
    author: entry.author?.name_show ?? entry.author?.name ?? username,
    datetime: stamp(entry.create_time ?? entry.post_time),
    media_type: media.length ? 'image' : 'text',
    media_url: media[0]?.big_pic ?? media[0]?.small_pic ?? '',
    thumbnail_url: media[0]?.small_pic ?? '',
    likes: String((entry.agree?.agree_num ?? 0) || ''),
    shares: String((entry.share_num ?? 0) || ''),
    views: String((entry.view_num ?? 0) || ''),
    thread_id: entry.thread_id ?? entry.id ?? '',
    post_id: entry.post_id ?? '',
    title_text: clean(entry.title),
    abstract: clean(entry.abstract),
    content: clean(entry.content),
    forum_id: entry.forum_id ?? entry.fid ?? '',
    forum_name: entry.forum_name ?? entry.fname ?? '',
    forum_url: entry.forum_name ? `https://tieba.baidu.com/f?kw=${encodeURIComponent(entry.forum_name)}` : '',
    reply_num: entry.reply_num ?? 0,
    view_num: entry.view_num ?? 0,
    share_num: entry.share_num ?? 0,
    agree_num: entry.agree?.agree_num ?? 0,
    disagree_num: entry.agree?.disagree_num ?? 0,
    is_top: Boolean(entry.is_top),
    is_good: Boolean(entry.is_good),
    is_ntitle: Boolean(entry.is_ntitle),
    is_video: Boolean(entry.video_info),
    video_url: entry.video_info?.video_url ?? '',
    video_duration: entry.video_info?.video_duration ?? 0,
    media_count: media.length,
    media_urls: media.map((item: any) => item?.big_pic ?? item?.small_pic ?? '').filter(Boolean).join(', '),
    author_id: entry.author?.id ?? '',
    author_name: entry.author?.name ?? '',
    author_show_name: entry.author?.name_show ?? '',
    author_portrait: entry.author?.portrait ? `https://himg.bdimg.com/sys/portrait/item/${entry.author.portrait}` : '',
    create_time: stamp(entry.create_time),
    post_time: stamp(entry.post_time),
    last_time: stamp(entry.last_time_int),
  };
}
