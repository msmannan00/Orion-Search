import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const MAX_TRALBUMS_PER_PAGE = 10;
