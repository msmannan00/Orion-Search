import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { BandcampCursor } from './model';

export function subdomain(payload: CrawlPayload): string {
  return /^https?:\/\/(?!www\.)([^./]+)\.bandcamp\.com/i.exec(payload.url ?? '')?.[1] ?? String(payload.username ?? '');
}

export function decode(value: string): string {
  return value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function parseCursor(payload: CrawlPayload): BandcampCursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { band_id: 0, offset: 0, skip: 0 };
  }

  try {
    const parsed = JSON.parse(raw);
    const num = (value: unknown): number => {
      const n = Math.floor(Number(value));
      return Number.isFinite(n) && n > 0 ? n : 0;
    };
    return { band_id: num(parsed?.band_id), offset: num(parsed?.offset), skip: num(parsed?.skip) };
  }
  catch {
    return { band_id: 0, offset: 0, skip: 0 };
  }
}

export function nextCursor(cursor: BandcampCursor, total: number, count: number): string | undefined {
  return count > 0 && cursor.offset < total ? JSON.stringify(cursor) : undefined;
}

export async function bandId(host: string): Promise<number> {
  try {
    const response = await fetch(`https://${host}.bandcamp.com/music`);
    if (!response.ok) {
      return 0;
    }

    const html = await response.text();
    const items = /data-client-items="([^"]+)"/.exec(html)?.[1];
    if (items) {
      const parsed = JSON.parse(decode(items));
      const found = Array.isArray(parsed) ? parsed.find((entry: any) => entry?.band_id) : null;
      if (found?.band_id) {
        return Number(found.band_id);
      }
    }
    return Number(/"band_id"\s*:\s*(\d+)/.exec(html)?.[1] ?? /data-band-id="(\d+)"/.exec(html)?.[1] ?? 0);
  }
  catch {
    return 0;
  }
}

export async function api(path: string): Promise<any> {
  try {
    const response = await fetch(`https://bandcamp.com/api/mobile/24/${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(await response.text()) : null;
  }
  catch {
    return null;
  }
}

export function tralbum(id: number, item: any): Promise<any> {
  return api(`tralbum_details?band_id=${id}&tralbum_id=${item.item_id}&tralbum_type=${String(item.item_type ?? 'album').charAt(0)}`);
}

export function art(id: unknown): string {
  return id ? `https://f4.bcbits.com/img/a${id}_10.jpg` : '';
}

export async function discography(payload: CrawlPayload, cursor: BandcampCursor): Promise<{ id: number; band: any; list: any[] }> {
  const host = subdomain(payload);
  if (!host) {
    return { id: 0, band: null, list: [] };
  }

  const id = cursor.band_id || await bandId(host);
  if (!id) {
    return { id: 0, band: null, list: [] };
  }

  const band = await api(`band_details?band_id=${id}`);
  return { id, band, list: Array.isArray(band?.discography) ? band.discography : [] };
}
