import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { ORIGIN, EMPTY, GRAPHQL_PAGE } from './constant';
import { CookieApi } from './model';
import { bcp, build, cursorOf, store, teamProjects, userProjects } from './helper';

export const COOKIE_API = ((globalThis as { browser?: CookieApi }).browser ?? (globalThis as { chrome?: CookieApi }).chrome) as CookieApi | undefined;

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${ORIGIN}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, GRAPHQL_PAGE, 100);
    const cursor = cursorOf(payload);

    if (!cursor.offset) {
      const token = await bcp();
      const user = token ? await userProjects(tab, username, cursor.after, limit, token) : null;
      if (user) {
        return build(tab, username, user.list, user.next);
      }
      if (cursor.after) {
        return EMPTY;
      }
    }

    const team = await teamProjects(tab, username, limit, cursor.offset);
    if (team) {
      return build(tab, username, team.list, team.next);
    }
    if (cursor.offset) {
      return EMPTY;
    }

    const data = await store(tab, `${ORIGIN}/${encodeURIComponent(username)}/projects`);
    const work: any = data?.profile?.activeSection?.work;
    const list: any[] = work?.profileProjects ?? data?.team?.section_content ?? [];
    if (!Array.isArray(list) || !list.length) {
      return EMPTY;
    }

    const page = list.slice(0, limit);
    let next: string | undefined;
    if (Array.isArray(work?.profileProjects)) {
      next = page.length < list.length ? JSON.stringify({ after: btoa(String(page.length)) }) : work.hasMore && work.cursor ? JSON.stringify({ after: String(work.cursor) }) : undefined;
    }
    return build(tab, username, page, next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
