import { CrawlPage } from '../../../app/extension/model/extension.model';

export const ORIGIN = 'https://www.behance.net';

export const EMPTY: CrawlPage = { items: [] };

export const GRAPHQL_PAGE = 20;

export const FILL_GUARD = 5;

export const PROJECTS_QUERY = `query GetProfileProjects($username: String, $after: String, $first: Int) {
  user(username: $username) {
    profileProjects(first: $first, after: $after) {
      pageInfo { endCursor hasNextPage }
      nodes {
        __typename id oid name url slug publishedOn modifiedOn premium isPrivate isBoosted isFlagged isOwner isFounder
        publishStatus privacyLevel hasMatureContent matureAccess profileSectionId
        colors { r g b }
        covers { size_202 { url } size_404 { url } size_808 { url } size_max_808 { url } size_original { url } }
        fields { id label slug url }
        tools { id title category }
        sourceFiles { oid }
        stats { appreciations { all } views { all } comments { all } }
        owners {
          id username firstName lastName displayName url occupation company location city state country createdOn
          images { size_50 { url } size_276 { url } }
          stats { followers appreciations views comments }
        }
      }
    }
  }
}`;
