import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { ORIGIN, EMPTY, GRAPHQL_PAGE, FILL_GUARD, PROJECTS_QUERY } from './constant';
import { Cursor, GraphqlPage } from './model';
import { COOKIE_API } from './behance';

export function cursorOf(payload: CrawlPayload): Cursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { after: '', offset: '' };
  }

  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return { after: String(parsed.after ?? ''), offset: String(parsed.offset ?? '') };
    }
    return { after: raw, offset: '' };
  }
  catch {
    return { after: raw, offset: '' };
  }
}

export async function store(tab: TabController, url: string): Promise<any> {
  if (!url) {
    return null;
  }

  try {
    const response = await tab.fetch(url);
    if (!response.ok) {
      return null;
    }

    const html = response.body;
    const raw = /<script[^>]*id="beconfig-store_state"[^>]*>([\s\S]*?)<\/script>/i.exec(html)?.[1];
    return raw ? JSON.parse(raw) : null;
  }
  catch {
    return null;
  }
}

export async function bcp(): Promise<string> {
  const cookies = COOKIE_API?.cookies;
  if (!cookies?.get || !cookies.set) {
    return '';
  }

  try {
    const existing = await cookies.get({ url: `${ORIGIN}/`, name: 'bcp' });
    if (existing?.value) {
      return existing.value;
    }

    const value = globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
    await cookies.set({ url: `${ORIGIN}/`, name: 'bcp', value, path: '/', secure: true, expirationDate: Math.floor(Date.now() / 1000) + 86400 });
    return value;
  }
  catch {
    return '';
  }
}

export async function graphqlProjects(tab: TabController, username: string, after: string, first: number, token: string): Promise<GraphqlPage | null> {
  try {
    const response = await tab.fetch(`${ORIGIN}/v3/graphql`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-BCP': token, 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ query: PROJECTS_QUERY, variables: { username, after: after || null, first } }),
    });
    if (!response.ok) {
      return null;
    }

    const connection = (JSON.parse(response.body))?.data?.user?.profileProjects;
    if (!connection || !Array.isArray(connection.nodes)) {
      return null;
    }

    return { nodes: connection.nodes, endCursor: String(connection.pageInfo?.endCursor ?? '').trim(), hasNextPage: Boolean(connection.pageInfo?.hasNextPage) };
  }
  catch {
    return null;
  }
}

export async function userProjects(tab: TabController, username: string, after: string, limit: number, token: string): Promise<{ list: any[]; next?: string } | null> {
  const nodes: any[] = [];
  let cursor = after;
  let more = true;
  for (let round = 0; round < FILL_GUARD && more && nodes.length < limit; round++) {
    const page = await graphqlProjects(tab, username, cursor, Math.min(GRAPHQL_PAGE, limit - nodes.length), token);
    if (!page) {
      if (!nodes.length) {
        return null;
      }
      break;
    }

    nodes.push(...page.nodes);
    more = page.hasNextPage && Boolean(page.endCursor) && page.nodes.length > 0;
    cursor = page.endCursor || cursor;
  }

  return { list: nodes, next: more && nodes.length && cursor && cursor !== after ? JSON.stringify({ after: cursor }) : undefined };
}

export async function teamProjects(tab: TabController, username: string, perPage: number, offset: string): Promise<{ list: any[]; next?: string } | null> {
  try {
    const response = await tab.fetch(`${ORIGIN}/${encodeURIComponent(username)}/projects?per_page=${perPage}${offset ? `&offset=${encodeURIComponent(offset)}` : ''}`, {
      headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
    });
    if (!response.ok) {
      return null;
    }

    const data = JSON.parse(response.body);
    if (!Array.isArray(data?.section_content)) {
      return null;
    }

    const list: any[] = data.section_content.slice(0, perPage);
    const token = data.offset == null ? '' : String(data.offset);
    return { list, next: list.length >= perPage && token && token !== offset ? JSON.stringify({ offset: token }) : undefined };
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function cover(covers: any): string {
  if (!covers || typeof covers !== 'object') {
    return '';
  }
  return covers.original ?? covers.max_808 ?? covers['808'] ?? covers['404'] ?? covers.size_original?.url ?? covers.size_max_808?.url ?? covers.size_808?.url ?? covers.size_404?.url ?? covers.size_276?.url ?? covers.size_50?.url ?? covers.allAvailable?.[0]?.url ?? Object.values(covers).find((value) => typeof value === 'string') as string ?? '';
}

export async function build(tab: TabController, username: string, list: any[], next?: string): Promise<CrawlPage> {
  if (!list.length) {
    return EMPTY;
  }

  const fulls = await Promise.all(list.map((item: any) => store(tab, String(item.url ?? item.share_url ?? ''))));

  const items = list.map((item: any, index: number): social_resource => {
    const full: any = fulls[index]?.project ?? {};
    const detail: any = full.project ?? {};
    const owners: any[] = Array.isArray(item.owners) ? item.owners : Array.isArray(detail.owners) ? detail.owners : [];
    const owner: any = owners[0] ?? {};
    const stats: any = item.stats ?? detail.stats ?? {};
    const fields: any[] = Array.isArray(item.fields) ? item.fields : [];
    const tags: any[] = Array.isArray(detail.tags) ? detail.tags : [];
    const tools: any[] = Array.isArray(detail.tools) ? detail.tools : [];
    const modules: any[] = Array.isArray(detail.modules) ? detail.modules : [];
    return {
      type: 'projects',
      resource_id: String(item.id ?? ''),
      url: item.url ?? detail.url ?? '',
      parent_url: `https://www.behance.net/${username}`,
      title: item.name ?? detail.name ?? '',
      caption: clean(detail.description),
      author: owner.username ?? username,
      datetime: stamp(item.publishedOn ?? item.published_on),
      media_type: 'project',
      media_url: cover(item.covers ?? detail.covers),
      thumbnail_url: cover(item.covers ?? detail.covers),
      likes: String((stats.appreciations?.all ?? stats.appreciations ?? full.appreciationCount ?? 0) || ''),
      shares: '',
      views: String((stats.views?.all ?? stats.views ?? 0) || ''),
      project_id: item.id ?? 0,
      oid: item.oid ?? '',
      slug: item.slug ?? '',
      name: item.name ?? '',
      description: clean(detail.description),
      short_url: detail.shortUrl ?? '',
      published_on: stamp(item.publishedOn ?? item.published_on),
      modified_on: stamp(item.modifiedOn ?? item.modified_on),
      created_on: stamp(item.created_on),
      conceived_on: stamp(item.conceived_on),
      featured_on: stamp(item.featured_on),
      views_count: stats.views?.all ?? stats.views ?? 0,
      appreciations_count: stats.appreciations?.all ?? stats.appreciations ?? full.appreciationCount ?? 0,
      comments_count: stats.comments?.all ?? stats.comments ?? full.commentCount ?? 0,
      privacy: item.privacy ?? item.privacyLevel ?? detail.privacyLevel ?? '',
      publish_status: item.publishStatus ?? '',
      is_private: item.isPrivate ?? item.private ?? false,
      is_premium: Boolean(item.premium ?? detail.premium),
      is_boosted: item.isBoosted ?? item.boosted ?? false,
      is_flagged: item.isFlagged ?? false,
      is_team: item.is_team ?? false,
      has_mature_content: item.hasMatureContent ?? Boolean(item.mature_content),
      mature_access: item.mature_access ?? item.matureAccess ?? detail.matureAccess ?? '',
      commenting_allowed: detail.isCommentingAllowed ?? false,
      fields: fields.map((field: any) => field?.name ?? field?.label ?? '').filter(Boolean).join(', '),
      tags: tags.map((tag: any) => tag?.title ?? '').filter(Boolean).join(', '),
      tags_count: tags.length,
      tools: tools.map((tool: any) => tool?.title ?? '').filter(Boolean).join(', '),
      tools_count: tools.length,
      modules_count: modules.length,
      module_types: [...new Set(modules.map((module: any) => module?.__typename ?? module?.type ?? '').filter(Boolean))].join(', '),
      module_images: modules.map((module: any) => module?.sizes?.original ?? module?.imageSizes?.size_original?.url ?? '').filter(Boolean).slice(0, 20).join(', '),
      license: detail.license?.license ?? '',
      source_files_count: Array.isArray(item.sourceFiles) ? item.sourceFiles.length : 0,
      linked_assets_count: item.linked_asset_count ?? 0,
      color_r: item.colors?.r ?? 0,
      color_g: item.colors?.g ?? 0,
      color_b: item.colors?.b ?? 0,
      cover_url: cover(item.covers ?? detail.covers),
      owners_count: owners.length,
      owner_names: owners.map((entry: any) => entry?.username ?? '').filter(Boolean).join(', '),
      owner_id: owner.id ?? 0,
      owner_username: owner.username ?? '',
      owner_first_name: owner.first_name ?? owner.firstName ?? '',
      owner_last_name: owner.last_name ?? owner.lastName ?? '',
      owner_display_name: owner.display_name ?? owner.displayName ?? '',
      owner_occupation: owner.occupation ?? '',
      owner_company: owner.company ?? '',
      owner_city: owner.city ?? '',
      owner_state: owner.state ?? '',
      owner_country: owner.country ?? '',
      owner_location: owner.location ?? '',
      owner_url: owner.url ?? '',
      owner_avatar: cover(owner.images),
      owner_created_on: stamp(owner.created_on ?? owner.createdOn),
      owner_followers: owner.stats?.followers ?? 0,
      owner_appreciations: owner.stats?.appreciations ?? 0,
      owner_views: owner.stats?.views ?? 0,
      owner_comments: owner.stats?.comments ?? 0,
    };
  }).filter((item) => item.url);

  return { items, next_cursor: items.length && next ? next : undefined };
}
