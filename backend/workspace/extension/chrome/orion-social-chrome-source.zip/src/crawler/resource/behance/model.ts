export interface CookieApi {
  cookies?: {
    get?(details: { url: string; name: string }): Promise<{ value?: string } | null | undefined>;
    set?(details: Record<string, unknown>): Promise<unknown>;
  };
}

export interface Cursor {
  after: string;
  offset: string;
}

export interface GraphqlPage {
  nodes: any[];
  endCursor: string;
  hasNextPage: boolean;
}
