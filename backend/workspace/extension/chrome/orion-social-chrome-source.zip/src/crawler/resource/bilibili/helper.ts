import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function mid(payload: CrawlPayload): string {
  const fromUrl = /space\.bilibili\.com\/(\d+)/.exec(String(payload.url ?? ''))?.[1];
  const username = String(payload.username ?? '');
  return fromUrl ?? (/^\d+$/.test(username) ? username : '');
}

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://api.bilibili.com${path}`, {
      headers: { Accept: 'application/json', Referer: 'https://space.bilibili.com/' },
    });
    if (!response.ok) {
      return null;
    }
    const data = JSON.parse(response.body);
    return data?.code === 0 ? data.data : null;
  }
  catch {
    return null;
  }
}

export function pageNumber(payload: CrawlPayload): number {
  const parsed = Number(String(payload.cursor ?? '').trim());
  return Number.isFinite(parsed) && parsed >= 1 ? Math.floor(parsed) : 1;
}

export function page(items: social_resource[], pn: number, ps: number, rawCount: number, total: unknown): CrawlPage {
  const count = Number(total);
  const hasMore = Number.isFinite(count) && count > 0 ? pn * ps < count : rawCount >= ps;
  return { items, next_cursor: items.length && hasMore ? String(pn + 1) : undefined };
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function https(url: unknown): string {
  const text = String(url ?? '');
  return text.startsWith('//') ? `https:${text}` : text;
}

export function person(id: string, type: 'followers', entry: any): social_resource {
  return {
    type,
    resource_id: String(entry.mid ?? ''),
    url: entry.mid ? `https://space.bilibili.com/${entry.mid}` : '',
    parent_url: `https://space.bilibili.com/${id}`,
    title: entry.uname ?? '',
    caption: clean(entry.sign),
    author: entry.uname ?? '',
    datetime: stamp(entry.mtime),
    media_type: 'user',
    media_url: entry.mid ? `https://space.bilibili.com/${entry.mid}` : '',
    thumbnail_url: https(entry.face),
    likes: '',
    shares: '',
    views: '',
    user_mid: entry.mid ?? 0,
    uname: entry.uname ?? '',
    sign: clean(entry.sign),
    face: https(entry.face),
    attribute: entry.attribute ?? 0,
    is_mutual: (entry.attribute ?? 0) === 6,
    special: entry.special ?? 0,
    vip_type: entry.vip?.vipType ?? 0,
    vip_status: entry.vip?.vipStatus ?? 0,
    vip_label: entry.vip?.label?.text ?? '',
    official_role: entry.official_verify?.type ?? -1,
    official_desc: entry.official_verify?.desc ?? '',
    nft_icon: entry.nft_icon ?? '',
    follow_time: stamp(entry.mtime),
  };
}
