import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { page, pagedPath, person, rkey, text, xrpc } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://bsky.app/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await xrpc(tab, pagedPath(`app.bsky.feed.getAuthorFeed?actor=${encodeURIComponent(username)}`, payload));
    const feed = (Array.isArray(data?.feed) ? data.feed : []) as any[];
    return page(feed.map((entry: any): social_resource => {
      const post = entry.post ?? {};
      const record = post.record ?? {};
      const author = post.author ?? {};
      const embed = post.embed ?? {};
      const externalEmbed = embed['external'] ?? {};
      const images: any[] = Array.isArray(embed.images) ? embed.images : Array.isArray(embed.media?.images) ? embed.media.images : [];
      const reason = entry.reason ?? {};
      const handle = author.handle ?? username;
      return {
        type: 'posts',
        resource_id: post.uri ?? '',
        url: post.uri ? `https://bsky.app/profile/${handle}/post/${rkey(post.uri)}` : '',
        parent_url: `https://bsky.app/profile/${username}`,
        title: '',
        caption: text(record.text),
        author: handle,
        datetime: record.createdAt ?? post.indexedAt ?? '',
        media_type: String(embed.$type ?? '').replace('app.bsky.embed.', '').replace('#view', '') || 'text',
        media_url: images[0]?.fullsize ?? externalEmbed.uri ?? embed.playlist ?? '',
        thumbnail_url: images[0]?.thumb ?? externalEmbed.thumb ?? embed.thumbnail ?? '',
        likes: String((post.likeCount ?? 0) || ''),
        shares: String((post.repostCount ?? 0) || ''),
        views: '',
        uri: post.uri ?? '',
        cid: post.cid ?? '',
        rkey: rkey(post.uri),
        text: text(record.text),
        text_length: String(record.text ?? '').length,
        langs: Array.isArray(record.langs) ? record.langs.join(', ') : '',
        author_did: author.did ?? '',
        author_handle: handle,
        author_display_name: author.displayName ?? '',
        author_avatar: author.avatar ?? '',
        author_created_at: author.createdAt ?? '',
        author_verified: author.verification?.verifiedStatus ?? '',
        like_count: post.likeCount ?? 0,
        repost_count: post.repostCount ?? 0,
        reply_count: post.replyCount ?? 0,
        quote_count: post.quoteCount ?? 0,
        bookmark_count: post.bookmarkCount ?? 0,
        indexed_at: post.indexedAt ?? '',
        created_at: record.createdAt ?? '',
        is_repost: String(reason.$type ?? '').includes('reasonRepost'),
        reposted_by: reason.by?.handle ?? '',
        reposted_at: reason.indexedAt ?? '',
        reply_root: record.reply?.root?.uri ?? '',
        reply_parent: record.reply?.parent?.uri ?? '',
        embed_type: embed.$type ?? '',
        embed_external_uri: externalEmbed.uri ?? '',
        embed_external_title: text(externalEmbed.title),
        embed_external_description: text(externalEmbed.description).slice(0, 500),
        embed_record_uri: embed.record?.uri ?? embed.record?.record?.uri ?? '',
        images_count: images.length,
        image_urls: images.map((image: any) => image?.fullsize ?? '').filter(Boolean).join(', '),
        image_alts: images.map((image: any) => text(image?.alt)).filter(Boolean).join(' | '),
        facet_links: Array.isArray(record.facets) ? record.facets.flatMap((facet: any) => (Array.isArray(facet?.features) ? facet.features : []).map((feature: any) => feature?.uri ?? feature?.tag ?? feature?.did ?? '')).filter(Boolean).join(', ') : '',
        labels: Array.isArray(post.labels) ? post.labels.map((label: any) => label?.val ?? '').filter(Boolean).join(', ') : '',
        tags: Array.isArray(record.tags) ? record.tags.join(', ') : '',
      };
    }).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://bsky.app/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await xrpc(tab, pagedPath(`app.bsky.graph.getFollowers?actor=${encodeURIComponent(username)}`, payload));
    return page(((data?.followers ?? []) as any[]).map((entry: any) => person(username, 'followers', entry)).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://bsky.app/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await xrpc(tab, pagedPath(`app.bsky.graph.getFollows?actor=${encodeURIComponent(username)}`, payload));
    return page(((data?.follows ?? []) as any[]).map((entry: any) => person(username, 'friends', entry)).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const postUrl = String(payload.url ?? '');
  const match = /\/profile\/([^/]+)\/post\/([^/?#]+)/.exec(postUrl);
  const username = String(payload.username ?? '');
  if (!match && !username) {
    return EMPTY;
  }
  const actor = match ? match[1] : username;
  const tab = await openSession('https://bsky.app/');
  if (!tab) {
    return EMPTY;
  }
  try {
    // A profile names no post, so the actor's newest own top-level post stands in for it.
    let uri = '';
    if (match) {
      let did = actor;
      if (!actor.startsWith('did:')) {
        const resolved = await xrpc(tab, `com.atproto.identity.resolveHandle?handle=${encodeURIComponent(actor)}`);
        did = String(resolved?.did ?? '');
      }
      uri = did ? `at://${did}/app.bsky.feed.post/${match[2]}` : '';
    }
    else {
      const feed = await xrpc(tab, `app.bsky.feed.getAuthorFeed?actor=${encodeURIComponent(actor)}&filter=posts_no_replies&limit=20`);
      const own = (Array.isArray(feed?.feed) ? feed.feed : []).find((entry: any) => !entry?.reason && entry?.post?.uri);
      uri = String(own?.post?.uri ?? '');
    }
    if (!uri) {
      return EMPTY;
    }
    const data = await xrpc(tab, `app.bsky.feed.getPostThread?uri=${encodeURIComponent(uri)}&depth=1`);
    const replies: any[] = Array.isArray(data?.thread?.replies) ? data.thread.replies : [];
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const reply of replies) {
      const post = reply?.post;
      const author = post?.author;
      const id = String(author?.did ?? '');
      if (!author?.handle || seen.has(id)) {
        continue;
      }
      seen.add(id);
      items.push({
        ...person(actor, 'connections', author),
        parent_url: postUrl,
        caption: text(post?.record?.text).slice(0, 600),
        comment_text: text(post?.record?.text),
        comment_url: `https://bsky.app/profile/${author.handle}/post/${rkey(post?.uri)}`,
        comment_at: post?.record?.createdAt ?? post?.indexedAt ?? '',
        handle: author.handle ?? '',
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}


export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://bsky.app/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await xrpc(tab, pagedPath(`app.bsky.feed.getActorFeeds?actor=${encodeURIComponent(username)}`, payload));
    return page(((data?.feeds ?? []) as any[]).map((feed: any): social_resource => ({
      type: 'projects',
      resource_id: feed.uri ?? '',
      url: feed.uri ? `https://bsky.app/profile/${feed.creator?.handle ?? username}/feed/${rkey(feed.uri)}` : '',
      parent_url: `https://bsky.app/profile/${username}`,
      title: feed.displayName ?? '',
      caption: text(feed.description),
      author: feed.creator?.handle ?? username,
      datetime: feed.indexedAt ?? '',
      media_type: 'feed_generator',
      media_url: feed.uri ?? '',
      thumbnail_url: feed.avatar ?? '',
      likes: String((feed.likeCount ?? 0) || ''),
      shares: '',
      views: '',
      uri: feed.uri ?? '',
      cid: feed.cid ?? '',
      rkey: rkey(feed.uri),
      feed_did: feed.did ?? '',
      display_name: feed.displayName ?? '',
      description: text(feed.description),
      avatar: feed.avatar ?? '',
      like_count: feed.likeCount ?? 0,
      accepts_interactions: feed.acceptsInteractions ?? false,
      creator_did: feed.creator?.did ?? '',
      creator_handle: feed.creator?.handle ?? '',
      creator_display_name: feed.creator?.displayName ?? '',
      creator_avatar: feed.creator?.avatar ?? '',
      creator_description: text(feed.creator?.description).slice(0, 500),
      creator_created_at: feed.creator?.createdAt ?? '',
      creator_verified: feed.creator?.verification?.verifiedStatus ?? '',
      content_mode: feed.contentMode ?? '',
      labels: Array.isArray(feed.labels) ? feed.labels.map((label: any) => label?.val ?? '').filter(Boolean).join(', ') : '',
      indexed_at: feed.indexedAt ?? '',
    })).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://bsky.app/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await xrpc(tab, pagedPath(`app.bsky.graph.getLists?actor=${encodeURIComponent(username)}`, payload));
    return page(((data?.lists ?? []) as any[]).map((list: any): social_resource => ({
      type: 'organizations',
      resource_id: list.uri ?? '',
      url: list.uri ? `https://bsky.app/profile/${list.creator?.handle ?? username}/lists/${rkey(list.uri)}` : '',
      parent_url: `https://bsky.app/profile/${username}`,
      title: list.name ?? '',
      caption: text(list.description),
      author: list.creator?.handle ?? username,
      datetime: list.indexedAt ?? '',
      media_type: String(list.purpose ?? '').replace('app.bsky.graph.defs#', '') || 'list',
      media_url: list.uri ?? '',
      thumbnail_url: list.avatar ?? '',
      likes: '',
      shares: String((list.listItemCount ?? 0) || ''),
      views: '',
      uri: list.uri ?? '',
      cid: list.cid ?? '',
      rkey: rkey(list.uri),
      name: list.name ?? '',
      description: text(list.description),
      purpose: list.purpose ?? '',
      list_item_count: list.listItemCount ?? 0,
      avatar: list.avatar ?? '',
      creator_did: list.creator?.did ?? '',
      creator_handle: list.creator?.handle ?? '',
      creator_display_name: list.creator?.displayName ?? '',
      creator_avatar: list.creator?.avatar ?? '',
      creator_description: text(list.creator?.description).slice(0, 500),
      creator_created_at: list.creator?.createdAt ?? '',
      labels: Array.isArray(list.labels) ? list.labels.map((label: any) => label?.val ?? '').filter(Boolean).join(', ') : '',
      indexed_at: list.indexedAt ?? '',
    })).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
