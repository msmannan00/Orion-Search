import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

async function fetchProfile(username: string): Promise<any> {
  const response = await fetch(`https://codeberg.org/api/v1/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  return data && data.login ? data : null;
}

async function fetchRepos(username: string, page: number, limit: number): Promise<{ repos: any[]; total: number }> {
  const response = await fetch(`https://codeberg.org/api/v1/users/${encodeURIComponent(username)}/repos?limit=${limit}&page=${page}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return { repos: [], total: 0 };
  }
  const repos = await response.json();
  const total = Number(response.headers.get('x-total-count') ?? 0);
  return { repos: Array.isArray(repos) ? repos : [], total };
}

export async function details(username: string): Promise<social_profile_details[]> {
  const user = await fetchProfile(username);
  if (!user) {
    return [];
  }

  const { total, repos } = await fetchRepos(username, 1, 1);
  const count = total || repos.length;
  return [{
    real_name: clean(user.full_name) || user.login,
    bio: clean(user.description),
    description: clean(user.description),
    location: clean(user.location),
    profile_url: user.html_url ?? `https://codeberg.org/${username}`,
    total_posts: String(count || ''),
    total_followers: String((user.followers_count ?? 0) || ''),
    total_likes: '',
    avatar: user.avatar_url ?? '',
    banner: '',
    crawl_type: ['details', 'repositories'],
    platform: 'codeberg',
    username: user.login,
    repositories_count: count,
    following_count: user.following_count ?? 0,
    website: user.website ?? '',
    created: user.created ?? '',
  }];
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const limit = limitOf(payload, 25, 50);
    const { repos, total } = await fetchRepos(username, page, limit);
    if (!repos.length) {
      return EMPTY;
    }

    const items = repos.map((repo: any): social_resource => {
      return {
        type: 'repositories',
        resource_id: String(repo.id ?? repo.full_name ?? ''),
        url: repo.html_url ?? `https://codeberg.org/${repo.full_name ?? ''}`,
        parent_url: `https://codeberg.org/${username}`,
        title: repo.full_name ?? repo.name ?? '',
        caption: clean(repo.description),
        author: username,
        datetime: repo.updated_at ?? repo.created_at ?? '',
        media_type: 'repository',
        media_url: '',
        thumbnail_url: repo.avatar_url ?? '',
        likes: String((repo.stars_count ?? 0) || ''),
        shares: String((repo.forks_count ?? 0) || ''),
        views: String((repo.watchers_count ?? 0) || ''),
        name: repo.name ?? '',
        description: clean(repo.description),
        language: repo.language ?? '',
        stars_count: repo.stars_count ?? 0,
        forks_count: repo.forks_count ?? 0,
        watchers_count: repo.watchers_count ?? 0,
        open_issues_count: repo.open_issues_count ?? 0,
        is_fork: Boolean(repo.fork),
        archived: Boolean(repo.archived),
        default_branch: repo.default_branch ?? '',
        clone_url: repo.clone_url ?? '',
        created_at: repo.created_at ?? '',
        updated_at: repo.updated_at ?? '',
        size: repo.size ?? 0,
      };
    }).filter((item) => item.url);

    const hasMore = total ? page * limit < total : repos.length >= limit;
    return { items, next_cursor: items.length && hasMore ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
