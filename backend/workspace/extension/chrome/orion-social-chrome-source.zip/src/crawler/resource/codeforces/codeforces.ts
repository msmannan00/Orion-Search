import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, fromOf, stamp } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const handle = String(payload.username ?? '');
  const tab = handle ? await openSession('https://codeforces.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const result = await api(tab, `user.blogEntries?handle=${encodeURIComponent(handle)}`);
    const items = ((Array.isArray(result) ? result : []) as any[]).map((entry: any): social_resource => ({
      type: 'posts',
      resource_id: String(entry.id ?? ''),
      url: entry.id ? `https://codeforces.com/blog/entry/${entry.id}` : '',
      parent_url: `https://codeforces.com/profile/${handle}`,
      title: clean(entry.title),
      caption: clean(entry.content).slice(0, 2000),
      author: entry.authorHandle ?? handle,
      datetime: stamp(entry.creationTimeSeconds),
      media_type: 'blog_entry',
      media_url: entry.id ? `https://codeforces.com/blog/entry/${entry.id}` : '',
      thumbnail_url: '',
      likes: String((entry.rating ?? 0) || ''),
      shares: '',
      views: '',
      entry_id: entry.id ?? 0,
      author_handle: entry.authorHandle ?? handle,
      title_text: clean(entry.title),
      rating: entry.rating ?? 0,
      locale: entry.locale ?? '',
      original_locale: entry.originalLocale ?? '',
      allow_view_history: entry.allowViewHistory ?? false,
      tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
      tags_count: Array.isArray(entry.tags) ? entry.tags.length : 0,
      created_at: stamp(entry.creationTimeSeconds),
      modified_at: stamp(entry.modificationTimeSeconds),
    })).filter((item) => item.url);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function answers(payload: CrawlPayload): Promise<CrawlPage> {
  const handle = String(payload.username ?? '');
  const tab = handle ? await openSession('https://codeforces.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const from = fromOf(payload);
    const count = limitOf(payload, 25, 100);
    const result = await api(tab, `user.status?handle=${encodeURIComponent(handle)}&from=${from}&count=${count}`);
    const entries = (Array.isArray(result) ? result : []) as any[];
    const items = entries.map((entry: any): social_resource => {
      const problem = entry.problem ?? {};
      const author = entry.author ?? {};
      const members: any[] = Array.isArray(author.members) ? author.members : [];
      return {
        type: 'answers',
        resource_id: String(entry.id ?? ''),
        url: entry.contestId ? `https://codeforces.com/contest/${entry.contestId}/submission/${entry.id}` : `https://codeforces.com/problemset/submission/0/${entry.id}`,
        parent_url: `https://codeforces.com/profile/${handle}`,
        title: problem.name ?? '',
        caption: Array.isArray(problem.tags) ? problem.tags.join(', ') : '',
        author: members[0]?.handle ?? handle,
        datetime: stamp(entry.creationTimeSeconds),
        media_type: 'submission',
        media_url: problem.contestId ? `https://codeforces.com/contest/${problem.contestId}/problem/${problem.index}` : '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        submission_id: entry.id ?? 0,
        contest_id: entry.contestId ?? 0,
        problem_index: problem.index ?? '',
        problem_name: problem.name ?? '',
        problem_type: problem.type ?? '',
        problem_rating: problem.rating ?? 0,
        problem_points: problem.points ?? 0,
        problem_tags: Array.isArray(problem.tags) ? problem.tags.join(', ') : '',
        problem_tags_count: Array.isArray(problem.tags) ? problem.tags.length : 0,
        problem_url: problem.contestId ? `https://codeforces.com/contest/${problem.contestId}/problem/${problem.index}` : '',
        verdict: entry.verdict ?? '',
        testset: entry.testset ?? '',
        passed_test_count: entry.passedTestCount ?? 0,
        time_consumed_ms: entry.timeConsumedMillis ?? 0,
        memory_consumed_bytes: entry.memoryConsumedBytes ?? 0,
        programming_language: entry.programmingLanguage ?? '',
        participant_type: author.participantType ?? '',
        ghost: author.ghost ?? false,
        team_id: author.teamId ?? 0,
        team_name: author.teamName ?? '',
        room: author.room ?? 0,
        members: members.map((member: any) => member?.handle ?? '').filter(Boolean).join(', '),
        members_count: members.length,
        relative_time_seconds: entry.relativeTimeSeconds ?? 0,
        points: entry.points ?? 0,
        created_at: stamp(entry.creationTimeSeconds),
        participant_start: stamp(author.startTimeSeconds),
      };
    }).filter((item) => item.url);
    return { items, next_cursor: items.length && entries.length >= count ? String(from + entries.length) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const handle = String(payload.username ?? '');
  const tab = handle ? await openSession('https://codeforces.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const result = await api(tab, `user.rating?handle=${encodeURIComponent(handle)}`);
    const items = ((Array.isArray(result) ? result : []) as any[]).map((entry: any): social_resource => ({
      type: 'games',
      resource_id: String(entry.contestId ?? ''),
      url: entry.contestId ? `https://codeforces.com/contest/${entry.contestId}` : '',
      parent_url: `https://codeforces.com/profile/${handle}`,
      title: clean(entry.contestName),
      caption: `rank ${entry.rank ?? 0}`,
      author: entry.handle ?? handle,
      datetime: stamp(entry.ratingUpdateTimeSeconds),
      media_type: 'contest',
      media_url: entry.contestId ? `https://codeforces.com/contest/${entry.contestId}` : '',
      thumbnail_url: '',
      likes: '',
      shares: '',
      views: '',
      contest_id: entry.contestId ?? 0,
      contest_name: clean(entry.contestName),
      handle: entry.handle ?? handle,
      rank: entry.rank ?? 0,
      old_rating: entry.oldRating ?? 0,
      new_rating: entry.newRating ?? 0,
      rating_change: (entry.newRating ?? 0) - (entry.oldRating ?? 0),
      rating_update_time: stamp(entry.ratingUpdateTimeSeconds),
    })).filter((item) => item.url);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
