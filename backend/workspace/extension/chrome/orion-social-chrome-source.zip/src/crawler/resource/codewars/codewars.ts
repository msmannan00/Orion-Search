import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, UPSTREAM_PAGE } from './constant';
import { api, enrich, position } from './helper';

export async function answers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.codewars.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, UPSTREAM_PAGE);
    let { page, offset } = position(payload);
    const entries: any[] = [];
    let next: string | undefined;

    for (let guard = 0; guard < 3 && entries.length < limit; guard++) {
      const data = await api(tab, `users/${encodeURIComponent(username)}/code-challenges/completed?page=${page}`);
      if (!data) {
        break;
      }

      const rows = (Array.isArray(data.data) ? data.data : []) as any[];
      const totalPages = Math.max(0, Math.floor(Number(data.totalPages) || 0));
      const slice = rows.slice(offset, offset + (limit - entries.length));
      entries.push(...slice);
      offset += slice.length;

      if (offset < rows.length) {
        next = JSON.stringify({ page, offset });
        break;
      }
      if (page + 1 >= totalPages) {
        next = undefined;
        break;
      }

      page += 1;
      offset = 0;
      next = JSON.stringify({ page, offset });
    }

    const items = await enrich(tab, username, 'answers', entries);
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.codewars.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, UPSTREAM_PAGE);
    const { offset } = position(payload);
    const data = await api(tab, `users/${encodeURIComponent(username)}/code-challenges/authored`);
    const rows = (Array.isArray(data?.data) ? data.data : []) as any[];
    const entries = rows.slice(offset, offset + limit);
    const end = offset + entries.length;
    const items = await enrich(tab, username, 'projects', entries);
    return { items, next_cursor: items.length && end < rows.length ? JSON.stringify({ offset: end }) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
