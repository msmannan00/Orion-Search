import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.codewars.com/api/v1/${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function position(payload: CrawlPayload): { page: number; offset: number } {
  try {
    const parsed: any = JSON.parse(String(payload.cursor ?? '').trim() || '{}');
    return {
      page: Math.max(0, Math.floor(Number(parsed?.page) || 0)),
      offset: Math.max(0, Math.floor(Number(parsed?.offset) || 0)),
    };
  }
  catch {
    return { page: 0, offset: 0 };
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/```[\s\S]*?```/g, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function kata(username: string, type: 'answers' | 'projects', entry: any, full: any): social_resource {
  const detail: any = full ?? {};
  const languages: string[] = Array.isArray(entry.languages) ? entry.languages : Array.isArray(detail.languages) ? detail.languages : [];
  const completed: string[] = Array.isArray(entry.completedLanguages) ? entry.completedLanguages : [];
  const tags: string[] = Array.isArray(entry.tags) ? entry.tags : Array.isArray(detail.tags) ? detail.tags : [];
  return {
    type,
    resource_id: entry.id ?? '',
    url: detail.url ?? (entry.slug ? `https://www.codewars.com/kata/${entry.slug}` : ''),
    parent_url: `https://www.codewars.com/users/${username}`,
    title: entry.name ?? detail.name ?? '',
    caption: clean(entry.description ?? detail.description).slice(0, 1000),
    author: detail.createdBy?.username ?? username,
    datetime: entry.completedAt ?? detail.publishedAt ?? detail.createdAt ?? '',
    media_type: 'kata',
    media_url: detail.url ?? '',
    thumbnail_url: '',
    likes: String((detail.totalStars ?? 0) || ''),
    shares: '',
    views: String((detail.totalCompleted ?? 0) || ''),
    kata_id: entry.id ?? '',
    slug: entry.slug ?? detail.slug ?? '',
    name: entry.name ?? detail.name ?? '',
    description: clean(entry.description ?? detail.description),
    category: detail.category ?? '',
    rank_id: entry.rank?.id ?? detail.rank?.id ?? 0,
    rank_name: entry.rankName ?? entry.rank?.name ?? detail.rank?.name ?? '',
    rank_color: entry.rank?.color ?? detail.rank?.color ?? '',
    languages: languages.join(', '),
    languages_count: languages.length,
    completed_languages: completed.join(', '),
    completed_languages_count: completed.length,
    completed_at: entry.completedAt ?? '',
    tags: tags.join(', '),
    tags_count: tags.length,
    total_attempts: detail.totalAttempts ?? 0,
    total_completed: detail.totalCompleted ?? 0,
    total_stars: detail.totalStars ?? 0,
    vote_score: detail.voteScore ?? 0,
    completion_rate: detail.totalAttempts ? Math.round(((detail.totalCompleted ?? 0) / detail.totalAttempts) * 10000) / 100 : 0,
    created_at: detail.createdAt ?? '',
    published_at: detail.publishedAt ?? '',
    approved_at: detail.approvedAt ?? '',
    created_by: detail.createdBy?.username ?? '',
    created_by_url: detail.createdBy?.url ?? '',
    approved_by: detail.approvedBy?.username ?? '',
    approved_by_url: detail.approvedBy?.url ?? '',
    contributors_wanted: detail.contributorsWanted ?? false,
    unresolved_issues: detail.unresolved?.issues ?? 0,
    unresolved_suggestions: detail.unresolved?.suggestions ?? 0,
  };
}

export async function enrich(tab: TabController, username: string, type: 'answers' | 'projects', entries: any[]): Promise<social_resource[]> {
  const fulls = await Promise.all(entries.map((entry: any) => api(tab, `code-challenges/${encodeURIComponent(entry.slug ?? entry.id ?? '')}`)));
  return entries.map((entry: any, index: number) => kata(username, type, entry, fulls[index])).filter((item) => item.url);
}
