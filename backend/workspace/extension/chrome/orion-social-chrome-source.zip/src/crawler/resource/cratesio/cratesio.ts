import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, cratesQuery, page } from './helper';

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://crates.io/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const profile = await api(tab, `users/${encodeURIComponent(username)}`);
    const userId = profile?.user?.id;
    if (!userId) {
      return EMPTY;
    }

    const data = await api(tab, `crates?${cratesQuery(userId, payload)}`);
    const crates = (Array.isArray(data?.crates) ? data.crates : []) as any[];

    return page(crates.map((crate: any): social_resource => {
      const full: any = {};
      const versions: any[] = [];
      const latest: any = {};
      const keywords: any[] = Array.isArray(crate.keywords) ? crate.keywords : [];
      const categories: any[] = Array.isArray(crate.categories) ? crate.categories : [];
      return {
        type: 'repositories',
        resource_id: crate.id ?? crate.name ?? '',
        url: `https://crates.io/crates/${crate.name ?? crate.id ?? ''}`,
        parent_url: `https://crates.io/users/${username}`,
        title: crate.name ?? '',
        caption: crate.description ?? '',
        author: username,
        datetime: crate.updated_at ?? '',
        media_type: 'crate',
        media_url: crate.repository ?? full.repository ?? '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: String((crate.downloads ?? 0) || ''),
        crate_id: crate.id ?? '',
        name: crate.name ?? '',
        description: crate.description ?? '',
        homepage: crate.homepage ?? '',
        documentation: crate.documentation ?? '',
        repository: crate.repository ?? '',
        downloads: crate.downloads ?? 0,
        recent_downloads: crate.recent_downloads ?? 0,
        num_versions: crate.num_versions ?? versions.length,
        default_version: crate.default_version ?? '',
        max_version: crate.max_version ?? '',
        newest_version: crate.newest_version ?? '',
        max_stable_version: crate.max_stable_version ?? '',
        yanked: crate.yanked ?? false,
        exact_match: crate.exact_match ?? false,
        trustpub_only: crate.trustpub_only ?? false,
        keywords: keywords.map((keyword: any) => keyword?.keyword ?? keyword?.id ?? '').filter(Boolean).join(', '),
        keywords_count: keywords.length,
        categories: categories.map((category: any) => category?.category ?? '').filter(Boolean).join(', '),
        category_slugs: categories.map((category: any) => category?.slug ?? '').filter(Boolean).join(', '),
        badges_count: Array.isArray(crate.badges) ? crate.badges.length : 0,
        latest_version: latest.num ?? '',
        latest_version_downloads: latest.downloads ?? 0,
        latest_version_created: latest.created_at ?? '',
        latest_version_updated: latest.updated_at ?? '',
        latest_version_yanked: latest.yanked ?? false,
        latest_version_license: latest.license ?? '',
        latest_version_size: latest.crate_size ?? 0,
        latest_version_features: latest.features ? Object.keys(latest.features).join(', ') : '',
        latest_version_rust: latest.rust_version ?? '',
        latest_version_edition: latest.edition ?? '',
        latest_version_publisher: latest.published_by?.login ?? '',
        latest_version_publisher_name: latest.published_by?.name ?? '',
        latest_version_has_lib: latest.has_lib ?? false,
        latest_version_bin_names: Array.isArray(latest.bin_names) ? latest.bin_names.filter(Boolean).join(', ') : '',
        versions_count: versions.length,
        version_numbers: versions.slice(0, 30).map((version: any) => version?.num ?? '').filter(Boolean).join(', '),
        total_version_downloads: versions.reduce((sum: number, version: any) => sum + (version?.downloads ?? 0), 0),
        created_at: crate.created_at ?? '',
        updated_at: crate.updated_at ?? '',
      };
    }).filter((item) => item.title), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
