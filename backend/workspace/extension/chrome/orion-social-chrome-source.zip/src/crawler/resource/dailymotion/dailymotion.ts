import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, USER_FIELDS, VIDEO_FIELDS } from './constant';
import { api, clean, page, pagedPath, pageOf, person, stamp } from './helper';

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.dailymotion.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const current = pageOf(payload);
    const data = await api(tab, pagedPath(`/user/${encodeURIComponent(username)}/videos?fields=${VIDEO_FIELDS}&sort=recent`, payload));
    return page(((data?.list ?? []) as any[]).map((video: any): social_resource => ({
      type: 'videos',
      resource_id: video.id ?? '',
      url: video.url ?? '',
      parent_url: `https://www.dailymotion.com/${username}`,
      title: video.title ?? '',
      caption: clean(video.description),
      author: video['owner.username'] ?? video.owner?.username ?? username,
      datetime: stamp(video.created_time),
      media_type: video.media_type ?? 'video',
      media_url: video.embed_url ?? '',
      thumbnail_url: video.thumbnail_720_url ?? video.thumbnail_url ?? '',
      likes: String((video.likes_total ?? 0) || ''),
      shares: '',
      views: String((video.views_total ?? 0) || ''),
      video_id: video.id ?? '',
      item_type: video.item_type ?? '',
      description: clean(video.description),
      tiny_url: video.tiny_url ?? '',
      duration: video.duration ?? 0,
      views_total: video.views_total ?? 0,
      views_last_hour: video.views_last_hour ?? 0,
      views_last_day: video.views_last_day ?? 0,
      views_last_week: video.views_last_week ?? 0,
      views_last_month: video.views_last_month ?? 0,
      likes_total: video.likes_total ?? 0,
      audience_total: video.audience_total ?? 0,
      language: video.language ?? '',
      country: video.country ?? '',
      tags: Array.isArray(video.tags) ? video.tags.join(', ') : '',
      hashtags: Array.isArray(video.hashtags) ? video.hashtags.join(', ') : '',
      channel_id: video['channel.id'] ?? '',
      channel_name: video['channel.name'] ?? '',
      channel_slug: video['channel.slug'] ?? '',
      channel_description: clean(video['channel.description']).slice(0, 400),
      thumbnail: video.thumbnail_url ?? '',
      thumbnail_720: video.thumbnail_720_url ?? '',
      thumbnail_1080: video.thumbnail_1080_url ?? '',
      first_frame: video.first_frame_720_url ?? '',
      filmstrip_url: video.filmstrip_60_url ?? '',
      sprite_url: video.sprite_url ?? '',
      seeker_url: video.seeker_url ?? '',
      embed_url: video.embed_url ?? '',
      allow_embed: video.allow_embed ?? false,
      width: video.width ?? 0,
      height: video.height ?? 0,
      aspect_ratio: video.aspect_ratio ?? 0,
      available_formats: Array.isArray(video.available_formats) ? video.available_formats.join(', ') : '',
      mode: video.mode ?? '',
      status: video.status ?? '',
      is_private: video.private ?? false,
      is_published: video.published ?? false,
      is_explicit: video.explicit ?? false,
      is_for_kids: video.is_created_for_kids ?? false,
      is_onair: video.onair ?? false,
      geoloc: Array.isArray(video.geoloc) ? video.geoloc.join(', ') : String(video.geoloc ?? ''),
      geoblocking: Array.isArray(video.geoblocking) ? video.geoblocking.join(', ') : '',
      live_airing_time: stamp(video.live_airing_time),
      record_status: video.record_status ?? '',
      allowed_in_playlists: video.allowed_in_playlists ?? false,
      soundtrack_isrc: video.soundtrack_isrc ?? '',
      is_partner: video.partner ?? false,
      is_verified: video.verified ?? false,
      owner_id: video['owner.id'] ?? '',
      owner_username: video['owner.username'] ?? '',
      owner_screenname: video['owner.screenname'] ?? '',
      owner_url: video['owner.url'] ?? '',
      owner_avatar: video['owner.avatar_240_url'] ?? '',
      created_at: stamp(video.created_time),
      updated_at: stamp(video.updated_time),
      uploaded_at: stamp(video.uploaded_time),
    })).filter((item) => item.url), data, current);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.dailymotion.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const current = pageOf(payload);
    const data = await api(tab, pagedPath(`/user/${encodeURIComponent(username)}/playlists?fields=id,item_type,name,description,videos_total,created_time,updated_time,thumbnail_url,thumbnail_720_url,private,owner,owner.username,owner.screenname,owner.url`, payload));
    return page(((data?.list ?? []) as any[]).map((playlist: any): social_resource => ({
      type: 'albums',
      resource_id: playlist.id ?? '',
      url: playlist.id ? `https://www.dailymotion.com/playlist/${playlist.id}` : '',
      parent_url: `https://www.dailymotion.com/${username}`,
      title: playlist.name ?? '',
      caption: clean(playlist.description),
      author: playlist['owner.username'] ?? username,
      datetime: stamp(playlist.created_time),
      media_type: 'playlist',
      media_url: playlist.id ? `https://www.dailymotion.com/playlist/${playlist.id}` : '',
      thumbnail_url: playlist.thumbnail_720_url ?? playlist.thumbnail_url ?? '',
      likes: '',
      shares: '',
      views: '',
      playlist_id: playlist.id ?? '',
      item_type: playlist.item_type ?? '',
      name: playlist.name ?? '',
      description: clean(playlist.description),
      videos_total: playlist.videos_total ?? 0,
      is_private: playlist.private ?? false,
      thumbnail: playlist.thumbnail_url ?? '',
      thumbnail_720: playlist.thumbnail_720_url ?? '',
      owner_id: playlist.owner ?? '',
      owner_username: playlist['owner.username'] ?? '',
      owner_screenname: playlist['owner.screenname'] ?? '',
      owner_url: playlist['owner.url'] ?? '',
      created_at: stamp(playlist.created_time),
      updated_at: stamp(playlist.updated_time),
    })).filter((item) => item.url), data, current);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.dailymotion.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const current = pageOf(payload);
    const data = await api(tab, pagedPath(`/user/${encodeURIComponent(username)}/followers?fields=${USER_FIELDS}`, payload));
    return page(((data?.list ?? []) as any[]).map((entry: any) => person(username, 'followers', entry)).filter((item) => item.url), data, current);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

