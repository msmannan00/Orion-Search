import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://api.dailymotion.com${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function pageOf(payload: CrawlPayload): number {
  const parsed = Number.parseInt(String(payload.cursor ?? '').trim(), 10);
  return Number.isFinite(parsed) && parsed > 1 ? parsed : 1;
}

export function pagedPath(path: string, payload: CrawlPayload): string {
  const joiner = path.includes('?') ? '&' : '?';
  return `${path}${joiner}limit=${limitOf(payload, 25, 100)}&page=${pageOf(payload)}`;
}

export function page(items: social_resource[], data: any, current: number): CrawlPage {
  const reported = Number(data?.page);
  const served = Number.isFinite(reported) && reported > 0 ? reported : current;
  return { items, next_cursor: items.length && data?.has_more ? String(served + 1) : undefined };
}

export function person(username: string, type: 'followers', entry: any): social_resource {
  return {
    type,
    resource_id: entry.id ?? '',
    url: entry.url ?? (entry.username ? `https://www.dailymotion.com/${entry.username}` : ''),
    parent_url: `https://www.dailymotion.com/${username}`,
    title: entry.screenname ?? entry.username ?? '',
    caption: clean(entry.description).slice(0, 600),
    author: entry.username ?? '',
    datetime: stamp(entry.created_time),
    media_type: 'user',
    media_url: entry.url ?? '',
    thumbnail_url: entry.avatar_240_url ?? '',
    likes: '',
    shares: '',
    views: String((entry.views_total ?? 0) || ''),
    user_id: entry.id ?? '',
    item_type: entry.item_type ?? '',
    username: entry.username ?? '',
    nickname: entry.nickname ?? '',
    screenname: entry.screenname ?? '',
    description: clean(entry.description),
    language: entry.language ?? '',
    gender: entry.gender ?? '',
    country: entry.country ?? '',
    city: entry.city ?? '',
    views_total: entry.views_total ?? 0,
    videos_total: entry.videos_total ?? 0,
    playlists_total: entry.playlists_total ?? 0,
    followers_total: entry.followers_total ?? 0,
    reposts_total: entry.reposts_total ?? 0,
    children_total: entry.children_total ?? 0,
    community_members_total: entry.community_members_total ?? 0,
    community_memberships_total: entry.community_memberships_total ?? 0,
    is_partner: entry.partner ?? false,
    is_verified: entry.verified ?? false,
    is_active: entry.active ?? false,
    status: entry.status ?? '',
    website_url: entry.website_url ?? '',
    facebook_url: entry.facebook_url ?? '',
    twitter_url: entry.twitter_url ?? '',
    instagram_url: entry.instagram_url ?? '',
    pinterest_url: entry.pinterest_url ?? '',
    linkedin_url: entry.linkedin_url ?? '',
    googleplus_url: entry.googleplus_url ?? '',
    avatar: entry.avatar_240_url ?? '',
    avatar_large: entry.avatar_720_url ?? '',
    cover: entry.cover_url ?? '',
    created_at: stamp(entry.created_time),
  };
}
