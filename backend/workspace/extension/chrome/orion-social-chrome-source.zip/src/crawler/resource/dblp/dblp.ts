import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function search(name: string, first: number, count: number): Promise<any> {
  const response = await fetch(`https://dblp.org/search/publ/api?q=${encodeURIComponent(name)}&format=json&h=${count}&f=${first}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function totalWorks(name: string): Promise<number> {
  const data = await search(name, 0, 1);
  return Number(data?.result?.hits?.['@total'] ?? 0);
}

export async function papers(payload: CrawlPayload): Promise<CrawlPage> {
  const name = String(payload.username ?? '');
  if (!name) {
    return EMPTY;
  }

  try {
    const first = offsetOf(payload);
    const count = limitOf(payload, 25, 50);
    const data = await search(name, first, count);
    const hits = data?.result?.hits ?? {};
    const total = Number(hits['@total'] ?? 0);
    const rows: any[] = Array.isArray(hits.hit) ? hits.hit : (hits.hit ? [hits.hit] : []);
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((row: any): social_resource => {
      const info = row.info ?? {};
      const authorRaw = info.authors?.author;
      const authors = (Array.isArray(authorRaw) ? authorRaw : (authorRaw ? [authorRaw] : [])).map((entry: any) => clean(typeof entry === 'object' ? entry?.text : entry)).filter(Boolean);
      return {
        type: 'papers',
        resource_id: String(info.key ?? row['@id'] ?? ''),
        url: info.ee ?? info.url ?? (info.doi ? `https://doi.org/${info.doi}` : ''),
        parent_url: `https://dblp.org/search?q=${encodeURIComponent(name)}`,
        title: clean(info.title) || 'Untitled',
        caption: authors.join(', '),
        author: authors.join(', ') || name,
        datetime: info.year ?? '',
        media_type: 'paper',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        name: clean(info.title),
        authors: authors.join(', '),
        venue: clean(info.venue),
        volume: info.volume ?? '',
        publication_year: info.year ?? '',
        work_type: info.type ?? '',
        doi: info.doi ?? '',
        dblp_url: info.url ?? '',
        access: info.access ?? '',
      };
    }).filter((item) => item.url);

    const next = first + rows.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
