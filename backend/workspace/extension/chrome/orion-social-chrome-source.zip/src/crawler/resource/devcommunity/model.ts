export interface OrgCursor {
  page: number;
  seen: string[];
  pending: string[];
}
