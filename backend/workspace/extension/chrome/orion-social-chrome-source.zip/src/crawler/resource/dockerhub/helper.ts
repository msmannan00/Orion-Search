import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://hub.docker.com/v2${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function pageOf(payload: CrawlPayload): number {
  const parsed = Number.parseInt(String(payload.cursor ?? '').trim(), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
}

export function page(items: social_resource[], data: any, current: number): CrawlPage {
  const hasNext = Boolean(data?.next);
  return { items, next_cursor: items.length && hasNext ? String(current + 1) : undefined };
}
