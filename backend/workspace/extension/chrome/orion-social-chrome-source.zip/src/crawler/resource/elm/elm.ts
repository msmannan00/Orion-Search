import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function authorPackages(author: string): Promise<any[]> {
  const response = await fetch('https://package.elm-lang.org/search.json', { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const all = await response.json();
  const prefix = `${author.toLowerCase().trim()}/`;
  return (Array.isArray(all) ? all : []).filter((pkg: any) => String(pkg?.name ?? '').toLowerCase().startsWith(prefix));
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const author = String(payload.username ?? '');
  if (!author) {
    return EMPTY;
  }

  try {
    const all = await authorPackages(author);
    if (!all.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = all.slice(offset, offset + limit);

    const items = slice.map((pkg: any): social_resource => {
      const name = String(pkg.name ?? '');
      const shortName = name.split('/')[1] ?? name;
      return {
        type: 'repositories',
        resource_id: name,
        url: `https://package.elm-lang.org/packages/${name}/latest/`,
        parent_url: `https://package.elm-lang.org/packages/${author}/`,
        title: name,
        caption: clean(pkg.summary),
        author,
        datetime: '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        name: shortName,
        full_name: name,
        description: clean(pkg.summary),
        version: pkg.version ?? '',
        license: pkg.license ?? '',
      };
    }).filter((item) => item.url);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < all.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
