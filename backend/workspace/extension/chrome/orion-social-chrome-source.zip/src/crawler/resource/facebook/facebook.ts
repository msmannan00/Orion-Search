import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { cacheSession, closeSessionTab, keepSessionAlive, liveSession, openSessionTab, sessionCache } from '../../tab_management/session_tab';
import { openSession } from '../../tab_management/tab.controller';
import { ADS_PASSES, ADS_PER_PASS, COLLECTIONS, COMMENTS_QUERY, EMPTY, FEED_PAGINATION_QUERY, MAX_COMMENT_HOPS, MAX_FEED_HOPS, MAX_HOPS, POSTS_MAX_HOPS, REEL_COMMENT_PROVIDERS, REEL_FEEDBACK_QUERY } from './constant';
import { CollectionKind, Tokens } from './model';
import { collectionNodes, collectionOf, commentAuthors, commentCursor, commentProviderFlags, connectionOf, countStories, decodeCursor, docIdAfterScroll, docIdFromBundles, docIdOf, encodeCursor, feedCursorOf, feedbackIdOf, feedPageInfo, feedVariablesOf, graphql, isStoryFragment, jsonBlocks, profileHtml, profileIdOf, reelCommentSeed, refetch, sponsoredStories, stories, timelinePageInfo, toAd, toCollectionItem, toItem, tokensOf, variablesOf } from './helper';

let cachedCommentsDocId = '';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }
  const key = `fb:posts:${username.toLowerCase()}`;
  const state = decodeCursor(payload);
  const received = state.c ?? '';
  const reused = received ? liveSession(key) : undefined;
  const tab = reused ? reused.tab : await openSessionTab(key, 'https://www.facebook.com/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 25, 50);
    let tokens = reused ? (sessionCache(key)['tokens'] as Tokens | undefined) : undefined;
    let base = reused ? (sessionCache(key)['base'] as Record<string, unknown> | undefined) : undefined;
    let profileId = state.id || '';
    let docId = state.d || '';
    const seen = new Set<string>();
    const items: social_resource[] = [];
    const push = (entries: any[]): void => {
      entries.forEach((story: any) => {
        const id = String(story.post_id ?? story.id ?? '');
        if (!id || seen.has(id)) {
          return;
        }
        const item = toItem(username, story);
        const urlKey = item.url.replace(/[?#].*$/, '').replace(/\/+$/, '').toLowerCase();
        if (!item.url || seen.has(urlKey) || /\/reel\//.test(urlKey) || isStoryFragment(item)) {
          return;
        }
        seen.add(id);
        seen.add(urlKey);
        if (story.post_id) {
          seen.add(String(story.post_id));
        }
        items.push(item);
      });
    };

    if (!reused) {
      const html = await profileHtml(tab, username);
      if (!html) {
        await closeSessionTab(key);
        return EMPTY;
      }
      const parsed = jsonBlocks(html);
      tokens = tokensOf(html);
      base = variablesOf(html);
      profileId = profileId || profileIdOf(parsed, html);
      docId = docId || docIdOf(html) || await docIdFromBundles(tab, html) || await docIdAfterScroll(tab, html);
      cacheSession(key, { tokens, base });
      if (!received) {
        push(stories(parsed));
      }
    }

    let cursor: string | null = received || null;
    let hasNext = true;
    for (let hop = 0; hop < POSTS_MAX_HOPS && hasNext && items.length < limit; hop++) {
      if (!docId || !profileId || !tokens?.dtsg) {
        break;
      }
      const lines = await refetch(tab, tokens, docId, profileId, cursor, 10, base ?? {});
      if (!lines) {
        break;
      }
      push(stories(lines));
      const info = timelinePageInfo(lines);
      if (!info) {
        hasNext = false;
        break;
      }
      const next = String(info.end_cursor ?? '');
      hasNext = Boolean(info.has_next_page) && Boolean(next) && next !== cursor;
      cursor = next || null;
    }

    const more = hasNext && Boolean(cursor) && cursor !== received;
    if (more) {
      keepSessionAlive(key);
    }
    else {
      await closeSessionTab(key);
    }
    return { items, next_cursor: more && cursor ? encodeCursor({ c: cursor, id: profileId, d: docId }) : undefined };
  }
  catch {
    await closeSessionTab(key);
    return EMPTY;
  }
}

export function reels(payload: CrawlPayload): Promise<CrawlPage> {
  return collection(payload, 'reels');
}

export function images(payload: CrawlPayload): Promise<CrawlPage> {
  return collection(payload, 'images');
}

export function followers(payload: CrawlPayload): Promise<CrawlPage> {
  return collection(payload, 'followers');
}

export function friends(payload: CrawlPayload): Promise<CrawlPage> {
  return collection(payload, 'friends');
}

async function collection(payload: CrawlPayload, kind: CollectionKind): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const spec = COLLECTIONS[kind];
  if (!username) {
    return EMPTY;
  }
  const key = `fb:${kind}:${username.toLowerCase()}`;
  const state = decodeCursor(payload);
  const received = state.c ?? '';
  const reused = received ? liveSession(key) : undefined;
  const tab = reused ? reused.tab : await openSessionTab(key, 'https://www.facebook.com/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 24, 50);
    let tokens = reused ? (sessionCache(key)['tokens'] as Tokens | undefined) : undefined;
    let collectionId = state.id || '';
    let docId = state.d || '';
    const seen = new Set<string>();
    const items: social_resource[] = [];
    const push = (edges: any[]): void => {
      collectionNodes(edges).forEach((node: any) => {
        const item = toCollectionItem(kind, username, node);
        const itemKey = item.resource_id || item.url;
        if (!item.url || !itemKey || seen.has(itemKey)) {
          return;
        }
        seen.add(itemKey);
        items.push(item);
      });
    };

    let cursor: string | null = received || null;
    let hasNext = true;
    if (!reused) {
      const html = await profileHtml(tab, username, spec.path, new RegExp(`"${spec.renderer}"`));
      if (!html) {
        await closeSessionTab(key);
        return EMPTY;
      }
      const parsed = jsonBlocks(html);
      tokens = tokensOf(html);
      const first = collectionOf(parsed, spec);
      collectionId = collectionId || String(first?.id ?? '');
      docId = docId || docIdOf(html, spec.query) || await docIdFromBundles(tab, html, [], spec.query) || await docIdAfterScroll(tab, html, spec.query);
      cacheSession(key, { tokens });
      if (!received) {
        const page = connectionOf(first, spec);
        push(page.edges);
        const next = String(page.pageInfo?.end_cursor ?? '');
        hasNext = Boolean(page.pageInfo?.has_next_page) && Boolean(next);
        cursor = next || null;
      }
    }

    for (let hop = 0; hop < MAX_HOPS && hasNext && cursor && items.length < limit; hop++) {
      if (!docId || !collectionId || !tokens?.dtsg) {
        break;
      }
      const lines = await graphql(tab, tokens, spec.query, docId, { ...spec.variables, cursor, id: collectionId });
      const page = connectionOf(lines?.[0]?.data?.node, spec);
      if (!page.pageInfo && !page.edges.length) {
        break;
      }
      push(page.edges);
      const next = String(page.pageInfo?.end_cursor ?? '');
      hasNext = Boolean(page.pageInfo?.has_next_page) && Boolean(next) && next !== cursor;
      cursor = next || null;
    }

    const more = hasNext && Boolean(cursor) && cursor !== received;
    if (more) {
      keepSessionAlive(key);
    }
    else {
      await closeSessionTab(key);
    }
    return { items, next_cursor: more && cursor ? encodeCursor({ c: cursor, id: collectionId, d: docId }) : undefined };
  }
  catch {
    await closeSessionTab(key);
    return EMPTY;
  }
}

function collectAds(stories: any[], ads: Map<string, social_resource>): void {
  for (const story of stories) {
    const ad = toAd(story);
    const key = String(ad.resource_id || ad['ad_id'] || ad.url || '');
    if (!key) {
      continue;
    }
    const existing = ads.get(key);
    if (!existing) {
      ads.set(key, ad);
    }
    else if (ad.caption && !existing.caption) {
      ads.set(key, { ...existing, ...ad });
    }
  }
}

export async function advertisements(_payload: CrawlPayload): Promise<CrawlPage> {
  const ads = new Map<string, social_resource>();
  for (let pass = 0; pass < ADS_PASSES; pass++) {
    const tab = await openSession('https://www.facebook.com/');
    if (!tab) {
      continue;
    }
    try {
      const landed = await tab.navigate('https://www.facebook.com/');
      if (landed && /\/login|checkpoint/i.test(landed)) {
        continue;
      }
      await new Promise((resolve) => setTimeout(resolve, 3000));
      const html = await tab.html();
      if (!html) {
        continue;
      }
      const tokens = tokensOf(html);
      const base = feedVariablesOf(html);
      let cursor = feedCursorOf(html);
      const docId = docIdOf(html, FEED_PAGINATION_QUERY) || await docIdFromBundles(tab, html, [], FEED_PAGINATION_QUERY);
      collectAds(sponsoredStories(jsonBlocks(html)), ads);
      let consumed = 0;
      let hasNext = Boolean(cursor) && Boolean(docId) && Boolean(tokens.dtsg);
      for (let hop = 0; hop < MAX_FEED_HOPS && hasNext && consumed < ADS_PER_PASS; hop++) {
        const lines = await graphql(tab, tokens, FEED_PAGINATION_QUERY, docId, { ...base, cursor, count: 10 });
        if (!lines) {
          break;
        }
        collectAds(sponsoredStories(lines), ads);
        consumed += countStories(lines);
        const info = feedPageInfo(lines);
        const next = info ? String(info.end_cursor ?? '') : '';
        hasNext = Boolean(info?.has_next_page) && Boolean(next) && next !== cursor;
        cursor = next;
      }
    }
    catch {
    }
    finally {
      await tab.close();
    }
  }
  return { items: [...ads.values()] };
}

function collectCommenters(entries: { id: string; name: string; url: string; avatar: string; text: string; reactions: string }[], postUrl: string, out: Map<string, social_resource>): void {
  for (const entry of entries) {
    if (out.has(entry.id)) {
      continue;
    }
    out.set(entry.id, {
      type: 'connections',
      resource_id: entry.id,
      url: entry.url,
      parent_url: postUrl,
      title: '',
      caption: entry.text,
      author: entry.name,
      datetime: '',
      media_type: 'user',
      media_url: entry.avatar,
      thumbnail_url: entry.avatar,
      likes: entry.reactions,
      shares: '',
      views: '',
      comment_text: entry.text,
    });
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const postUrl = String(payload.url ?? '');
  if (!postUrl) {
    return EMPTY;
  }
  const key = `fb:connections:${postUrl.toLowerCase()}`;
  const state = decodeCursor(payload);
  const received = state.c ?? '';
  const reused = received ? liveSession(key) : undefined;
  const tab = reused ? reused.tab : await openSessionTab(key, 'https://www.facebook.com/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 50, 100);
    const reelId = /\/reel\/(\d+)/.exec(postUrl)?.[1] ?? '';
    let tokens = reused ? (sessionCache(key)['tokens'] as Tokens | undefined) : undefined;
    let providers = reused ? (sessionCache(key)['providers'] as Record<string, unknown> | undefined) : undefined;
    let feedLocation = reused ? String(sessionCache(key)['feedLocation'] || 'DEDICATED_COMMENTING_SURFACE') : 'DEDICATED_COMMENTING_SURFACE';
    let feedbackId = state.id || '';
    let docId = state.d || '';
    let seededCursor = '';
    const commenters = new Map<string, social_resource>();

    if (!reused) {
      if (reelId && !docId && !cachedCommentsDocId) {
        const homeHtml = await tab.html();
        const homeDoc = homeHtml ? (docIdOf(homeHtml, COMMENTS_QUERY) || await docIdFromBundles(tab, homeHtml, [], COMMENTS_QUERY)) : '';
        if (homeDoc) {
          cachedCommentsDocId = homeDoc;
        }
      }
      const landed = await tab.navigate(postUrl);
      if (landed && /\/login|checkpoint/i.test(landed)) {
        await closeSessionTab(key);
        return EMPTY;
      }
      await new Promise((resolve) => setTimeout(resolve, 3000));
      const html = await tab.html();
      if (!html) {
        await closeSessionTab(key);
        return EMPTY;
      }
      tokens = tokensOf(html);
      docId = docId || docIdOf(html, COMMENTS_QUERY) || await docIdFromBundles(tab, html, [], COMMENTS_QUERY);
      if (!docId && !reelId) {
        docId = await docIdAfterScroll(tab, html, COMMENTS_QUERY);
      }
      docId = docId || cachedCommentsDocId;
      if (docId) {
        cachedCommentsDocId = docId;
      }
      if (reelId) {
        feedLocation = 'COMET_MEDIA_VIEWER';
        providers = REEL_COMMENT_PROVIDERS;
        const reelDocId = docIdOf(html, REEL_FEEDBACK_QUERY) || await docIdFromBundles(tab, html, [], REEL_FEEDBACK_QUERY);
        if (reelDocId && tokens?.dtsg) {
          const railLines = await graphql(tab, tokens, REEL_FEEDBACK_QUERY, reelDocId, { feedbackSource: 65, feedLocation, focusCommentID: null, initial_node_id: reelId, scale: 1, ...REEL_COMMENT_PROVIDERS });
          if (railLines) {
            const seed = reelCommentSeed(railLines);
            feedbackId = feedbackId || seed.feedbackId;
            seededCursor = seed.cursor;
            if (!received) {
              collectCommenters(commentAuthors(railLines), postUrl, commenters);
            }
          }
        }
      }
      else {
        providers = commentProviderFlags(html);
        feedbackId = feedbackId || feedbackIdOf(html);
        if (!received) {
          collectCommenters(commentAuthors(jsonBlocks(html)), postUrl, commenters);
        }
      }
      cacheSession(key, { tokens, providers, feedLocation });
    }

    let cursor = received || seededCursor;
    let hasNext = Boolean(feedbackId) && Boolean(docId) && Boolean(tokens?.dtsg);
    for (let hop = 0; hop < MAX_COMMENT_HOPS && hasNext && commenters.size < limit; hop++) {
      const variables = {
        ...(providers ?? {}),
        commentsAfterCount: 50,
        commentsAfterCursor: cursor || null,
        commentsBeforeCount: null,
        commentsBeforeCursor: null,
        commentsIntentToken: 'RANKED_UNFILTERED_INTENT_V1',
        feedLocation,
        focusCommentID: null,
        scale: 1,
        useDefaultActor: false,
        id: feedbackId,
      };
      const lines = await graphql(tab, tokens as Tokens, COMMENTS_QUERY, docId, variables);
      if (!lines) {
        break;
      }
      collectCommenters(commentAuthors(lines), postUrl, commenters);
      const info = commentCursor(lines);
      hasNext = info.has_next_page && Boolean(info.next) && info.next !== cursor;
      cursor = info.next;
    }

    const more = hasNext && Boolean(cursor) && cursor !== received;
    if (more) {
      keepSessionAlive(key);
    }
    else {
      await closeSessionTab(key);
    }
    return { items: [...commenters.values()], next_cursor: more && cursor ? encodeCursor({ c: cursor, id: feedbackId, d: docId }) : undefined };
  }
  catch {
    await closeSessionTab(key);
    return EMPTY;
  }
}
