export interface TimelineCursor {
  c: string;
  id: string;
  d: string;
}

export interface Tokens {
  dtsg: string;
  lsd: string;
  user: string;
  jazoest: string;
}

export type CollectionKind = 'reels' | 'images' | 'followers' | 'friends';

export interface CollectionSpec {
  path: string;
  renderer: string;
  query: string;
  connection: string;
  name?: string;
  variables: Record<string, unknown>;
}
