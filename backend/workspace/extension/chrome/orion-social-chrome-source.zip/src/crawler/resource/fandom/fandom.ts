import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, continuation, origin, page } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '').replace(/_/g, ' ');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const data = await api(tab, base, {
      action: 'query',
      list: 'usercontribs',
      ucuser: username,
      uclimit: String(limitOf(payload, 25, 500)),
      ucprop: 'ids|title|timestamp|comment|parsedcomment|size|sizediff|flags|tags',
      ...continuation(payload),
    });

    const items = (data?.query?.usercontribs ?? []) as any[];
    return page(items.map((entry: any): social_resource => {
      const title = entry.title ?? '';
      return {
        type: 'posts',
        resource_id: String(entry.revid ?? ''),
        url: entry.revid ? `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}?oldid=${entry.revid}` : '',
        parent_url: `${base}/wiki/User:${encodeURIComponent(username.replace(/ /g, '_'))}`,
        title,
        caption: clean(entry.comment),
        author: entry.user ?? username,
        datetime: entry.timestamp ?? '',
        media_type: 'revision',
        media_url: `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        revision_id: entry.revid ?? 0,
        parent_revision_id: entry.parentid ?? 0,
        page_id: entry.pageid ?? 0,
        page_title: title,
        page_url: `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        namespace: entry.ns ?? 0,
        namespace_name: title.includes(':') ? title.split(':')[0] : 'Article',
        user_id: entry.userid ?? 0,
        user_name: entry.user ?? username,
        comment: clean(entry.comment),
        parsed_comment: clean(entry.parsedcomment),
        section: /\/\*\s*(.*?)\s*\*\//.exec(String(entry.comment ?? ''))?.[1] ?? '',
        size_bytes: entry.size ?? 0,
        size_diff: entry.sizediff ?? 0,
        is_new: entry.new ?? false,
        is_minor: entry.minor ?? false,
        is_top: entry.top ?? false,
        tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
        tags_count: Array.isArray(entry.tags) ? entry.tags.length : 0,
        diff_url: entry.revid ? `${base}/index.php?title=${encodeURIComponent(title)}&diff=${entry.revid}&oldid=${entry.parentid ?? 0}` : '',
        history_url: `${base}/index.php?title=${encodeURIComponent(title)}&action=history`,
        wiki_host: base,
        wiki_name: base.replace(/^https?:\/\//, '').replace(/\.fandom\.com$/, ''),
        timestamp: entry.timestamp ?? '',
      };
    }).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '').replace(/_/g, ' ');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const data = await api(tab, base, {
      action: 'query',
      list: 'logevents',
      letype: 'upload',
      leuser: username,
      lelimit: String(limitOf(payload, 25, 500)),
      leprop: 'ids|title|type|user|userid|timestamp|comment|parsedcomment|tags',
      ...continuation(payload),
    });

    const items = (data?.query?.logevents ?? []) as any[];
    return page(items.map((entry: any): social_resource => {
      const title = entry.title ?? '';
      return {
        type: 'images',
        resource_id: String(entry.logid ?? ''),
        url: `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        parent_url: `${base}/wiki/User:${encodeURIComponent(username.replace(/ /g, '_'))}`,
        title,
        caption: clean(entry.comment),
        author: entry.user ?? username,
        datetime: entry.timestamp ?? '',
        media_type: 'file',
        media_url: `${base}/wiki/Special:Redirect/file/${encodeURIComponent(title.replace(/^File:/i, '').replace(/ /g, '_'))}`,
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        log_id: entry.logid ?? 0,
        log_action: entry.action ?? '',
        log_type: entry.type ?? '',
        file_title: title,
        file_name: title.replace(/^File:/i, ''),
        page_id: entry.pageid ?? 0,
        namespace: entry.ns ?? 0,
        user_name: entry.user ?? '',
        user_id: entry.userid ?? 0,
        comment: clean(entry.comment),
        parsed_comment: clean(entry.parsedcomment),
        tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
        wiki_host: base,
        wiki_name: base.replace(/^https?:\/\//, '').replace(/\.fandom\.com$/, ''),
        timestamp: entry.timestamp ?? '',
      };
    }).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
