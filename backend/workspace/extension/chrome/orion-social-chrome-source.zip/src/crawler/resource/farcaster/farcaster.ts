import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };
const API = 'https://api.warpcast.com';

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function isoOf(ms: unknown): string {
  const n = Number(ms);
  return Number.isFinite(n) && n > 0 ? new Date(n).toISOString() : '';
}

export async function userByName(username: string): Promise<any> {
  const handle = username.replace(/^@/, '').trim();
  const response = await fetch(`${API}/v2/user-by-username?username=${encodeURIComponent(handle)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  return data?.result?.user ?? null;
}

export async function details(username: string): Promise<social_profile_details[]> {
  const user = await userByName(username);
  if (!user?.fid) {
    return [];
  }

  const profile = user.profile ?? {};
  return [{
    real_name: clean(user.displayName) || user.username,
    bio: clean(profile.bio?.text),
    description: clean(profile.bio?.text),
    location: clean(profile.location?.description),
    profile_url: `https://warpcast.com/${user.username}`,
    total_posts: '',
    total_followers: String((user.followerCount ?? 0) || ''),
    total_likes: '',
    avatar: user.pfp?.url ?? '',
    banner: '',
    crawl_type: ['details', 'posts'],
    platform: 'farcaster',
    username: user.username,
    fid: user.fid,
    follower_count: user.followerCount ?? 0,
    following_count: user.followingCount ?? 0,
    active_on_fc_network: Boolean(user.activeOnFcNetwork),
  }];
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const user = await userByName(username);
    const fid = user?.fid;
    if (!fid) {
      return EMPTY;
    }

    const limit = limitOf(payload, 25, 50);
    const cursor = String(payload.cursor ?? '').trim();
    const url = `${API}/v2/casts?fid=${encodeURIComponent(fid)}&limit=${limit}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`;
    const response = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }
    const data = await response.json();
    const rows: any[] = Array.isArray(data?.result?.casts) ? data.result.casts : [];
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((cast: any): social_resource => {
      const hash = String(cast.hash ?? '');
      const author = cast.author?.username ?? user.username;
      const embeds = cast.embeds ?? {};
      const media = [...(Array.isArray(embeds.images) ? embeds.images.map((image: any) => image?.url) : []), ...(Array.isArray(embeds.urls) ? embeds.urls.map((entry: any) => entry?.openGraph?.url ?? entry?.url) : [])].filter(Boolean);
      return {
        type: 'posts',
        resource_id: hash,
        url: `https://warpcast.com/${author}/${hash.slice(0, 10)}`,
        parent_url: `https://warpcast.com/${user.username}`,
        title: clean(cast.text).slice(0, 80) || `Cast ${hash.slice(0, 10)}`,
        caption: clean(cast.text),
        author,
        datetime: isoOf(cast.timestamp),
        media_type: 'cast',
        media_url: media[0] ?? '',
        thumbnail_url: (Array.isArray(embeds.images) && embeds.images.length ? embeds.images[0]?.url : '') ?? '',
        likes: String((cast.reactions?.count ?? 0) || ''),
        shares: String((cast.recasts?.count ?? cast.combinedRecastCount ?? 0) || ''),
        views: String((cast.viewCount ?? 0) || ''),
        content: clean(cast.text),
        replies_count: cast.replies?.count ?? 0,
        reactions_count: cast.reactions?.count ?? 0,
        recasts_count: cast.recasts?.count ?? cast.combinedRecastCount ?? 0,
        quote_count: cast.quoteCount ?? 0,
        media_urls: media.join(', '),
        timestamp: isoOf(cast.timestamp),
      };
    }).filter((item) => item.url && item.resource_id);

    const nextCursor = data?.next?.cursor;
    return { items, next_cursor: items.length && nextCursor ? String(nextCursor) : undefined };
  }
  catch {
    return EMPTY;
  }
}
