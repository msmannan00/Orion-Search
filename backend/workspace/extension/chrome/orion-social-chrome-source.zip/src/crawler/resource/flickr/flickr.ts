import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, MAX_PER_PAGE } from './constant';
import { albumFromApi, albumsFromHtml, decode, feed, imageFromApi, imageFromFeed, nextCursor, paged, parseCursor, resolve, rest } from './helper';

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.flickr.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = parseCursor(payload);
    const perPage = limitOf(payload, 25, MAX_PER_PAGE);
    const result = await paged(tab, username, cursor, (context, page) => rest(tab, 'flickr.people.getPublicPhotos', context.key, {
      user_id: context.nsid,
      page,
      per_page: perPage,
      extras: 'description,date_upload,date_taken,owner_name,license,tags,views,media,path_alias,url_t,url_s,url_b,url_o',
    }));

    if (result) {
      const photos = (Array.isArray(result.data?.photos?.photo) ? result.data.photos.photo : []) as any[];
      const items = photos.map((photo: any) => imageFromApi(username, result.context, photo)).filter((item) => item.url);
      return { items, next_cursor: nextCursor(items, result.page, result.data?.photos?.pages, result.context) };
    }

    if (cursor) {
      return EMPTY;
    }

    const id = /^\d+@N\d+$/.test(username) ? username : (await resolve(tab, username))?.nsid ?? '';
    if (!id) {
      return EMPTY;
    }
    const items = (await feed(tab, id)).map((item: any) => imageFromFeed(username, id, item)).filter((item) => item.url);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.flickr.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = parseCursor(payload);
    const perPage = limitOf(payload, 25, MAX_PER_PAGE);
    const result = await paged(tab, username, cursor, (context, page) => rest(tab, 'flickr.photosets.getList', context.key, {
      user_id: context.nsid,
      page,
      per_page: perPage,
      primary_photo_extras: 'url_m,url_s',
    }));

    if (result) {
      const sets = (Array.isArray(result.data?.photosets?.photoset) ? result.data.photosets.photoset : []) as any[];
      const items = sets.map((set: any) => albumFromApi(username, result.context, set)).filter((item) => item.url);
      return { items, next_cursor: nextCursor(items, result.page, result.data?.photosets?.pages, result.context) };
    }

    if (cursor) {
      return EMPTY;
    }

    return albumsFromHtml(tab, username);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.flickr.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = parseCursor(payload);
    if (cursor) {
      return EMPTY;
    }
    const result = await paged(tab, username, cursor, (context) => rest(tab, 'flickr.people.getPublicGroups', context.key, {
      user_id: context.nsid,
    }));
    if (!result) {
      return EMPTY;
    }
    const groups = (Array.isArray(result.data?.groups?.group) ? result.data.groups.group : []) as any[];
    const items = groups.map((group: any): social_resource => ({
      type: 'organizations',
      resource_id: String(group.nsid ?? ''),
      url: group.nsid ? `https://www.flickr.com/groups/${group.nsid}/` : '',
      parent_url: `https://www.flickr.com/people/${username}/`,
      title: decode(group.name),
      caption: '',
      author: username,
      datetime: '',
      media_type: 'group',
      media_url: group.nsid ? `https://www.flickr.com/groups/${group.nsid}/` : '',
      thumbnail_url: '',
      likes: '',
      shares: '',
      views: '',
      group_id: String(group.nsid ?? ''),
      name: decode(group.name),
      members: group.members ?? 0,
      pool_count: group.pool_count ?? 0,
      is_admin: group.admin ?? 0,
      is_invitation_only: group.invitation_only ?? 0,
    })).filter((item) => item.url);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
