import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const GAMES_PER_PAGE = 36;
export const POSTS_PER_PAGE = 10;
export const MAX_POST_FETCHES = 5;

export const FOLLOW_PER_PAGE = 24;
