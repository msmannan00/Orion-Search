import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://gamejolt.com/site-api${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? (JSON.parse(response.body))?.payload ?? null : null;
  }
  catch {
    return null;
  }
}

export function stamp(value: unknown): string {
  const millis = Number(value);
  return Number.isFinite(millis) && millis > 0 ? new Date(millis).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function parseCursor(payload: CrawlPayload): Record<string, unknown> {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return {};
  }
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  }
  catch {
    return {};
  }
}

export function positive(value: unknown, fallback: number): number {
  const n = Math.floor(Number(value));
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

export function scrollId(entry: any): string {
  const raw = entry?.scroll_id ?? entry?.scrollId;
  if (raw == null) {
    return '';
  }
  return typeof raw === 'string' ? raw : JSON.stringify(raw);
}
