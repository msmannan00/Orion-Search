import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { nextCursor } from './helper';

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://github.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const url = String(payload.cursor ?? '').trim() || `https://github.com/${encodeURIComponent(username)}?tab=repositories`;
    const response = await tab.fetch(url);
    const doc = new DOMParser().parseFromString(response.body, 'text/html');

    const items = Array.from(doc.querySelectorAll('li[itemprop="owns"]')).map((row): social_resource => {
      const path = row.querySelector('a[itemprop="name codeRepository"]')?.getAttribute('href') ?? '';
      return {
        type: 'repositories',
        resource_id: path.replace(/^\//, ''),
        url: path ? `https://github.com${path}` : '',
        parent_url: `https://github.com/${username}`,
        title: row.querySelector('a[itemprop="name codeRepository"]')?.textContent?.trim() ?? '',
        caption: row.querySelector('[itemprop="description"]')?.textContent?.trim() ?? '',
        author: username,
        datetime: row.querySelector('relative-time')?.getAttribute('datetime') ?? '',
        media_type: 'repository',
        media_url: path ? `https://github.com${path}` : '',
        thumbnail_url: '',
        likes: row.querySelector('a[href$="/stargazers"]')?.textContent?.trim() ?? '',
        shares: row.querySelector('a[href$="/forks"]')?.textContent?.trim() ?? '',
        views: '',
        language: row.querySelector('[itemprop="programmingLanguage"]')?.textContent?.trim() ?? '',
        visibility: row.querySelector('span.Label')?.textContent?.trim() ?? '',
        is_fork: /forked from/i.test(row.textContent ?? ''),
        parent_repo: (/forked from\s*<a[^>]*href="\/([^"]+)"/i.exec(row.innerHTML)?.[1] ?? '').trim(),
        topics: Array.from(row.querySelectorAll('a.topic-tag')).map((topic) => topic.textContent?.trim() ?? '').filter(Boolean),
        license: (row.querySelector('[itemprop="license"]')?.textContent ?? Array.from(row.querySelectorAll('span.mr-3')).map((span) => span.textContent?.trim() ?? '').find((text) => /license|MIT|Apache|GPL|BSD/i.test(text)) ?? '').trim(),
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length ? nextCursor(doc, url) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://github.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const url = String(payload.cursor ?? '').trim() || `https://github.com/${encodeURIComponent(username)}?tab=followers`;
    const response = await tab.fetch(url);
    const doc = new DOMParser().parseFromString(response.body, 'text/html');

    const items = Array.from(doc.querySelectorAll('.d-table.table-fixed')).map((row): social_resource => {
      const login = (row.querySelector('a[data-hovercard-type="user"]')?.getAttribute('href') ?? '').replace(/^\//, '');
      return {
        type: 'followers',
        resource_id: login,
        url: login ? `https://github.com/${login}` : '',
        parent_url: `https://github.com/${username}`,
        title: row.querySelector('.Link--primary')?.textContent?.trim() || login,
        caption: row.querySelector('.text-small')?.textContent?.replace(/\s+/g, ' ').trim() ?? '',
        author: login,
        datetime: '',
        media_type: 'user',
        media_url: login ? `https://github.com/${login}` : '',
        thumbnail_url: row.querySelector('img.avatar')?.getAttribute('src') ?? '',
        likes: '',
        shares: '',
        views: '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length ? nextCursor(doc, url) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}


export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://github.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const response = await tab.fetch(`https://github.com/${encodeURIComponent(username)}`);
    const doc = new DOMParser().parseFromString(response.body, 'text/html');

    const items = Array.from(doc.querySelectorAll('a[data-hovercard-type="organization"]')).map((link): social_resource => {
      const login = (link.getAttribute('href') ?? '').replace(/^\//, '');
      return {
        type: 'organizations',
        resource_id: login,
        url: login ? `https://github.com/${login}` : '',
        parent_url: `https://github.com/${username}`,
        title: login,
        caption: '',
        author: login,
        datetime: '',
        media_type: 'organization',
        media_url: login ? `https://github.com/${login}` : '',
        thumbnail_url: link.querySelector('img')?.getAttribute('src') ?? '',
        likes: '',
        shares: '',
        views: '',
      };
    }).filter((item) => item.url);

    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gist.github.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const url = String(payload.cursor ?? '').trim() || `https://gist.github.com/${encodeURIComponent(username)}`;
    const response = await tab.fetch(url);
    const doc = new DOMParser().parseFromString(response.body, 'text/html');

    const items = Array.from(doc.querySelectorAll('.gist-snippet')).map((row): social_resource => {
      const name = row.querySelector('strong.css-truncate-target');
      const path = name?.closest('a')?.getAttribute('href') ?? '';
      return {
        type: 'projects',
        resource_id: path.split('/').pop() ?? '',
        url: path ? `https://gist.github.com${path}` : '',
        parent_url: `https://gist.github.com/${username}`,
        title: name?.textContent?.trim() ?? '',
        caption: row.querySelector('span.f6.color-fg-muted')?.textContent?.replace(/\s+/g, ' ').trim() ?? '',
        author: username,
        datetime: row.querySelector('relative-time')?.getAttribute('datetime') ?? '',
        media_type: 'gist',
        media_url: path ? `https://gist.github.com${path}` : '',
        thumbnail_url: row.querySelector('img')?.getAttribute('src') ?? '',
        likes: row.querySelector('a[href$="/stargazers"]')?.textContent?.trim() ?? '',
        shares: row.querySelector('a[href$="/forks"]')?.textContent?.trim() ?? '',
        views: '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length ? nextCursor(doc, url) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://github.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const response = await tab.fetch(`https://github.com/${encodeURIComponent(username)}.atom`);
    const doc = new DOMParser().parseFromString(response.body, 'application/xml');

    const items = Array.from(doc.querySelectorAll('entry')).map((entry): social_resource => {
      const id = entry.querySelector('id')?.textContent?.trim() ?? '';
      const url = entry.querySelector('link')?.getAttribute('href') ?? '';
      const event = id.split(':').pop()?.split('/')[0] ?? '';
      const contentDoc = new DOMParser().parseFromString(entry.querySelector('content')?.textContent ?? '', 'text/html');
      const contentText = (contentDoc.body?.textContent ?? '').replace(/\s+/g, ' ').trim();
      const repo = /github\.com\/([^/\s"]+\/[^/\s"]+)/.exec(url)?.[1] ?? '';
      const commitLines = Array.from(contentDoc.querySelectorAll('.commits li, li:has(a[href*="/commit/"])')).map((item) => {
        const sha = (item.querySelector('a[href*="/commit/"]')?.textContent ?? '').trim();
        const message = (item.textContent ?? '').replace(/\s+/g, ' ').replace(sha, '').trim();
        return [sha, message].filter(Boolean).join(' ');
      }).filter((line, position, all) => line && all.indexOf(line) === position);
      const summary = contentText.replace(/^.*?\d{4}\s+\d{2}:\d{2}\s*/, '').trim();
      return {
        type: 'posts',
        resource_id: id.split(':').pop() ?? '',
        url,
        parent_url: `https://github.com/${username}`,
        title: entry.querySelector('title')?.textContent?.trim() ?? '',
        caption: (commitLines.length ? commitLines.join('\n') : summary || contentText).slice(0, 800),
        author: entry.querySelector('author > name')?.textContent?.trim() ?? username,
        datetime: entry.querySelector('published')?.textContent?.trim() ?? '',
        media_type: event,
        media_url: url,
        thumbnail_url: entry.querySelector('thumbnail')?.getAttribute('url') ?? '',
        likes: '',
        shares: '',
        views: '',
        event,
        repo,
        repo_url: repo ? `https://github.com/${repo}` : '',
        branch: /(?:to|created branch|branch)\s+(\S+)\s+(?:in|at)\s/i.exec(contentText)?.[1] ?? '',
        commit_count: /(\d+)\s+commits?\s+to/i.exec(contentText)?.[1] ?? (commitLines.length ? String(commitLines.length) : ''),
      };
    }).filter((item) => item.url);

    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
