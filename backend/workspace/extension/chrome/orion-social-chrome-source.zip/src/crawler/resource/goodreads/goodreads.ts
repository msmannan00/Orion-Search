import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { userId, walk } from './helper';

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const tab = userId(payload) ? await openSession('https://www.goodreads.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return await walk(tab, payload, ['read'], 'reviews');
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const tab = userId(payload) ? await openSession('https://www.goodreads.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return await walk(tab, payload, ['currently-reading', 'to-read'], 'posts');
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
