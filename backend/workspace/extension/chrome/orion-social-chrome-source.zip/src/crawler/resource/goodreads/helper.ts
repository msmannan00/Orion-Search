import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { ShelfCursor } from './model';

export function userId(payload: CrawlPayload): string {
  const url = String(payload.url ?? '');
  const fromUrl = /goodreads\.com\/user\/show\/(\d+)/.exec(url)?.[1];
  if (fromUrl) {
    return fromUrl;
  }
  const username = String(payload.username ?? '');
  return /^\d+/.exec(username)?.[0] ?? '';
}

export function decode(value: string): string {
  return value.replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function tag(block: string, name: string): string {
  return decode(new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`, 'i').exec(block)?.[1] ?? '');
}

export function cursorOf(payload: CrawlPayload, shelves: readonly string[]): ShelfCursor {
  const fallback: ShelfCursor = { shelf: shelves[0], page: 1, per_page: limitOf(payload, 25, 200) };
  try {
    const parsed: any = JSON.parse(String(payload.cursor ?? '').trim() || '{}');
    const page = Number.parseInt(String(parsed?.page ?? ''), 10);
    const perPage = Number.parseInt(String(parsed?.per_page ?? ''), 10);
    return {
      shelf: shelves.includes(String(parsed?.shelf ?? '')) ? String(parsed.shelf) : fallback.shelf,
      page: Number.isFinite(page) && page > 0 ? page : fallback.page,
      per_page: Number.isFinite(perPage) && perPage > 0 ? Math.min(perPage, 200) : fallback.per_page,
    };
  }
  catch {
    return fallback;
  }
}

export function advance(current: ShelfCursor, full: boolean, shelves: readonly string[]): ShelfCursor | undefined {
  if (full) {
    return { ...current, page: current.page + 1 };
  }
  const next = shelves[shelves.indexOf(current.shelf) + 1];
  return next ? { ...current, shelf: next, page: 1 } : undefined;
}

export async function shelf(tab: TabController, id: string, position: ShelfCursor): Promise<string[]> {
  try {
    const response = await tab.fetch(`https://www.goodreads.com/review/list_rss/${encodeURIComponent(id)}?shelf=${encodeURIComponent(position.shelf)}&page=${position.page}&per_page=${position.per_page}`);
    if (!response.ok) {
      return [];
    }
    const xml = response.body;
    return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((match) => match[1]);
  }
  catch {
    return [];
  }
}

export function book(id: string, shelfName: string, block: string): social_resource {
  const link = tag(block, 'link');
  const rating = Number(tag(block, 'user_rating')) || 0;
  const review = tag(block, 'user_review');
  return {
    type: 'reviews',
    resource_id: /review\/show\/(\d+)/.exec(link)?.[1] ?? tag(block, 'book_id'),
    url: link.split('?')[0],
    parent_url: `https://www.goodreads.com/user/show/${id}`,
    title: tag(block, 'title'),
    caption: review || tag(block, 'book_description').slice(0, 800),
    author: tag(block, 'user_name'),
    datetime: tag(block, 'user_date_added'),
    media_type: 'book_review',
    media_url: `https://www.goodreads.com/book/show/${tag(block, 'book_id')}`,
    thumbnail_url: tag(block, 'book_large_image_url') || tag(block, 'book_image_url'),
    likes: '',
    shares: '',
    views: '',
    review_id: /review\/show\/(\d+)/.exec(link)?.[1] ?? '',
    book_id: tag(block, 'book_id'),
    book_url: `https://www.goodreads.com/book/show/${tag(block, 'book_id')}`,
    book_title: tag(block, 'title'),
    book_author: tag(block, 'author_name'),
    book_description: tag(block, 'book_description').slice(0, 3000),
    book_pages: Number(/<num_pages>(\d+)<\/num_pages>/.exec(block)?.[1] ?? 0),
    book_published: tag(block, 'book_published'),
    isbn: tag(block, 'isbn'),
    average_rating: Number(tag(block, 'average_rating')) || 0,
    user_rating: rating,
    user_stars: rating ? '★'.repeat(rating) : '',
    user_review: review,
    review_length: review.length,
    has_review: review.length > 0,
    user_name: tag(block, 'user_name'),
    user_shelves: tag(block, 'user_shelves'),
    shelf: shelfName,
    user_read_at: tag(block, 'user_read_at'),
    user_date_added: tag(block, 'user_date_added'),
    user_date_created: tag(block, 'user_date_created'),
    image_small: tag(block, 'book_small_image_url'),
    image_medium: tag(block, 'book_medium_image_url'),
    image_large: tag(block, 'book_large_image_url'),
    guid: tag(block, 'guid'),
    published_at: tag(block, 'pubDate'),
  };
}

export async function walk(tab: TabController, payload: CrawlPayload, shelves: readonly string[], type: 'reviews' | 'posts'): Promise<CrawlPage> {
  const id = userId(payload);
  if (!id) {
    return EMPTY;
  }

  let position: ShelfCursor | undefined = cursorOf(payload, shelves);
  let items: social_resource[] = [];
  for (let guard = 0; position && guard < shelves.length; guard++) {
    const current: ShelfCursor = position;
    const blocks = await shelf(tab, id, current);
    items = blocks.map((block: string): social_resource => ({ ...book(id, current.shelf, block), type })).filter((item) => item.url);
    position = advance(current, blocks.length >= current.per_page, shelves);
    if (items.length) {
      break;
    }
  }

  return { items, next_cursor: items.length && position ? JSON.stringify(position) : undefined };
}
