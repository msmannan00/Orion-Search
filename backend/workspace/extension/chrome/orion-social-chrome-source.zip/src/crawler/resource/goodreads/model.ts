export interface ShelfCursor {
  shelf: string;
  page: number;
  per_page: number;
}
