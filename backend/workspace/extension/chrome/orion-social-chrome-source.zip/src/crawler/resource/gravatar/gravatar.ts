import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { clean, page, profile } from './helper';

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gravatar.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const entry = await profile(tab, username);
    if (!entry) {
      return EMPTY;
    }

    const photos: any[] = Array.isArray(entry.photos) ? entry.photos : [];
    const hash = entry.hash ?? '';
    const sizes = [80, 200, 512, 1024];
    const items: social_resource[] = photos.map((photo: any, index: number): social_resource => ({
      type: 'images',
      resource_id: `${hash}-${index}`,
      url: photo.value ?? '',
      parent_url: entry.profileUrl ?? `https://gravatar.com/${username}`,
      title: photo.type ?? 'photo',
      caption: clean(entry.aboutMe).slice(0, 300),
      author: entry.preferredUsername ?? username,
      datetime: '',
      media_type: photo.type ?? 'thumbnail',
      media_url: photo.value ? `${photo.value}?s=1024` : '',
      thumbnail_url: photo.value ? `${photo.value}?s=200` : '',
      likes: '',
      shares: '',
      views: '',
      photo_type: photo.type ?? '',
      photo_url: photo.value ?? '',
      hash,
      request_hash: entry.requestHash ?? '',
      profile_url: entry.profileUrl ?? '',
      preferred_username: entry.preferredUsername ?? '',
      display_name: entry.displayName ?? '',
      about_me: clean(entry.aboutMe),
      ...Object.fromEntries(sizes.map((size) => [`size_${size}`, photo.value ? `${photo.value}?s=${size}` : ''])),
      avatar_url: entry.thumbnailUrl ?? '',
      is_primary: index === 0,
      background_color: entry.profileBackground?.color ?? '',
      background_url: entry.profileBackground?.url ?? '',
    }));

    return page(items.filter((item) => item.url));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gravatar.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const entry = await profile(tab, username);
    if (!entry) {
      return EMPTY;
    }

    const accounts: any[] = Array.isArray(entry.accounts) ? entry.accounts : [];
    const urls: any[] = Array.isArray(entry.urls) ? entry.urls : [];

    return page([
      ...accounts.map((account: any): social_resource => ({
        type: 'organizations',
        resource_id: `${account.shortname ?? account.domain ?? ''}-${account.username ?? ''}`,
        url: account.url ?? '',
        parent_url: entry.profileUrl ?? `https://gravatar.com/${username}`,
        title: account.name ?? account.domain ?? '',
        caption: account.display ?? '',
        author: entry.preferredUsername ?? username,
        datetime: '',
        media_type: 'verified_account',
        media_url: account.url ?? '',
        thumbnail_url: account.iconUrl ?? '',
        likes: '',
        shares: '',
        views: '',
        kind: 'account',
        service_name: account.name ?? '',
        service_shortname: account.shortname ?? '',
        service_domain: account.domain ?? '',
        service_icon: account.iconUrl ?? '',
        account_username: account.username ?? '',
        account_display: account.display ?? '',
        account_url: account.url ?? '',
        is_verified: account.verified ?? false,
        is_hidden: account.is_hidden ?? false,
        link_title: '',
        hash: entry.hash ?? '',
        profile_url: entry.profileUrl ?? '',
      })),
      ...urls.map((link: any): social_resource => ({
        type: 'organizations',
        resource_id: link.value ?? '',
        url: link.value ?? '',
        parent_url: entry.profileUrl ?? `https://gravatar.com/${username}`,
        title: link.title ?? '',
        caption: link.value ?? '',
        author: entry.preferredUsername ?? username,
        datetime: '',
        media_type: 'link',
        media_url: link.value ?? '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        kind: 'link',
        service_name: '',
        service_shortname: '',
        service_domain: String(link.value ?? '').replace(/^https?:\/\//, '').split('/')[0],
        service_icon: '',
        account_username: '',
        account_display: '',
        account_url: link.value ?? '',
        is_verified: false,
        is_hidden: false,
        link_title: link.title ?? '',
        hash: entry.hash ?? '',
        profile_url: entry.profileUrl ?? '',
      })),
    ].filter((item) => item.url));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
