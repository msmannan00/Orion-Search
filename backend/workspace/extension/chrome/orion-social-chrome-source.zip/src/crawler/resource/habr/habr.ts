import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { COMMENTS_MAX_FETCHES, COMMENTS_PER_PAGE, EMPTY } from './constant';
import { api, clean, comment_of, commentsCursor, host, language, pageOf, totalPages } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const base = host(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`https://${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const lang = language(payload);
    const page = pageOf(payload.cursor);
    const perPage = limitOf(payload, 25, 100);
    const data = await api(tab, base, `/articles/?user=${encodeURIComponent(username)}&page=${page}&perPage=${perPage}`);
    const refs = data?.publicationRefs ?? {};
    const ids: string[] = Array.isArray(data?.publicationIds) ? data.publicationIds : Object.keys(refs);

    const items = ids.map((id: string): social_resource => {
      const article: any = refs[id] ?? {};
      const author = article.author ?? {};
      const statistics = article.statistics ?? {};
      const hubs: any[] = Array.isArray(article.hubs) ? article.hubs : [];
      const tags: any[] = Array.isArray(article.tags) ? article.tags : [];
      return {
        type: 'posts',
        resource_id: String(article.id ?? id),
        url: `https://${base}/${lang}/articles/${article.id ?? id}/`,
        parent_url: `https://${base}/${lang}/users/${username}/`,
        title: clean(article.titleHtml),
        caption: clean(article.leadData?.textHtml ?? article.textHtml).slice(0, 2000),
        author: author.alias ?? username,
        datetime: article.timePublished ?? '',
        media_type: article.postType ?? 'article',
        media_url: article.leadData?.imageUrl ?? '',
        thumbnail_url: article.leadData?.imageUrl ?? '',
        likes: String((statistics.score ?? 0) || ''),
        shares: '',
        views: String((statistics.readingCount ?? 0) || ''),
        article_id: article.id ?? id,
        title_text: clean(article.titleHtml),
        lead_text: clean(article.leadData?.textHtml).slice(0, 2000),
        post_type: article.postType ?? '',
        publication_type: article.publicationType ?? '',
        editor_version: article.editorVersion ?? '',
        language: article.lang ?? lang,
        is_corporative: article.isCorporative ?? false,
        is_tutorial: Array.isArray(article.postLabels) && article.postLabels.some((label: any) => /tutorial/i.test(label?.type ?? '')),
        post_labels: Array.isArray(article.postLabels) ? article.postLabels.map((label: any) => label?.type ?? '').filter(Boolean).join(', ') : '',
        reading_time: article.readingTime ?? 0,
        comments_count: statistics.commentsCount ?? 0,
        favorites_count: statistics.favoritesCount ?? 0,
        reading_count: statistics.readingCount ?? 0,
        score: statistics.score ?? 0,
        votes_count: statistics.votesCount ?? 0,
        votes_plus: statistics.votesCountPlus ?? 0,
        votes_minus: statistics.votesCountMinus ?? 0,
        reach: statistics.reach ?? 0,
        readers: statistics.readers ?? 0,
        hubs: hubs.map((hub: any) => hub?.title ?? '').filter(Boolean).join(', '),
        hub_aliases: hubs.map((hub: any) => hub?.alias ?? '').filter(Boolean).join(', '),
        hubs_count: hubs.length,
        corporate_hubs: hubs.filter((hub: any) => hub?.type === 'corporative').map((hub: any) => hub?.title ?? '').join(', '),
        tags: tags.map((tag: any) => tag?.titleHtml ?? tag?.title ?? '').filter(Boolean).join(', '),
        tags_count: tags.length,
        author_id: author.id ?? '',
        author_alias: author.alias ?? '',
        author_fullname: author.fullname ?? '',
        author_avatar: author.avatarUrl ? `https:${String(author.avatarUrl).replace(/^https?:/, '')}` : '',
        author_speciality: author.speciality ?? '',
        author_deleted: author.deleted ?? false,
        comments_url: `https://${base}/${lang}/articles/${article.id ?? id}/comments/`,
        time_published: article.timePublished ?? '',
      };
    }).filter((item) => item.resource_id);

    const total = totalPages(data);
    const hasMore = Number.isFinite(total) ? page < total : ids.length >= perPage;
    return { items, next_cursor: items.length && hasMore ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const base = host(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`https://${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const lang = language(payload);
    const limit = limitOf(payload, COMMENTS_PER_PAGE, COMMENTS_PER_PAGE * COMMENTS_MAX_FETCHES);
    const items: social_resource[] = [];
    let { page, skip } = commentsCursor(payload.cursor);
    let next: string | undefined;

    for (let fetches = 0; fetches < COMMENTS_MAX_FETCHES && items.length < limit; fetches++) {
      const data = await api(tab, base, `/users/${encodeURIComponent(username)}/comments/?page=${page}`);
      if (!data) {
        next = undefined;
        break;
      }

      const refs = data?.commentRefs ?? data?.comments ?? {};
      const ids: string[] = Array.isArray(data?.commentIds) ? data.commentIds : Array.isArray(data?.threads) ? data.threads.map(String) : Object.keys(refs ?? {});
      const total = totalPages(data);
      const lastPage = Number.isFinite(total) ? page >= total : ids.length < COMMENTS_PER_PAGE;

      let consumed = skip;
      for (; consumed < ids.length && items.length < limit; consumed++) {
        const item = comment_of(base, lang, username, ids[consumed], refs);
        if (item.url) {
          items.push(item);
        }
      }

      if (consumed < ids.length) {
        next = JSON.stringify({ page, skip: consumed });
        break;
      }

      next = lastPage ? undefined : JSON.stringify({ page: page + 1, skip: 0 });
      if (lastPage) {
        break;
      }
      page += 1;
      skip = 0;
    }

    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const base = host(payload);
  const lang = language(payload);
  const postUrl = String(payload.url ?? '');
  const named = /\/(?:articles|post|blog)\/(\d+)/.exec(postUrl)?.[1] ?? /\/(\d+)\/?(?:[?#].*)?$/.exec(postUrl)?.[1] ?? '';
  const username = String(payload.username ?? '');
  if (!named && !username) {
    return EMPTY;
  }
  const tab = await openSession(`https://${base}/`);
  if (!tab) {
    return EMPTY;
  }
  try {
    // A profile names no article, so the author's newest one stands in for it.
    let id = named;
    if (!id) {
      const owned = await api(tab, base, `/articles/?fl=${lang}&user=${encodeURIComponent(username)}&page=1`);
      const list: any[] = Array.isArray(owned?.publicationIds) ? owned.publicationIds : [];
      id = String(list[0] ?? '');
    }
    if (!id) {
      return EMPTY;
    }
    const data = await api(tab, base, `/articles/${id}/comments/?fl=${lang}`);
    const map = (data?.comments ?? {}) as Record<string, any>;
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const key of Object.keys(map)) {
      const comment = map[key] ?? {};
      if (Number(comment.parentId ?? 0) !== 0) {
        continue;
      }
      const alias = String(comment.author?.alias ?? '');
      if (!alias || seen.has(alias)) {
        continue;
      }
      seen.add(alias);
      items.push({
        type: 'connections',
        resource_id: alias,
        url: `https://${base}/${lang}/users/${alias}/`,
        parent_url: postUrl,
        title: alias,
        caption: clean(comment.message).slice(0, 600),
        author: alias,
        datetime: comment.timePublished ?? '',
        media_type: 'user',
        media_url: `https://${base}/${lang}/users/${alias}/`,
        thumbnail_url: comment.author?.avatarUrl ?? '',
        likes: String((comment.score ?? 0) || ''),
        shares: '',
        views: '',
        handle: alias,
        comment_id: String(comment.id ?? key),
        comment_text: clean(comment.message),
        comment_url: `https://${base}/${lang}/articles/${id}/comments/#comment_${comment.id ?? key}`,
        comment_at: comment.timePublished ?? '',
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
