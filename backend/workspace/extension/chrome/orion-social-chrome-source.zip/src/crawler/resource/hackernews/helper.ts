import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { SearchResult } from './model';

export function pageOf(payload: CrawlPayload): number {
  const page = Number(String(payload.cursor ?? '').trim());
  return Number.isFinite(page) && page > 0 ? Math.floor(page) : 0;
}

export async function search(tab: TabController, tags: string, payload: CrawlPayload): Promise<SearchResult> {
  const page = pageOf(payload);
  const none: SearchResult = { hits: [], page, nbPages: 0 };
  try {
    const response = await tab.fetch(`https://hn.algolia.com/api/v1/search_by_date?tags=${encodeURIComponent(tags)}&hitsPerPage=${limitOf(payload, 25, 1000)}&page=${page}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return none;
    }
    const data = JSON.parse(response.body);
    return {
      hits: Array.isArray(data?.hits) ? data.hits : [],
      page: Number.isFinite(Number(data?.page)) ? Number(data.page) : page,
      nbPages: Number.isFinite(Number(data?.nbPages)) ? Number(data.nbPages) : 0,
    };
  }
  catch {
    return none;
  }
}

export function pageFrom(items: social_resource[], result: SearchResult): CrawlPage {
  const hasMore = result.hits.length > 0 && result.page + 1 < result.nbPages;
  return { items, next_cursor: items.length && hasMore ? String(result.page + 1) : undefined };
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#x2F;/g, '/').replace(/\s+/g, ' ').trim();
}
