export interface SearchResult {
  hits: any[];
  page: number;
  nbPages: number;
}
