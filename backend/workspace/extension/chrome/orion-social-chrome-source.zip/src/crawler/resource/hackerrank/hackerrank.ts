import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, RECENT_CHALLENGES_MAX_REQUESTS, RECENT_CHALLENGES_UPSTREAM_MAX } from './constant';
import { answer, api } from './helper';

export async function answers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.hackerrank.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const wanted = limitOf(payload, 25, 100);
    const startCursor = String(payload.cursor ?? '').trim();
    const items: social_resource[] = [];
    let cursor = startCursor;
    let hasMore = false;

    for (let request = 0; request < RECENT_CHALLENGES_MAX_REQUESTS && items.length < wanted; request++) {
      const take = Math.min(RECENT_CHALLENGES_UPSTREAM_MAX, wanted - items.length);
      const data = await api(tab, `/hackers/${encodeURIComponent(username)}/recent_challenges?limit=${take}&response_version=v2${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
      const models = (Array.isArray(data?.models) ? data.models : []) as any[];
      items.push(...models.map((item: any) => answer(username, item)).filter((item) => item.url));

      const nextCursor = String(data?.cursor ?? '').trim();
      hasMore = models.length > 0 && Boolean(nextCursor) && nextCursor !== cursor && data?.last_page !== true;
      if (!hasMore) {
        break;
      }
      cursor = nextCursor;
    }

    return { items, next_cursor: items.length && hasMore && cursor && cursor !== startCursor ? cursor : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.hackerrank.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, `/hackers/${encodeURIComponent(username)}/badges`);
    return {
      items: ((data?.models ?? []) as any[]).map((badge: any): social_resource => ({
        type: 'projects',
        resource_id: badge.badge_type ?? badge.badge_name ?? '',
        url: badge.url ? `https://www.hackerrank.com${badge.url}` : `https://www.hackerrank.com/profile/${username}`,
        parent_url: `https://www.hackerrank.com/profile/${username}`,
        title: badge.badge_name ?? '',
        caption: `${badge.stars ?? 0} stars`,
        author: username,
        datetime: '',
        media_type: 'badge',
        media_url: badge.url ? `https://www.hackerrank.com${badge.url}` : '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        badge_name: badge.badge_name ?? '',
        badge_type: badge.badge_type ?? '',
        badge_category: badge.badge_category ?? '',
        badge_short_name: badge.badge_short_name ?? '',
        category_name: badge.category_name ?? '',
        stars: badge.stars ?? 0,
        total_stars: badge.total_stars ?? 0,
        level: badge.level ?? 0,
        solved: badge.solved ?? 0,
        total_challenges: badge.total_challenges ?? 0,
        solve_rate: badge.total_challenges ? Math.round(((badge.solved ?? 0) / badge.total_challenges) * 10000) / 100 : 0,
        current_points: badge.current_points ?? 0,
        total_points: badge.total_points ?? 0,
        track_total_score: badge.track_total_score ?? 0,
        hacker_rank: badge.hacker_rank ?? 0,
        domain_url: badge.url ? `https://www.hackerrank.com${badge.url}` : '',
      })).filter((item) => item.title),
    };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
