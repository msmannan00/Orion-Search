import { social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.hackerrank.com/rest${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function answer(username: string, item: any): social_resource {
  return {
    type: 'answers',
    resource_id: item.ch_slug ?? '',
    url: item.url ? `https://www.hackerrank.com${item.url}` : '',
    parent_url: `https://www.hackerrank.com/profile/${username}`,
    title: item.name ?? '',
    caption: item.con_slug ?? '',
    author: username,
    datetime: item.created_at ?? '',
    media_type: 'challenge',
    media_url: item.url ? `https://www.hackerrank.com${item.url}` : '',
    thumbnail_url: '',
    likes: '',
    shares: '',
    views: '',
    challenge_slug: item.ch_slug ?? '',
    challenge_name: item.name ?? '',
    contest_slug: item.con_slug ?? '',
    contest_url: item.con_slug ? `https://www.hackerrank.com/contests/${item.con_slug}` : '',
    challenge_url: item.url ? `https://www.hackerrank.com${item.url}` : '',
    is_master_contest: item.con_slug === 'master',
    solved_at: item.created_at ?? '',
    created_at: item.created_at ?? '',
  };
}
