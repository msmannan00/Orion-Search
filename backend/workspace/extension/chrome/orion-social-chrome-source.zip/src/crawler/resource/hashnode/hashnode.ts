import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { limitOf } from '../../helper/helper';
import { EMPTY } from './constant';
import { Cursor, Entry } from './model';
import { blogHost, collectUrls, enrich, isPostUrl, parseCursor, rssPosts, startIndex } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const host = blogHost(payload);
  if (!host) {
    return EMPTY;
  }

  const tab = await openSession(`https://${host}/`);
  if (!tab) {
    return EMPTY;
  }

  try {
    const want = limitOf(payload, 25, 100);
    const cursor = parseCursor(payload);
    const seen = new Set<string>();
    const entries: Entry[] = [];

    const feed = await tab.fetch(`https://${host}/rss.xml`);
    if (feed.ok) {
      for (const item of rssPosts(feed.body, host)) {
        if (!seen.has(item.url)) {
          seen.add(item.url);
          entries.push({ url: item.url, lastmod: '', item });
        }
      }
    }

    for (const entry of await collectUrls(tab, host)) {
      if (isPostUrl(entry.url, host) && !seen.has(entry.url)) {
        seen.add(entry.url);
        entries.push(entry);
      }
    }

    const start = startIndex(entries, cursor);
    const slice = entries.slice(start, start + want);
    const enriched = new Map((await enrich(tab, host, slice.filter((entry) => !entry.item))).map((item) => [item.url, item]));
    const items = slice.map((entry) => entry.item ?? enriched.get(entry.url)).filter((item): item is social_resource => Boolean(item?.url));
    const end = start + slice.length;
    const last = slice[slice.length - 1]?.url ?? '';
    return { items, next_cursor: items.length && end < entries.length ? JSON.stringify({ o: end, last } as Cursor) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
