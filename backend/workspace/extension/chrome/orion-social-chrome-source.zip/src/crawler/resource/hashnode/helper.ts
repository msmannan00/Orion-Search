import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { Cursor, Entry } from './model';

export function blogHost(payload: CrawlPayload): string {
  const url = String(payload.url ?? '');
  const custom = /^https?:\/\/([^/]+)/.exec(url)?.[1] ?? '';
  if (custom && !/hashnode\.com$/i.test(custom)) {
    return custom;
  }
  const username = String(payload.username ?? '').replace(/^@/, '');
  return username ? `${username}.hashnode.dev` : '';
}

export function parseCursor(payload: CrawlPayload): Cursor {
  try {
    const raw = String(payload.cursor ?? '').trim();
    if (!raw) {
      return { o: 0, last: '' };
    }
    const parsed = JSON.parse(raw);
    const offset = Math.floor(Number(parsed?.o));
    return { o: Number.isFinite(offset) && offset > 0 ? offset : 0, last: String(parsed?.last ?? '') };
  }
  catch {
    return { o: 0, last: '' };
  }
}

export function startIndex(entries: Entry[], cursor: Cursor): number {
  if (cursor.last) {
    const anchored = entries.findIndex((entry) => entry.url === cursor.last);
    if (anchored >= 0) {
      return anchored + 1;
    }
  }
  return Math.min(cursor.o, entries.length);
}

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function tag(block: string, name: string): string {
  return decode(new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`, 'i').exec(block)?.[1] ?? '');
}

export function rawTag(block: string, name: string): string {
  return new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`, 'i').exec(block)?.[1] ?? '';
}

export function slugTitle(slug: string): string {
  return slug.replace(/[-_]+/g, ' ').replace(/\b\w/g, (character) => character.toUpperCase()).trim();
}

export function imageUrl(image: any): string {
  if (!image) {
    return '';
  }
  if (typeof image === 'string') {
    return image;
  }
  if (Array.isArray(image)) {
    return imageUrl(image[0]);
  }
  return image.url ?? '';
}

export function rssPosts(xml: string, host: string): social_resource[] {
  const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((match) => match[1]);
  return items.map((block: string): social_resource => {
    const link = tag(block, 'link');
    const content = rawTag(block, 'content:encoded');
    const text = decode(content || rawTag(block, 'description'));
    const images = [...content.matchAll(/<img[^>]+src="([^"]+)"/g)].map((match) => match[1]);
    const categories = [...block.matchAll(/<category>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/category>/g)].map((match) => decode(match[1]));
    return {
      type: 'posts',
      resource_id: tag(block, 'guid') || link,
      url: link,
      parent_url: `https://${host}`,
      title: tag(block, 'title'),
      caption: decode(rawTag(block, 'description')).slice(0, 2000),
      author: tag(block, 'dc:creator'),
      datetime: tag(block, 'pubDate'),
      media_type: 'article',
      media_url: link,
      thumbnail_url: images[0] ?? '',
      likes: '',
      shares: '',
      views: '',
      guid: tag(block, 'guid'),
      title_text: tag(block, 'title'),
      slug: link.split('/').filter(Boolean).pop() ?? '',
      description: decode(rawTag(block, 'description')),
      content_text: text.slice(0, 8000),
      content_length: text.length,
      word_count: text.split(/\s+/).filter(Boolean).length,
      reading_time_minutes: Math.max(1, Math.round(text.split(/\s+/).filter(Boolean).length / 250)),
      categories: categories.join(', '),
      categories_count: categories.length,
      images_count: images.length,
      image_urls: images.slice(0, 30).join(', '),
      cover_image: images[0] ?? '',
      links: [...new Set([...content.matchAll(/<a[^>]+href="([^"]+)"/g)].map((match) => match[1]))].slice(0, 40).join(', '),
      creator: tag(block, 'dc:creator'),
      blog_host: host,
      published_at: tag(block, 'pubDate'),
    };
  }).filter((item) => item.url);
}

export function sitemapUrls(xml: string): { url: string; lastmod: string }[] {
  const blocks = [...xml.matchAll(/<url>([\s\S]*?)<\/url>/g)].map((match) => match[1]);
  if (blocks.length) {
    return blocks.map((block) => ({ url: /<loc>([^<]+)<\/loc>/.exec(block)?.[1] ?? '', lastmod: /<lastmod>([^<]+)<\/lastmod>/.exec(block)?.[1] ?? '' })).filter((entry) => entry.url);
  }
  return [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((match) => ({ url: match[1], lastmod: '' })).filter((entry) => !/sitemap/i.test(entry.url));
}

export async function collectUrls(tab: TabController, host: string): Promise<{ url: string; lastmod: string }[]> {
  const index = await tab.fetch(`https://${host}/sitemap.xml`);
  if (!index.ok) {
    return [];
  }
  const pages = [...index.body.matchAll(/<loc>([^<]*sitemap[^<]*)<\/loc>/g)].map((match) => match[1]);
  if (!pages.length) {
    return sitemapUrls(index.body);
  }
  const collected: { url: string; lastmod: string }[] = [];
  for (const page of pages) {
    const sub = await tab.fetch(page);
    if (sub.ok) {
      collected.push(...sitemapUrls(sub.body));
    }
  }
  return collected;
}

export function isPostUrl(url: string, host: string): boolean {
  try {
    const parsed = new URL(url);
    if (parsed.hostname !== host) {
      return false;
    }
    const segment = parsed.pathname.replace(/^\/|\/$/g, '');
    return Boolean(segment) && !segment.includes('/') && !/^(tag|tags|series|about|newsletter|sponsor|sponsors|search|badges|members|rss|sitemap|feed)$/i.test(segment);
  }
  catch {
    return false;
  }
}

export function ldPost(host: string, url: string, ld: any, lastmod: string): social_resource {
  const slug = url.split('/').filter(Boolean).pop() ?? '';
  const description = String(ld?.description ?? '');
  const author = ld?.author?.name ?? ld?.author ?? '';
  const image = imageUrl(ld?.image);
  const published = ld?.datePublished ?? lastmod;
  return {
    type: 'posts',
    resource_id: url,
    url,
    parent_url: `https://${host}`,
    title: ld?.headline ?? slugTitle(slug),
    caption: description.slice(0, 2000),
    author: String(author),
    datetime: published,
    media_type: 'article',
    media_url: url,
    thumbnail_url: image,
    likes: '',
    shares: '',
    views: '',
    guid: url,
    title_text: ld?.headline ?? slugTitle(slug),
    slug,
    description,
    content_text: description.slice(0, 8000),
    content_length: description.length,
    word_count: description.split(/\s+/).filter(Boolean).length,
    reading_time_minutes: Math.max(1, Math.round(description.split(/\s+/).filter(Boolean).length / 250)),
    categories: '',
    categories_count: 0,
    images_count: image ? 1 : 0,
    image_urls: image,
    cover_image: image,
    links: '',
    creator: String(author),
    blog_host: host,
    published_at: published,
    modified_at: ld?.dateModified ?? '',
  };
}

export async function enrich(tab: TabController, host: string, targets: { url: string; lastmod: string }[]): Promise<social_resource[]> {
  const output: social_resource[] = [];
  const size = 6;
  for (let start = 0; start < targets.length; start += size) {
    const batch = targets.slice(start, start + size);
    const results = await Promise.all(batch.map(async (target) => {
      const response = await tab.fetch(target.url);
      if (!response.ok) {
        return ldPost(host, target.url, null, target.lastmod);
      }
      const blocks = [...response.body.matchAll(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)].map((match) => match[1]);
      let post: any = null;
      for (const block of blocks) {
        try {
          const parsed = JSON.parse(block);
          const entries = Array.isArray(parsed) ? parsed : (parsed['@graph'] ?? [parsed]);
          for (const entry of entries) {
            if (entry && (entry['@type'] === 'BlogPosting' || entry['@type'] === 'Article' || entry['@type'] === 'NewsArticle')) {
              post = entry;
            }
          }
        }
        catch {
        }
      }
      return ldPost(host, target.url, post, target.lastmod);
    }));
    output.push(...results);
  }
  return output;
}
