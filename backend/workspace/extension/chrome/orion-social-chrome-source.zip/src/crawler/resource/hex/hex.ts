import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function ownedPackages(username: string): Promise<string[]> {
  const response = await fetch(`https://hex.pm/api/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  const owned = data?.owned_packages ?? {};
  return owned && typeof owned === 'object' ? Object.keys(owned) : [];
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const names = await ownedPackages(username);
    if (!names.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 40);
    const slice = names.slice(offset, offset + limit);
    const docs = await Promise.all(slice.map((name) => fetch(`https://hex.pm/api/packages/${encodeURIComponent(name)}`, { headers: { Accept: 'application/json' } })
      .then((response) => response.ok ? response.json() : null)
      .catch(() => null)));

    const items = slice.map((name: string, index: number): social_resource => {
      const pkg: any = docs[index] ?? {};
      const meta = pkg.meta ?? {};
      const downloads = pkg.downloads ?? {};
      const links = meta.links ?? {};
      return {
        type: 'repositories',
        resource_id: name,
        url: pkg.html_url ?? `https://hex.pm/packages/${name}`,
        parent_url: `https://hex.pm/users/${username}`,
        title: name,
        caption: clean(meta.description),
        author: username,
        datetime: pkg.updated_at ?? pkg.inserted_at ?? '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: String((downloads.all ?? 0) || ''),
        name,
        description: clean(meta.description),
        latest_version: pkg.latest_stable_version ?? pkg.latest_version ?? '',
        licenses: Array.isArray(meta.licenses) ? meta.licenses.join(', ') : '',
        links: Object.entries(links).map(([label, href]) => `${label}: ${href}`).join(' | '),
        downloads_all: downloads.all ?? 0,
        downloads_recent: downloads.recent ?? 0,
        downloads_day: downloads.day ?? 0,
        releases_count: Array.isArray(pkg.releases) ? pkg.releases.length : 0,
        inserted_at: pkg.inserted_at ?? '',
        updated_at: pkg.updated_at ?? '',
      };
    }).filter((item) => item.url);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < names.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
