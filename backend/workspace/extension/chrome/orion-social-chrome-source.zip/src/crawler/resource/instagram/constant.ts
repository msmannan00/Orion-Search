import { CrawlPage } from '../../../app/extension/model/extension.model';

export const HEADERS = { Accept: 'application/json', 'x-ig-app-id': '936619743392459' };
export const EMPTY: CrawlPage = { items: [] };
export const MAX_FIRST = 50;
export const FILL_PAGES = 3;
