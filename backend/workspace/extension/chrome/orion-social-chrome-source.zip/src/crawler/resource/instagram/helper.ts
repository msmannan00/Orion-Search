import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { FILL_PAGES, HEADERS, MAX_FIRST } from './constant';
import { Cursor, Owner, Timeline } from './model';

export async function profile(tab: TabController, username: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`, {
      headers: HEADERS,
    });
    return response.ok ? (JSON.parse(response.body))?.data?.user ?? null : null;
  }
  catch {
    return null;
  }
}

export async function graphql(tab: TabController, id: string, after: string, first: number): Promise<any> {
  try {
    const variables = encodeURIComponent(JSON.stringify({ id, first, after }));
    const response = await tab.fetch(`https://www.instagram.com/graphql/query/?query_hash=69cba40317214236af40e7efa697781d&variables=${variables}`, {
      headers: HEADERS,
    });
    if (!response.ok) {
      return null;
    }
    const connection = (JSON.parse(response.body))?.data?.user?.edge_owner_to_timeline_media;
    return Array.isArray(connection?.edges) ? connection : null;
  }
  catch {
    return null;
  }
}

export async function feed(tab: TabController, id: string, maxId: string, count: number): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.instagram.com/api/v1/feed/user/${encodeURIComponent(id)}/?count=${count}${maxId ? `&max_id=${encodeURIComponent(maxId)}` : ''}`, {
      headers: HEADERS,
    });
    if (!response.ok) {
      return null;
    }
    const data = JSON.parse(response.body);
    return Array.isArray(data?.items) ? data : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function fromFeedItem(item: any): any {
  if (!item || typeof item !== 'object') {
    return null;
  }
  const image = (Array.isArray(item.image_versions2?.candidates) ? item.image_versions2.candidates : [])[0] ?? {};
  const video = (Array.isArray(item.video_versions) ? item.video_versions : [])[0] ?? {};
  const carousel: any[] = Array.isArray(item.carousel_media) ? item.carousel_media : [];
  const usertags: any[] = Array.isArray(item.usertags?.in) ? item.usertags.in : [];
  const isVideo = Number(item.media_type) === 2 || Boolean(video.url);
  const captionText = item.caption?.text ?? '';
  return {
    id: String(item.pk ?? item.id ?? ''),
    shortcode: item.code ?? '',
    __typename: Number(item.media_type) === 8 || carousel.length ? 'GraphSidecar' : isVideo ? 'GraphVideo' : 'GraphImage',
    product_type: item.product_type ?? '',
    taken_at_timestamp: item.taken_at,
    is_video: isVideo,
    has_audio: item.has_audio ?? false,
    video_url: video.url || undefined,
    display_url: image.url ?? '',
    thumbnail_src: image.url ?? '',
    video_view_count: item.view_count ?? 0,
    video_play_count: item.play_count ?? 0,
    video_duration: item.video_duration ?? 0,
    dimensions: { width: item.original_width ?? image.width ?? 0, height: item.original_height ?? image.height ?? 0 },
    edge_media_to_caption: { edges: captionText ? [{ node: { text: captionText } }] : [] },
    edge_liked_by: { count: item.like_count ?? 0 },
    edge_media_to_comment: { count: item.comment_count ?? 0 },
    comments_disabled: item.comments_disabled ?? item.commenting_disabled_for_viewer ?? false,
    location: item.location ? { id: String(item.location.pk ?? item.location.id ?? ''), name: item.location.name ?? '', slug: item.location.slug ?? '' } : undefined,
    accessibility_caption: item.accessibility_caption ?? '',
    edge_sidecar_to_children: { edges: carousel.map((child: any) => ({ node: fromFeedItem(child) })).filter((edge) => edge.node) },
    edge_media_to_tagged_user: { edges: usertags.map((tag: any) => ({ node: { user: { username: tag?.user?.username ?? '' } } })) },
    coauthor_producers: Array.isArray(item.coauthor_producers) ? item.coauthor_producers : [],
    is_paid_partnership: item.is_paid_partnership ?? false,
    is_affiliate: item.is_affiliate ?? false,
    fact_check_overall_rating: item.fact_check_overall_rating ?? '',
    owner: { id: String(item.user?.pk ?? item.owner?.pk ?? item.user?.id ?? ''), username: item.user?.username ?? item.owner?.username ?? '' },
  };
}

export function media(username: string, type: 'posts' | 'images' | 'videos', node: any, user: any): social_resource {
  const caption = node.edge_media_to_caption?.edges?.[0]?.node?.text ?? '';
  const children: any[] = Array.isArray(node.edge_sidecar_to_children?.edges) ? node.edge_sidecar_to_children.edges.map((edge: any) => edge?.node).filter(Boolean) : [];
  const tagged: any[] = Array.isArray(node.edge_media_to_tagged_user?.edges) ? node.edge_media_to_tagged_user.edges.map((edge: any) => edge?.node).filter(Boolean) : [];
  const hashtags = [...String(caption).matchAll(/#([\p{L}\p{N}_]+)/gu)].map((match) => match[1]);
  const mentions = [...String(caption).matchAll(/@([\w.]+)/g)].map((match) => match[1]);
  return {
    type,
    resource_id: String(node.id ?? ''),
    url: node.shortcode ? `https://www.instagram.com/p/${node.shortcode}/` : '',
    parent_url: `https://www.instagram.com/${username}/`,
    title: clean(caption).slice(0, 120),
    caption: clean(caption),
    author: node.owner?.username ?? username,
    datetime: stamp(node.taken_at_timestamp),
    media_type: node.__typename === 'GraphVideo' ? 'video' : node.__typename === 'GraphSidecar' ? 'carousel' : 'image',
    media_url: node.video_url ?? node.display_url ?? '',
    thumbnail_url: node.thumbnail_src ?? node.display_url ?? '',
    likes: String((node.edge_liked_by?.count ?? node.edge_media_preview_like?.count ?? 0) || ''),
    shares: '',
    views: String((node.video_view_count ?? node.video_play_count ?? 0) || ''),
    media_id: node.id ?? '',
    shortcode: node.shortcode ?? '',
    typename: node.__typename ?? '',
    product_type: node.product_type ?? '',
    caption_text: clean(caption),
    caption_length: String(caption ?? '').length,
    hashtags: hashtags.join(', '),
    hashtags_count: hashtags.length,
    mentions: mentions.join(', '),
    mentions_count: mentions.length,
    is_video: node.is_video ?? false,
    has_audio: node.has_audio ?? false,
    video_url: node.video_url ?? '',
    video_view_count: node.video_view_count ?? 0,
    video_play_count: node.video_play_count ?? 0,
    video_duration: node.video_duration ?? 0,
    display_url: node.display_url ?? '',
    thumbnail_src: node.thumbnail_src ?? '',
    width: node.dimensions?.width ?? 0,
    height: node.dimensions?.height ?? 0,
    like_count: node.edge_liked_by?.count ?? node.edge_media_preview_like?.count ?? 0,
    comment_count: node.edge_media_to_comment?.count ?? node.edge_media_preview_comment?.count ?? 0,
    comments_disabled: node.comments_disabled ?? false,
    location_id: node.location?.id ?? '',
    location_name: node.location?.name ?? '',
    location_slug: node.location?.slug ?? '',
    accessibility_caption: clean(node.accessibility_caption),
    children_count: children.length,
    children_urls: children.map((child: any) => child?.display_url ?? '').filter(Boolean).join(', '),
    children_video_urls: children.map((child: any) => child?.video_url ?? '').filter(Boolean).join(', '),
    children_types: [...new Set(children.map((child: any) => child?.__typename ?? '').filter(Boolean))].join(', '),
    tagged_users: tagged.map((entry: any) => entry?.user?.username ?? '').filter(Boolean).join(', '),
    tagged_count: tagged.length,
    coauthors: Array.isArray(node.coauthor_producers) ? node.coauthor_producers.map((entry: any) => entry?.username ?? '').filter(Boolean).join(', ') : '',
    is_paid_partnership: node.is_paid_partnership ?? false,
    is_affiliate: node.is_affiliate ?? false,
    fact_check_rating: node.fact_check_overall_rating ?? '',
    owner_id: node.owner?.id ?? user?.id ?? '',
    owner_username: node.owner?.username ?? username,
    owner_full_name: user?.full_name ?? '',
    owner_is_verified: user?.is_verified ?? false,
    owner_followers: user?.edge_followed_by?.count ?? 0,
    taken_at: stamp(node.taken_at_timestamp),
  };
}

export function parseCursor(payload: CrawlPayload): Cursor | null {
  try {
    const raw = String(payload.cursor ?? '').trim();
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw);
    const id = String(parsed?.id ?? '').trim();
    const after = String(parsed?.after ?? '').trim();
    if (!id || !after) {
      return null;
    }
    const owner = parsed?.owner ?? {};
    return {
      id,
      after,
      last: String(parsed?.last ?? '').trim(),
      src: parsed?.src === 'v1' ? 'v1' : 'graphql',
      owner: { id: String(owner.id ?? id), name: String(owner.name ?? ''), verified: Boolean(owner.verified), followers: Number(owner.followers) || 0 },
    };
  }
  catch {
    return null;
  }
}

export function ownerOf(user: any): Owner {
  return { id: String(user?.id ?? ''), name: String(user?.full_name ?? ''), verified: Boolean(user?.is_verified), followers: Number(user?.edge_followed_by?.count) || 0 };
}

export function userOf(owner: Owner): any {
  return { id: owner.id, full_name: owner.name, is_verified: owner.verified, edge_followed_by: { count: owner.followers } };
}

export function nodesOf(connection: any): any[] {
  return ((Array.isArray(connection?.edges) ? connection.edges : []) as any[]).map((edge: any) => edge?.node).filter((node: any) => node?.id);
}

export function continuation(previous: Cursor | null, user: any, nodes: any[], after: unknown, more: boolean, src: Cursor['src']): Cursor | undefined {
  const token = String(after ?? '').trim();
  if (!more || !token || !nodes.length || token === previous?.after) {
    return undefined;
  }
  const owner = previous?.owner ?? ownerOf(user);
  return { id: owner.id || String(user?.id ?? ''), after: token, last: String(nodes[nodes.length - 1]?.id ?? ''), src, owner };
}

export async function firstPage(tab: TabController, username: string): Promise<Timeline> {
  const user = await profile(tab, username);
  if (!user?.id) {
    return { user: null, nodes: [] };
  }
  const connection = user.edge_owner_to_timeline_media;
  const nodes = nodesOf(connection);
  return { user, nodes, next: continuation(null, user, nodes, connection?.page_info?.end_cursor, Boolean(connection?.page_info?.has_next_page), 'graphql') };
}

export async function nextPage(tab: TabController, cursor: Cursor, count: number): Promise<Timeline> {
  const user = userOf(cursor.owner);
  if (cursor.src === 'graphql') {
    const connection = await graphql(tab, cursor.id, cursor.after, count);
    if (connection) {
      const nodes = nodesOf(connection);
      return { user, nodes, next: continuation(cursor, user, nodes, connection.page_info?.end_cursor, Boolean(connection.page_info?.has_next_page), 'graphql') };
    }
  }

  const data = await feed(tab, cursor.id, cursor.src === 'v1' ? cursor.after : cursor.last, count);
  if (!data) {
    return { user, nodes: [] };
  }
  const nodes = (data.items as any[]).map(fromFeedItem).filter((node: any) => node?.id);
  return { user, nodes, next: continuation(cursor, user, nodes, data.next_max_id, Boolean(data.more_available), 'v1') };
}

export async function timeline(tab: TabController, payload: CrawlPayload, username: string, keep: (node: any) => boolean): Promise<Timeline> {
  const limit = limitOf(payload, 25, MAX_FIRST);
  const cursor = parseCursor(payload);
  const first = cursor ? await nextPage(tab, cursor, limit) : await firstPage(tab, username);
  const user = first.user;
  const nodes = first.nodes.filter(keep);
  let next = first.next;
  for (let fill = 0; fill < FILL_PAGES && next && nodes.length < limit; fill++) {
    const page = await nextPage(tab, next, Math.min(MAX_FIRST, Math.max(12, limit - nodes.length)));
    nodes.push(...page.nodes.filter(keep));
    next = page.next;
  }
  return { user, nodes, next };
}

export function page(username: string, type: 'posts' | 'images' | 'videos', result: Timeline): CrawlPage {
  const items = result.nodes.map((node: any) => media(username, type, node, result.user)).filter((item) => item.url);
  return { items, next_cursor: items.length && result.next ? JSON.stringify(result.next) : undefined };
}
