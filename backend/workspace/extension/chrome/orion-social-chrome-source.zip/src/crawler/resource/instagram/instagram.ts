import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { nodesOf, page, timeline } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.instagram.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return page(username, 'posts', await timeline(tab, payload, username, () => true));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.instagram.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return page(username, 'images', await timeline(tab, payload, username, (node: any) => !node.is_video));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.instagram.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const result = await timeline(tab, payload, username, (node: any) => Boolean(node?.is_video));
    const seen = new Set(result.nodes.map((node: any) => String(node.id)));
    result.nodes.push(...nodesOf(result.user?.edge_felix_video_timeline).filter((node: any) => node?.is_video && !seen.has(String(node.id))));
    return page(username, 'videos', result);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
