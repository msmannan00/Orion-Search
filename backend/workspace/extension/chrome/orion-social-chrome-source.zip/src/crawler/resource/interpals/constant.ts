import { CrawlPage } from '../../../app/extension/model/extension.model';

export const ORIGIN = 'https://www.interpals.net';
export const EMPTY: CrawlPage = { items: [] };

export const CARD_WRAPPER = /<(?:article|li|div)\b[^>]*(?:\bclass=["'][^"']*\bpost(?:-card|-item|-container|-entry|_post|\b)|\bdata-post-id=|\bid=["']post[-_]?\d+["'])/gi;
