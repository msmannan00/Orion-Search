import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, ORIGIN } from './constant';
import { cursorNext, fetchHtml, nextPageUrl, parseCursor, parsePosts, resolveUid } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').replace(/^@/, '');
  if (!username) {
    return EMPTY;
  }

  const tab = await openSession(`${ORIGIN}/`);
  if (!tab) {
    return EMPTY;
  }

  const limit = limitOf(payload, 25, 50);
  try {
    const cursor = parseCursor(payload.cursor);
    if (cursor) {
      const html = await fetchHtml(tab, cursor.next);
      if (!html) {
        return EMPTY;
      }
      const items = parsePosts(html, username);
      const next = nextPageUrl(html, cursor.next);
      return { items, next_cursor: items.length && next ? JSON.stringify({ uid: cursor.uid, next }) : undefined };
    }

    const profileUrl = `${ORIGIN}/${encodeURIComponent(username)}`;
    const profileHtml = await fetchHtml(tab, profileUrl);
    if (!profileHtml) {
      return EMPTY;
    }

    const uid = resolveUid(profileHtml, username);
    if (uid) {
      const listUrl = `${ORIGIN}/app/${uid}/posts?limit=${limit}`;
      const listHtml = await fetchHtml(tab, listUrl);
      if (listHtml) {
        const items = parsePosts(listHtml, username);
        if (items.length) {
          const next = nextPageUrl(listHtml, listUrl);
          return { items, next_cursor: next ? JSON.stringify({ uid, next }) : undefined };
        }
      }
    }

    const items = parsePosts(profileHtml, username);
    const next = cursorNext(profileHtml, profileUrl);
    return { items, next_cursor: items.length && next ? JSON.stringify({ uid, next }) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
