export interface Cursor {
  uid: string;
  next: string;
}
