import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function scopeOf(payload: CrawlPayload): string {
  return String(payload.username ?? '').replace(/^@/, '').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

async function fetchPackages(scope: string, page: number, limit: number): Promise<{ items: any[]; total: number }> {
  const response = await fetch(`https://jsr.io/api/scopes/${encodeURIComponent(scope)}/packages?limit=${limit}&page=${page}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return { items: [], total: 0 };
  }
  const data = await response.json();
  return { items: Array.isArray(data?.items) ? data.items : [], total: Number(data?.total ?? 0) };
}

export async function scopeTotal(scope: string): Promise<number> {
  return (await fetchPackages(scope, 1, 1)).total;
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const scope = scopeOf(payload);
  if (!scope) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const limit = limitOf(payload, 25, 50);
    const { items: rows, total } = await fetchPackages(scope, page, limit);
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((pkg: any): social_resource => {
      const name = String(pkg.name ?? '');
      const runtime = pkg.runtimeCompat ?? {};
      const runtimes = Object.keys(runtime).filter((key) => runtime[key]);
      return {
        type: 'repositories',
        resource_id: `@${scope}/${name}`,
        url: `https://jsr.io/@${scope}/${name}`,
        parent_url: `https://jsr.io/@${scope}`,
        title: `@${scope}/${name}`,
        caption: clean(pkg.description),
        author: `@${scope}`,
        datetime: pkg.updatedAt ?? pkg.createdAt ?? '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: String((pkg.score ?? '') !== '' ? pkg.score : ''),
        shares: String((pkg.dependentCount ?? 0) || ''),
        views: '',
        name,
        description: clean(pkg.description),
        latest_version: pkg.latestVersion ?? '',
        score: pkg.score ?? '',
        github_repository: pkg.githubRepository ? `https://github.com/${pkg.githubRepository.owner}/${pkg.githubRepository.name}` : '',
        runtimes: runtimes.join(', '),
        version_count: pkg.versionCount ?? 0,
        dependency_count: pkg.dependencyCount ?? 0,
        dependent_count: pkg.dependentCount ?? 0,
        is_archived: Boolean(pkg.isArchived),
        created_at: pkg.createdAt ?? '',
        updated_at: pkg.updatedAt ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const hasMore = total ? page * limit < total : rows.length >= limit;
    return { items, next_cursor: items.length && hasMore ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
