import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { ListCursor } from './model';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://keybase.io/_/api/1.0/${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function parseCursor(payload: CrawlPayload): ListCursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { offset: 0, uid: '' };
  }

  try {
    const parsed: any = JSON.parse(raw);
    const offset = Number(parsed?.offset);
    return { offset: Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0, uid: String(parsed?.uid ?? '') };
  }
  catch {
    return { offset: 0, uid: '' };
  }
}

export function people(users: any[], username: string, type: 'followers', payload: CrawlPayload): CrawlPage {
  const size = limitOf(payload, 25, 200);
  const cursor = parseCursor(payload);
  const anchor = cursor.uid ? users.findIndex((entry: any) => entry?.uid === cursor.uid) : -1;
  const start = anchor >= 0 ? anchor + 1 : cursor.offset;
  const entries = users.slice(start, start + size);
  const end = start + entries.length;
  const items = entries.map((entry: any) => person(username, type, entry)).filter((item) => item.url);
  const last: any = entries[entries.length - 1];
  return { items, next_cursor: items.length && end < users.length ? JSON.stringify({ offset: end, uid: last?.uid ?? '' }) : undefined };
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function person(username: string, type: 'followers', entry: any): social_resource {
  return {
    type,
    resource_id: entry.uid ?? '',
    url: entry.username ? `https://keybase.io/${entry.username}` : '',
    parent_url: `https://keybase.io/${username}`,
    title: entry.full_name ?? entry.username ?? '',
    caption: clean(entry.bio).slice(0, 600),
    author: entry.username ?? '',
    datetime: '',
    media_type: 'user',
    media_url: entry.username ? `https://keybase.io/${entry.username}` : '',
    thumbnail_url: entry.thumbnail ?? '',
    likes: '',
    shares: '',
    views: '',
    uid: entry.uid ?? '',
    username: entry.username ?? '',
    full_name: entry.full_name ?? '',
    bio: clean(entry.bio),
    location: entry.location ?? '',
    thumbnail: entry.thumbnail ?? '',
    is_followee: entry.is_followee ?? false,
    follow_time: entry.follow_time ?? 0,
    proofs_url: entry.username ? `https://keybase.io/${entry.username}` : '',
    sigchain_url: entry.username ? `https://keybase.io/${entry.username}/sigchain` : '',
  };
}
