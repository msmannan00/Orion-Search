import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, people } from './helper';

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://keybase.io/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, `user/list_followers_for_display.json?username=${encodeURIComponent(username)}&reverse=0`);
    return people((Array.isArray(data?.users) ? data.users : []) as any[], username, 'followers', payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}


export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://keybase.io/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, `user/lookup.json?usernames=${encodeURIComponent(username)}&fields=proofs_summary,cryptocurrency_addresses,basics`);
    const user = data?.them?.[0] ?? {};
    const proofs: any[] = Array.isArray(user.proofs_summary?.all) ? user.proofs_summary.all : [];
    const crypto = user.cryptocurrency_addresses ?? {};
    const wallets: any[] = Object.entries(crypto).flatMap(([family, list]: [string, any]) => (Array.isArray(list) ? list.map((entry: any) => ({ family, ...entry })) : []));

    const items = [
      ...proofs.map((proof: any): social_resource => ({
        type: 'organizations',
        resource_id: proof.sig_id ?? `${proof.proof_type ?? ''}-${proof.nametag ?? ''}`,
        url: proof.service_url ?? proof.human_url ?? '',
        parent_url: `https://keybase.io/${username}`,
        title: proof.nametag ?? '',
        caption: proof.proof_type ?? '',
        author: username,
        datetime: '',
        media_type: proof.proof_type ?? 'proof',
        media_url: proof.proof_url ?? '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        kind: 'proof',
        service: proof.proof_type ?? '',
        nametag: proof.nametag ?? '',
        service_url: proof.service_url ?? '',
        human_url: proof.human_url ?? '',
        proof_url: proof.proof_url ?? '',
        presentation_group: proof.presentation_group ?? '',
        presentation_tag: proof.presentation_tag ?? '',
        state: proof.state ?? 0,
        sig_id: proof.sig_id ?? '',
        proof_id: proof.proof_id ?? '',
        wallet_family: '',
        wallet_address: '',
      })),
      ...wallets.map((wallet: any): social_resource => ({
        type: 'organizations',
        resource_id: wallet.address ?? '',
        url: `https://keybase.io/${username}`,
        parent_url: `https://keybase.io/${username}`,
        title: wallet.family ?? '',
        caption: wallet.address ?? '',
        author: username,
        datetime: '',
        media_type: 'wallet',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        kind: 'wallet',
        service: wallet.family ?? '',
        nametag: wallet.address ?? '',
        service_url: '',
        human_url: '',
        proof_url: '',
        presentation_group: '',
        presentation_tag: '',
        state: 0,
        sig_id: wallet.sig_id ?? '',
        proof_id: '',
        wallet_family: wallet.family ?? '',
        wallet_address: wallet.address ?? '',
      })),
    ].filter((item) => item.resource_id);

    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
