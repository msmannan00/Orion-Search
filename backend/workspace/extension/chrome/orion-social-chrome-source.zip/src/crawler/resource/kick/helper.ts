import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://kick.com/api/v2${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function upstreamCursor(value: unknown): string {
  if (typeof value === 'string') {
    return value.trim();
  }
  return value && typeof value === 'object' ? JSON.stringify(value) : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function iso(value: unknown): string {
  const text = String(value ?? '').trim();
  if (!text) {
    return '';
  }
  const parsed = new Date(text.includes('T') ? text : text.replace(' ', 'T') + 'Z');
  return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString();
}
