import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, iso, upstreamCursor } from './helper';

export async function streams(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://kick.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const list = await api(tab, `/channels/${encodeURIComponent(username)}/videos`);
    const items = ((Array.isArray(list) ? list : []) as any[]).map((entry: any): social_resource => {
      const video = entry.video ?? {};
      const categories: any[] = Array.isArray(entry.categories) ? entry.categories : [];
      const category = categories[0] ?? {};
      return {
        type: 'streams',
        resource_id: String(entry.id ?? ''),
        url: video.uuid ? `https://kick.com/${username}/videos/${video.uuid}` : `https://kick.com/${username}`,
        parent_url: `https://kick.com/${username}`,
        title: clean(entry.session_title),
        caption: category.name ?? '',
        author: username,
        datetime: iso(entry.start_time ?? entry.created_at),
        media_type: 'stream',
        media_url: entry.source ?? '',
        thumbnail_url: entry.thumbnail?.src ?? '',
        likes: '',
        shares: '',
        views: String((entry.views ?? entry.viewer_count ?? 0) || ''),
        livestream_id: entry.id ?? 0,
        video_id: video.id ?? 0,
        video_uuid: video.uuid ?? '',
        slug: entry.slug ?? '',
        channel_id: entry.channel_id ?? 0,
        session_title: clean(entry.session_title),
        is_live: entry.is_live ?? false,
        duration: entry.duration ?? 0,
        language: entry.language ?? '',
        is_mature: entry.is_mature ?? false,
        viewer_count: entry.viewer_count ?? 0,
        views_count: entry.views ?? 0,
        risk_level_id: entry.risk_level_id ?? 0,
        source_url: entry.source ?? '',
        twitch_channel: entry.twitch_channel ?? '',
        thumbnail: entry.thumbnail?.src ?? '',
        thumbnail_srcset: entry.thumbnail?.srcset ?? '',
        tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
        categories: categories.map((item: any) => item?.name ?? '').filter(Boolean).join(', '),
        category_id: category.id ?? 0,
        category_name: category.name ?? '',
        category_slug: category.slug ?? '',
        category_banner: category.banner?.src ?? '',
        category_viewers: category.viewers ?? 0,
        category_description: clean(category.description).slice(0, 500),
        video_live_stream_id: video.live_stream_id ?? 0,
        video_created_at: iso(video.created_at),
        video_updated_at: iso(video.updated_at),
        video_uuid_url: video.uuid ? `https://kick.com/video/${video.uuid}` : '',
        start_time: iso(entry.start_time),
        created_at: iso(entry.created_at),
      };
    }).filter((item) => item.url);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://kick.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = String(payload.cursor ?? '').trim();
    const data = await api(tab, `/channels/${encodeURIComponent(username)}/clips?limit=${limitOf(payload, 25, 100)}&sort=date${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
    const clips = (Array.isArray(data?.clips) ? data.clips : Array.isArray(data) ? data : []) as any[];
    const items = clips.map((clip: any): social_resource => {
      const creator = clip.creator ?? {};
      const channel = clip.channel ?? {};
      const category = clip.category ?? {};
      return {
        type: 'videos',
        resource_id: clip.id ?? '',
        url: clip.id ? `https://kick.com/${channel.slug ?? username}/clips/${clip.id}` : '',
        parent_url: `https://kick.com/${username}`,
        title: clean(clip.title),
        caption: category.name ?? '',
        author: creator.username ?? username,
        datetime: clip.created_at ?? '',
        media_type: 'clip',
        media_url: clip.video_url ?? clip.clip_url ?? '',
        thumbnail_url: clip.thumbnail_url ?? '',
        likes: String((clip.likes ?? 0) || ''),
        shares: '',
        views: String((clip.view_count ?? clip.views ?? 0) || ''),
        clip_id: clip.id ?? '',
        livestream_id: clip.livestream_id ?? '',
        channel_id: clip.channel_id ?? 0,
        user_id: clip.user_id ?? 0,
        title_text: clean(clip.title),
        clip_url: clip.clip_url ?? '',
        video_url: clip.video_url ?? '',
        thumbnail: clip.thumbnail_url ?? '',
        privacy: clip.privacy ?? '',
        likes_count: clip.likes ?? 0,
        view_count: clip.view_count ?? clip.views ?? 0,
        duration: clip.duration ?? 0,
        is_mature: clip.is_mature ?? false,
        vod_starts_at: clip.vod_starts_at ?? 0,
        started_at: clip.started_at ?? '',
        created_at: clip.created_at ?? '',
        category_id: clip.category_id ?? category.id ?? '',
        category_name: category.name ?? '',
        category_slug: category.slug ?? '',
        category_thumbnail: category.thumbnail ?? '',
        creator_id: creator.id ?? 0,
        creator_username: creator.username ?? '',
        creator_slug: creator.slug ?? '',
        creator_avatar: creator.profile_picture ?? '',
        channel_slug: channel.slug ?? '',
        channel_username: channel.username ?? '',
        channel_avatar: channel.profile_picture ?? '',
      };
    }).filter((item) => item.url);
    const nextCursor = upstreamCursor(data?.nextCursor ?? data?.next_cursor);
    return { items, next_cursor: items.length && nextCursor && nextCursor !== cursor ? nextCursor : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
