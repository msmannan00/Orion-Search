import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };
const HEADERS = { Accept: 'application/vnd.api+json' };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function userBySlug(slug: string): Promise<any> {
  const response = await fetch(`https://kitsu.io/api/edge/users?filter[slug]=${encodeURIComponent(slug.trim())}`, { headers: HEADERS });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  return Array.isArray(data?.data) && data.data.length ? data.data[0] : null;
}

export async function details(slug: string): Promise<social_profile_details[]> {
  const user = await userBySlug(slug);
  if (!user) {
    return [];
  }

  const attrs = user.attributes ?? {};
  return [{
    real_name: clean(attrs.name) || slug,
    bio: clean(attrs.about),
    description: clean(attrs.about),
    location: clean(attrs.location),
    profile_url: `https://kitsu.io/users/${attrs.slug ?? slug}`,
    total_posts: String((attrs.ratingsCount ?? 0) || ''),
    total_followers: String((attrs.followersCount ?? 0) || ''),
    total_likes: '',
    avatar: attrs.avatar?.original ?? '',
    banner: attrs.coverImage?.original ?? '',
    crawl_type: ['details', 'reviews'],
    platform: 'kitsu',
    username: attrs.slug ?? slug,
    ratings_count: attrs.ratingsCount ?? 0,
    posts_count: attrs.postsCount ?? 0,
    followers_count: attrs.followersCount ?? 0,
    following_count: attrs.followingCount ?? 0,
    kitsu_id: user.id ?? '',
  }];
}

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const slug = String(payload.username ?? '');
  if (!slug) {
    return EMPTY;
  }

  try {
    const user = await userBySlug(slug);
    const id = user?.id;
    if (!id) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 40);
    const response = await fetch(`https://kitsu.io/api/edge/library-entries?filter[userId]=${encodeURIComponent(id)}&include=media&page[limit]=${limit}&page[offset]=${offset}&sort=-updatedAt`, { headers: HEADERS });
    if (!response.ok) {
      return EMPTY;
    }
    const data = await response.json();
    const rows: any[] = Array.isArray(data?.data) ? data.data : [];
    if (!rows.length) {
      return EMPTY;
    }
    const total = Number(data?.meta?.count ?? 0);

    const media = new Map<string, any>();
    (Array.isArray(data?.included) ? data.included : []).forEach((entry: any) => media.set(`${entry.type}:${entry.id}`, entry));

    const items = rows.map((entry: any): social_resource => {
      const attrs = entry.attributes ?? {};
      const rel = entry.relationships?.media?.data ?? {};
      const item = media.get(`${rel.type}:${rel.id}`) ?? {};
      const mediaAttrs = item.attributes ?? {};
      const mediaType = String(rel.type ?? 'anime');
      const mediaSlug = mediaAttrs.slug ?? rel.id ?? '';
      const title = clean(mediaAttrs.canonicalTitle) || clean(mediaAttrs.slug);
      return {
        type: 'reviews',
        resource_id: String(entry.id ?? ''),
        url: mediaSlug ? `https://kitsu.io/${mediaType}/${mediaSlug}` : `https://kitsu.io/users/${slug}`,
        parent_url: `https://kitsu.io/users/${slug}/library`,
        title,
        caption: clean(attrs.notes),
        author: slug,
        datetime: attrs.progressedAt ?? attrs.updatedAt ?? '',
        media_type: mediaType,
        media_url: '',
        thumbnail_url: mediaAttrs.posterImage?.small ?? mediaAttrs.posterImage?.tiny ?? '',
        likes: '',
        shares: '',
        views: '',
        name: title,
        status: attrs.status ?? '',
        rating_twenty: attrs.ratingTwenty ?? '',
        rating_stars: attrs.ratingTwenty != null ? Number((Number(attrs.ratingTwenty) / 4).toFixed(1)) : '',
        progress: attrs.progress ?? 0,
        reconsume_count: attrs.reconsumeCount ?? 0,
        notes: clean(attrs.notes),
        started_at: attrs.startedAt ?? '',
        finished_at: attrs.finishedAt ?? '',
      };
    }).filter((item) => item.url);

    const next = offset + rows.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
