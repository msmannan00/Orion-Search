import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { EMPTY } from './constant';
import { count, decode, library } from './helper';

export async function tracks(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    return await library(payload, 'tracks', (row: string, username: string): social_resource => {
      const link = /<a[^>]+href="(\/music\/[^"]+)"[^>]*title="([^"]*)"/i.exec(row);
      const path = link?.[1] ?? '';
      const artistLink = /chartlist-artist[\s\S]{0,200}?href="(\/music\/[^"]+)"[^>]*>([^<]*)</i.exec(row);
      const image = /<img[^>]+src="([^"]+)"/i.exec(row)?.[1] ?? '';
      const timestamp = /<td class="chartlist-timestamp[\s\S]{0,300}?title="([^"]*)"/i.exec(row)?.[1] ?? /chartlist-timestamp[^>]*>\s*<span[^>]*>([^<]*)</i.exec(row)?.[1] ?? '';
      return {
        type: 'tracks',
        resource_id: path,
        url: path ? `https://www.last.fm${path}` : '',
        parent_url: `https://www.last.fm/user/${username}`,
        title: decode(link?.[2] ?? ''),
        caption: decode(artistLink?.[2] ?? ''),
        author: decode(artistLink?.[2] ?? username),
        datetime: decode(timestamp),
        media_type: 'track',
        media_url: path ? `https://www.last.fm${path}` : '',
        thumbnail_url: image,
        likes: String(/chartlist-loved/.test(row) ? 1 : ''),
        shares: '',
        views: String(count(row) || ''),
        track_path: path,
        track_name: decode(link?.[2] ?? ''),
        artist_name: decode(artistLink?.[2] ?? ''),
        artist_path: artistLink?.[1] ?? '',
        artist_url: artistLink?.[1] ? `https://www.last.fm${artistLink[1]}` : '',
        scrobble_count: count(row),
        is_loved: /chartlist-loved/.test(row),
        album_art: image,
        played_at: decode(timestamp),
        user_name: username,
        library_url: `https://www.last.fm/user/${username}/library/tracks`,
      };
    });
  }
  catch {
    return EMPTY;
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    return await library(payload, 'albums', (row: string, username: string): social_resource => {
      const link = /<a[^>]+href="(\/music\/[^"]+)"[^>]*title="([^"]*)"/i.exec(row);
      const path = link?.[1] ?? '';
      const artistLink = /chartlist-artist[\s\S]{0,200}?href="(\/music\/[^"]+)"[^>]*>([^<]*)</i.exec(row);
      const image = /<img[^>]+src="([^"]+)"/i.exec(row)?.[1] ?? '';
      return {
        type: 'albums',
        resource_id: path,
        url: path ? `https://www.last.fm${path}` : '',
        parent_url: `https://www.last.fm/user/${username}`,
        title: decode(link?.[2] ?? ''),
        caption: decode(artistLink?.[2] ?? ''),
        author: decode(artistLink?.[2] ?? username),
        datetime: '',
        media_type: 'album',
        media_url: path ? `https://www.last.fm${path}` : '',
        thumbnail_url: image,
        likes: '',
        shares: '',
        views: String(count(row) || ''),
        album_path: path,
        album_name: decode(link?.[2] ?? ''),
        artist_name: decode(artistLink?.[2] ?? ''),
        artist_path: artistLink?.[1] ?? '',
        artist_url: artistLink?.[1] ? `https://www.last.fm${artistLink[1]}` : '',
        scrobble_count: count(row),
        cover_art: image,
        user_name: username,
        library_url: `https://www.last.fm/user/${username}/library/albums`,
      };
    });
  }
  catch {
    return EMPTY;
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    return await library(payload, 'artists', (row: string, username: string): social_resource => {
      const link = /<a[^>]+href="(\/music\/[^"]+)"[^>]*title="([^"]*)"/i.exec(row);
      const path = link?.[1] ?? '';
      const image = /<img[^>]+src="([^"]+)"/i.exec(row)?.[1] ?? '';
      return {
        type: 'organizations',
        resource_id: path,
        url: path ? `https://www.last.fm${path}` : '',
        parent_url: `https://www.last.fm/user/${username}`,
        title: decode(link?.[2] ?? ''),
        caption: '',
        author: decode(link?.[2] ?? ''),
        datetime: '',
        media_type: 'artist',
        media_url: path ? `https://www.last.fm${path}` : '',
        thumbnail_url: image,
        likes: '',
        shares: '',
        views: String(count(row) || ''),
        artist_path: path,
        artist_name: decode(link?.[2] ?? ''),
        scrobble_count: count(row),
        artist_image: image,
        user_name: username,
        library_url: `https://www.last.fm/user/${username}/library/artists`,
      };
    });
  }
  catch {
    return EMPTY;
  }
}
