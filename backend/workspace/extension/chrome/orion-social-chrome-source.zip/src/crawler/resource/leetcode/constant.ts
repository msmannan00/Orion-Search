import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const UPSTREAM_MAX = 20;
