import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { MAX_PAGES_PER_CALL, PAGE_SIZE } from './constant';
import { Feed, ListingCursor } from './model';

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function tag(block: string, name: string): string {
  return decode(new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`, 'i').exec(block)?.[1] ?? '');
}

export function rssDescription(block: string): string {
  return /<description>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/description>/i.exec(block)?.[1] ?? '';
}

export function absolute(href: string): string {
  const value = String(href ?? '').trim();
  if (!value) {
    return '';
  }
  return /^https?:\/\//i.test(value) ? value : `https://letterboxd.com${value.startsWith('/') ? '' : '/'}${value}`;
}

export function stars(rating: number): string {
  return rating ? '★'.repeat(Math.floor(rating)) + (rating % 1 ? '½' : '') : '';
}

export function cursorOf(payload: CrawlPayload): ListingCursor {
  try {
    const parsed: any = JSON.parse(String(payload.cursor ?? '').trim() || '{}');
    const page = Number.parseInt(String(parsed?.page ?? ''), 10);
    const skip = Number.parseInt(String(parsed?.skip ?? ''), 10);
    return { page: Number.isFinite(page) && page > 0 ? page : 1, skip: Number.isFinite(skip) && skip > 0 ? skip : 0 };
  }
  catch {
    return { page: 1, skip: 0 };
  }
}

export async function feed(tab: TabController, username: string): Promise<Feed> {
  const empty: Feed = { creator: '', items: [], byLink: new Map() };
  try {
    const response = await tab.fetch(`https://letterboxd.com/${encodeURIComponent(username)}/rss/`);
    if (!response.ok) {
      return empty;
    }
    const xml = response.body;
    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((match) => match[1]);
    return {
      creator: tag(xml, 'title').replace(/^Letterboxd\s*-\s*/i, '').trim(),
      items,
      byLink: new Map(items.map((block) => [tag(block, 'link'), block])),
    };
  }
  catch {
    return empty;
  }
}

export async function html(tab: TabController, url: string): Promise<string> {
  try {
    const response = await tab.fetch(url);
    return response.ok ? response.body : '';
  }
  catch {
    return '';
  }
}

export function listingUrl(username: string, section: string, page: number): string {
  return `https://letterboxd.com/${encodeURIComponent(username)}/${section}/${page > 1 ? `page/${page}/` : ''}`;
}

export function hasNext(markup: string, current: number): boolean {
  const found = /<a[^>]+class="next"[^>]*href="[^"]*\/page\/(\d+)\/?"|<a[^>]+href="[^"]*\/page\/(\d+)\/?"[^>]+class="next"/i.exec(markup);
  return Number(found?.[1] ?? found?.[2] ?? 0) > current;
}

export function segments(markup: string, start: RegExp): string[] {
  const body = markup.split(/<div[^>]+class="pagination"/i)[0] ?? markup;
  const starts = [...body.matchAll(start)].map((match) => match.index ?? 0);
  return starts.map((at, index) => body.slice(at, starts[index + 1] ?? body.length));
}

export async function walk(tab: TabController, username: string, section: string, start: RegExp, payload: CrawlPayload): Promise<{ blocks: string[]; next?: ListingCursor }> {
  const limit = limitOf(payload, 25, PAGE_SIZE * MAX_PAGES_PER_CALL);
  const position = cursorOf(payload);
  const collected: string[] = [];
  let page = position.page;
  let skip = position.skip;
  let next: ListingCursor | undefined;

  for (let hop = 0; hop < MAX_PAGES_PER_CALL; hop++) {
    const markup = await html(tab, listingUrl(username, section, page));
    if (!markup) {
      break;
    }
    const fresh = segments(markup, start).slice(skip);
    const room = limit - collected.length;
    if (fresh.length > room) {
      collected.push(...fresh.slice(0, room));
      next = { page, skip: skip + room };
      break;
    }
    collected.push(...fresh);
    if (!hasNext(markup, page)) {
      next = undefined;
      break;
    }
    page += 1;
    skip = 0;
    next = { page, skip };
    if (collected.length >= limit) {
      break;
    }
  }

  return { blocks: collected, next };
}

export function page(items: social_resource[], next?: ListingCursor): CrawlPage {
  return { items, next_cursor: items.length && next ? JSON.stringify(next) : undefined };
}

export function reviewFromFeed(username: string, block: string): social_resource {
  const link = tag(block, 'link');
  const description = rssDescription(block);
  const poster = /<img src="([^"]+)"/.exec(description)?.[1] ?? '';
  const text = decode(description.replace(/<p><img[^>]*><\/p>/i, ''));
  const rating = tag(block, 'letterboxd:memberRating');
  const title = tag(block, 'title');
  return {
    type: 'reviews',
    resource_id: tag(block, 'guid') || link,
    url: link,
    parent_url: `https://letterboxd.com/${username}/`,
    title,
    caption: text.slice(0, 2000),
    author: tag(block, 'dc:creator') || username,
    datetime: tag(block, 'pubDate'),
    media_type: /letterboxd-list/.test(tag(block, 'guid')) ? 'list' : 'review',
    media_url: link,
    thumbnail_url: poster,
    likes: '',
    shares: '',
    views: '',
    guid: tag(block, 'guid'),
    entry_title: title,
    film_title: tag(block, 'letterboxd:filmTitle'),
    film_year: Number(tag(block, 'letterboxd:filmYear')) || 0,
    member_rating: Number(rating) || 0,
    rating_stars: stars(Number(rating) || 0),
    is_rewatch: /yes/i.test(tag(block, 'letterboxd:rewatch')),
    is_liked: /yes/i.test(tag(block, 'letterboxd:memberLike')),
    watched_date: tag(block, 'letterboxd:watchedDate'),
    tmdb_movie_id: tag(block, 'tmdb:movieId'),
    tmdb_tv_id: tag(block, 'tmdb:tvId'),
    tmdb_url: tag(block, 'tmdb:movieId') ? `https://www.themoviedb.org/movie/${tag(block, 'tmdb:movieId')}` : '',
    review_text: text,
    review_length: text.length,
    has_review: text.length > 0,
    poster_url: poster,
    film_slug: /\/film\/([^/]+)/.exec(link)?.[1] ?? '',
    film_url: /\/film\/([^/]+)/.exec(link)?.[1] ? `https://letterboxd.com/film/${/\/film\/([^/]+)/.exec(link)?.[1]}/` : '',
    creator: tag(block, 'dc:creator'),
    published_at: tag(block, 'pubDate'),
  };
}

export function reviewFromHtml(username: string, block: string, rss: Feed): social_resource {
  const head = /<h2[^>]+class="[^"]*(?:headline-2|name)[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i.exec(block);
  const link = absolute(head?.[1] ?? '');
  const entry = rss.byLink.get(link) ?? '';
  const itemName = decode(/data-item-name="([^"]*)"/.exec(block)?.[1] ?? '');
  const filmTitle = tag(entry, 'letterboxd:filmTitle') || decode(head?.[2] ?? '') || itemName.replace(/\s*\(\d{4}\)$/, '');
  const filmYear = Number(tag(entry, 'letterboxd:filmYear') || (/href="\/films\/year\/(\d{4})\//.exec(block)?.[1] ?? /\((\d{4})\)$/.exec(itemName)?.[1] ?? '')) || 0;
  const rated = /\brated-(\d+)\b/.exec(block)?.[1];
  const rating = Number(tag(entry, 'letterboxd:memberRating')) || (rated ? Number(rated) / 2 : 0);
  const dateText = decode(/<span[^>]+class="date[^"]*"[^>]*>([\s\S]*?)<\/span>/i.exec(block)?.[1] ?? '');
  const dateOnly = dateText.replace(/^(?:Rewatched|Watched|Added)\b/i, '').trim();
  const body = /<div[^>]+class="[^"]*body-text[^"]*"[^>]*>([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? '';
  const description = rssDescription(entry);
  const text = entry ? decode(description.replace(/<p><img[^>]*><\/p>/i, '')) : decode(body);
  const poster = /<img src="([^"]+)"/.exec(description)?.[1] ?? absolute(/data-poster-url="([^"]+)"/.exec(block)?.[1] ?? /<img[^>]+src="(https:\/\/a\.ltrbxd\.com\/[^"]+)"/.exec(block)?.[1] ?? '');
  const viewingId = /viewing:(\d+)/.exec(block)?.[1] ?? '';
  const guid = tag(entry, 'guid') || (viewingId ? `letterboxd-watch-${viewingId}` : '');
  const slug = /\/film\/([^/]+)/.exec(link)?.[1] ?? /data-(?:item|film)-slug="([^"]+)"/.exec(block)?.[1] ?? '';
  const creator = tag(entry, 'dc:creator') || rss.creator;
  const tmdbMovieId = tag(entry, 'tmdb:movieId');
  const title = tag(entry, 'title') || `${filmTitle}${filmYear ? `, ${filmYear}` : ''}${rating ? ` - ${stars(rating)}` : ''}`;
  const published = tag(entry, 'pubDate') || dateOnly;
  return {
    type: 'reviews',
    resource_id: guid || link,
    url: link,
    parent_url: `https://letterboxd.com/${username}/`,
    title,
    caption: text.slice(0, 2000),
    author: creator || username,
    datetime: published,
    media_type: 'review',
    media_url: link,
    thumbnail_url: poster,
    likes: /like-link-target[^>]*data-count="(\d+)"/.exec(block)?.[1] ?? '',
    shares: '',
    views: '',
    guid,
    entry_title: title,
    film_title: filmTitle,
    film_year: filmYear,
    member_rating: rating,
    rating_stars: stars(rating),
    is_rewatch: entry ? /yes/i.test(tag(entry, 'letterboxd:rewatch')) : /^Rewatched/i.test(dateText) || /icon-rewatch|-rewatch\b/.test(block),
    is_liked: entry ? /yes/i.test(tag(entry, 'letterboxd:memberLike')) : /icon-liked|class="[^"]*\bliked\b/.test(block),
    watched_date: tag(entry, 'letterboxd:watchedDate') || (/^(?:Re)?watched/i.test(dateText) ? dateOnly : ''),
    tmdb_movie_id: tmdbMovieId,
    tmdb_tv_id: tag(entry, 'tmdb:tvId'),
    tmdb_url: tmdbMovieId ? `https://www.themoviedb.org/movie/${tmdbMovieId}` : '',
    review_text: text,
    review_length: text.length,
    has_review: text.length > 0,
    poster_url: poster,
    film_slug: slug,
    film_url: slug ? `https://letterboxd.com/film/${slug}/` : '',
    creator,
    published_at: published,
  };
}

export function listFromFeed(username: string, block: string): social_resource {
  const link = tag(block, 'link');
  const description = rssDescription(block);
  const films = [...description.matchAll(/\/film\/([^/"]+)\//g)].map((match) => match[1]);
  return {
    type: 'posts',
    resource_id: tag(block, 'guid'),
    url: link,
    parent_url: `https://letterboxd.com/${username}/`,
    title: tag(block, 'title'),
    caption: decode(description).slice(0, 2000),
    author: tag(block, 'dc:creator') || username,
    datetime: tag(block, 'pubDate'),
    media_type: 'list',
    media_url: link,
    thumbnail_url: /<img src="([^"]+)"/.exec(description)?.[1] ?? '',
    likes: '',
    shares: '',
    views: '',
    guid: tag(block, 'guid'),
    list_title: tag(block, 'title'),
    description_text: decode(description),
    films_count: films.length,
    film_slugs: [...new Set(films)].join(', '),
    list_slug: /\/list\/([^/]+)/.exec(link)?.[1] ?? '',
    creator: tag(block, 'dc:creator'),
    published_at: tag(block, 'pubDate'),
  };
}

export function listFromHtml(username: string, block: string, rss: Feed): social_resource {
  const head = /<h2[^>]+class="[^"]*name[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i.exec(block);
  const link = absolute(head?.[1] ?? /<a[^>]+href="(\/[^"]+\/list\/[^"]+)"/.exec(block)?.[1] ?? '');
  const entry = rss.byLink.get(link) ?? '';
  const id = /data-film-list-id="(\d+)"/.exec(block)?.[1] ?? '';
  const guid = tag(entry, 'guid') || (id ? `letterboxd-list-${id}` : '');
  const description = rssDescription(entry);
  const notes = /<div[^>]+class="[^"]*\bnotes\b[^"]*"[^>]*>([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? '';
  const text = entry ? decode(description) : decode(notes);
  const feedFilms = [...description.matchAll(/\/film\/([^/"]+)\//g)].map((match) => match[1]);
  const posterFilms = [...block.matchAll(/data-item-slug="([^"]+)"/g)].map((match) => match[1]);
  const total = Number((/<span class="value">([\d,.]+)(?:&nbsp;|\s)*films?/i.exec(block)?.[1] ?? '').replace(/,/g, '')) || 0;
  const title = decode(head?.[2] ?? '') || tag(entry, 'title');
  const creator = tag(entry, 'dc:creator') || rss.creator;
  return {
    type: 'posts',
    resource_id: guid,
    url: link,
    parent_url: `https://letterboxd.com/${username}/`,
    title,
    caption: text.slice(0, 2000),
    author: creator || username,
    datetime: tag(entry, 'pubDate'),
    media_type: 'list',
    media_url: link,
    thumbnail_url: /<img src="([^"]+)"/.exec(description)?.[1] ?? absolute(/data-poster-url="([^"]+)"/.exec(block)?.[1] ?? ''),
    likes: (/href="[^"]*\/likes\/"[^>]*>[\s\S]*?<span class="label">([\d.,]+[KMB]?)<\/span>/i.exec(block)?.[1] ?? '').replace(/,/g, ''),
    shares: '',
    views: '',
    guid,
    list_title: title,
    description_text: text,
    films_count: total || feedFilms.length || posterFilms.length,
    film_slugs: [...new Set([...posterFilms, ...feedFilms])].join(', '),
    list_slug: /\/list\/([^/]+)/.exec(link)?.[1] ?? '',
    creator,
    published_at: tag(entry, 'pubDate'),
  };
}
