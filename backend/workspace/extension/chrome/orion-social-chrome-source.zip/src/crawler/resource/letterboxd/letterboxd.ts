import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, LIST_BLOCK, PERSON_BLOCK, REVIEW_BLOCK } from './constant';
import { decode, feed, listFromFeed, listFromHtml, page, reviewFromFeed, reviewFromHtml, tag, walk } from './helper';

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://letterboxd.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const [walked, rss] = await Promise.all([walk(tab, username, 'films/reviews', REVIEW_BLOCK, payload), feed(tab, username)]);
    if (!walked.blocks.length) {
      return String(payload.cursor ?? '').trim() ? EMPTY : { items: rss.items.map((block) => reviewFromFeed(username, block)).filter((item) => item.url) };
    }
    return page(walked.blocks.map((block) => reviewFromHtml(username, block, rss)).filter((item) => item.url), walked.next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://letterboxd.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const [walked, rss] = await Promise.all([walk(tab, username, 'lists', LIST_BLOCK, payload), feed(tab, username)]);
    if (!walked.blocks.length) {
      return String(payload.cursor ?? '').trim() ? EMPTY : { items: rss.items.filter((block) => /letterboxd-list/.test(tag(block, 'guid'))).map((block) => listFromFeed(username, block)).filter((item) => item.url) };
    }
    return page(walked.blocks.map((block) => listFromHtml(username, block, rss)).filter((item) => item.url), walked.next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

function personFromHtml(username: string, kind: 'followers' | 'friends', block: string): social_resource {
  const link = /href="(\/[^/"]+\/)"[^>]*class="name"[^>]*>([^<]*)</i.exec(block);
  const slug = (link?.[1] ?? '').replace(/^\/|\/$/g, '');
  const name = decode(link?.[2] ?? '') || slug;
  const avatar = /<img[^>]+src="([^"]+)"/i.exec(block)?.[1] ?? '';
  const url = slug ? `https://letterboxd.com/${slug}/` : '';
  return {
    type: kind,
    resource_id: slug,
    url,
    parent_url: `https://letterboxd.com/${username}/`,
    title: name,
    caption: '',
    author: slug,
    datetime: '',
    media_type: 'user',
    media_url: avatar,
    thumbnail_url: avatar,
    likes: '',
    shares: '',
    views: '',
    profile_username: slug,
    display_name: name,
    avatar,
    profile_url: url,
  };
}

async function people(payload: CrawlPayload, kind: 'followers' | 'friends', section: string): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://letterboxd.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const walked = await walk(tab, username, section, PERSON_BLOCK, payload);
    return page(walked.blocks.map((block) => personFromHtml(username, kind, block)).filter((item) => item.url), walked.next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  return people(payload, 'followers', 'followers');
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  return people(payload, 'friends', 'following');
}
