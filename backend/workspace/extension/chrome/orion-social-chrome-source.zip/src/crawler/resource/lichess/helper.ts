import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { GamesCursor } from './model';

export function stamp(value: unknown): string {
  const millis = Number(value);
  return Number.isFinite(millis) && millis > 0 ? new Date(millis).toISOString() : '';
}

export function parseCursor(payload: CrawlPayload): GamesCursor | null {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return null;
  }

  try {
    const parsed: any = JSON.parse(raw);
    const until = Number(parsed?.until);
    return Number.isFinite(until) && until > 0 ? { until, id: String(parsed?.id ?? '') } : null;
  }
  catch {
    return null;
  }
}
