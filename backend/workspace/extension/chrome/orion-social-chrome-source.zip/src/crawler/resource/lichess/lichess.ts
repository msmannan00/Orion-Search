import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { GamesCursor } from './model';
import { parseCursor, stamp } from './helper';

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  const tab = await openSession('https://lichess.org/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 25, 300);
    const cursor = parseCursor(payload);
    const max = cursor ? Math.min(limit + 1, 300) : limit;
    const params = `max=${max}&sort=dateDesc${cursor ? `&until=${cursor.until}` : ''}&opening=true&division=true&accuracy=true&clocks=false&evals=false`;
    const endpoint = `https://lichess.org/api/games/user/${encodeURIComponent(username)}?${params}`;
    let response = await tab.fetch(endpoint, { headers: { Accept: 'application/x-ndjson' } });
    for (let attempt = 0; !response.ok && response.status === 429 && attempt < 4; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      response = await tab.fetch(endpoint, { headers: { Accept: 'application/x-ndjson' } });
    }
    if (!response.ok) {
      return EMPTY;
    }

    const lines = response.body.split('\n').filter(Boolean);
    const items = lines.map((line: string): social_resource | null => {
      let game: any = null;
      try {
        game = JSON.parse(line);
      }
      catch {
        return null;
      }
      if (!game?.id || (cursor && game.id === cursor.id)) {
        return null;
      }

      const white = game.players?.white ?? {};
      const black = game.players?.black ?? {};
      const isWhite = String(white.user?.id ?? '').toLowerCase() === username.toLowerCase();
      const player = isWhite ? white : black;
      const opponent = isWhite ? black : white;
      const moves = String(game.moves ?? '').split(' ').filter(Boolean);
      return {
        type: 'games',
        resource_id: game.id,
        url: `https://lichess.org/${game.id}`,
        parent_url: `https://lichess.org/@/${username}`,
        title: `${white.user?.name ?? white.aiLevel ? `AI level ${white.aiLevel}` : 'anonymous'} vs ${black.user?.name ?? (black.aiLevel ? `AI level ${black.aiLevel}` : 'anonymous')}`,
        caption: game.opening?.name ?? '',
        author: player.user?.name ?? username,
        datetime: stamp(game.createdAt),
        media_type: game.speed ?? 'game',
        media_url: `https://lichess.org/${game.id}`,
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        game_id: game.id,
        rated: game.rated ?? false,
        variant: game.variant ?? '',
        speed: game.speed ?? '',
        perf: game.perf ?? '',
        status: game.status ?? '',
        source: game.source ?? '',
        winner: game.winner ?? '',
        opening_eco: game.opening?.eco ?? '',
        opening_name: game.opening?.name ?? '',
        opening_ply: game.opening?.ply ?? 0,
        moves_count: moves.length,
        moves: moves.slice(0, 200).join(' '),
        clock_initial: game.clock?.initial ?? 0,
        clock_increment: game.clock?.increment ?? 0,
        clock_total_time: game.clock?.totalTime ?? 0,
        tournament: game.tournament ?? '',
        swiss: game.swiss ?? '',
        division_middle: game.division?.middle ?? 0,
        division_end: game.division?.end ?? 0,
        last_fen: game.lastFen ?? '',
        white_name: white.user?.name ?? '',
        white_id: white.user?.id ?? '',
        white_title: white.user?.title ?? '',
        white_patron: white.user?.patron ?? false,
        white_rating: white.rating ?? 0,
        white_rating_diff: white.ratingDiff ?? 0,
        white_provisional: white.provisional ?? false,
        white_ai_level: white.aiLevel ?? 0,
        white_accuracy: white.analysis?.accuracy ?? 0,
        white_acpl: white.analysis?.acpl ?? 0,
        white_inaccuracy: white.analysis?.inaccuracy ?? 0,
        white_mistake: white.analysis?.mistake ?? 0,
        white_blunder: white.analysis?.blunder ?? 0,
        black_name: black.user?.name ?? '',
        black_id: black.user?.id ?? '',
        black_title: black.user?.title ?? '',
        black_patron: black.user?.patron ?? false,
        black_rating: black.rating ?? 0,
        black_rating_diff: black.ratingDiff ?? 0,
        black_provisional: black.provisional ?? false,
        black_ai_level: black.aiLevel ?? 0,
        black_accuracy: black.analysis?.accuracy ?? 0,
        black_acpl: black.analysis?.acpl ?? 0,
        black_inaccuracy: black.analysis?.inaccuracy ?? 0,
        black_mistake: black.analysis?.mistake ?? 0,
        black_blunder: black.analysis?.blunder ?? 0,
        player_color: isWhite ? 'white' : 'black',
        player_rating: player.rating ?? 0,
        player_rating_diff: player.ratingDiff ?? 0,
        player_accuracy: player.analysis?.accuracy ?? 0,
        opponent_name: opponent.user?.name ?? '',
        opponent_title: opponent.user?.title ?? '',
        opponent_rating: opponent.rating ?? 0,
        is_win: game.winner === (isWhite ? 'white' : 'black'),
        created_at: stamp(game.createdAt),
        last_move_at: stamp(game.lastMoveAt),
      };
    }).filter((item): item is social_resource => Boolean(item)).slice(0, limit);

    const last = items[items.length - 1];
    const until = Number(last?.['created_at'] ? Date.parse(String(last['created_at'])) : NaN);
    const hasMore = lines.length >= max && Number.isFinite(until) && until > 0 && (!cursor || until <= cursor.until);
    return { items, next_cursor: items.length && hasMore ? JSON.stringify({ until, id: String(last?.['game_id'] ?? '') } satisfies GamesCursor) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }
  const tab = await openSession('https://lichess.org/');
  if (!tab) {
    return EMPTY;
  }
  try {
    const response = await tab.fetch(`https://lichess.org/api/study/by/${encodeURIComponent(username)}?max=${limitOf(payload, 25, 100)}`, { headers: { Accept: 'application/x-ndjson' } });
    if (!response.ok) {
      return EMPTY;
    }
    const lines = response.body.split('\n').filter(Boolean);
    const items = lines.map((line: string): social_resource | null => {
      let study: any = null;
      try {
        study = JSON.parse(line);
      }
      catch {
        return null;
      }
      if (!study?.id) {
        return null;
      }
      return {
        type: 'projects',
        resource_id: study.id,
        url: `https://lichess.org/study/${study.id}`,
        parent_url: `https://lichess.org/@/${username}`,
        title: String(study.name ?? ''),
        caption: '',
        author: username,
        datetime: stamp(study.createdAt),
        media_type: 'study',
        media_url: `https://lichess.org/study/${study.id}`,
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        study_id: study.id,
        name: String(study.name ?? ''),
        created_at: stamp(study.createdAt),
        updated_at: stamp(study.updatedAt),
      };
    }).filter((item): item is social_resource => item !== null);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
