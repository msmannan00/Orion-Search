import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { Cursor } from './model';

export function host(payload: CrawlPayload): string {
  const fromUrl = /^https?:\/\/([^/]+\.livejournal\.com)/i.exec(payload.url ?? '')?.[1];
  if (fromUrl) {
    return fromUrl;
  }
  const username = String(payload.username ?? '').replace(/_/g, '-');
  return username ? `${username}.livejournal.com` : '';
}

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&apos;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function tag(block: string, name: string): string {
  return decode(new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`, 'i').exec(block)?.[1] ?? '');
}

export function rawTag(block: string, name: string): string {
  return new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`, 'i').exec(block)?.[1] ?? '';
}

export function escapeRe(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function parseCursor(raw: unknown): Cursor {
  const first: Cursor = { offset: 0, skip: 0, rss: [], done: [] };
  const text = String(raw ?? '').trim();
  if (!text) {
    return first;
  }
  try {
    const data = JSON.parse(text);
    const num = (value: unknown): number | null => {
      const parsed = Number(value);
      return value != null && Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : null;
    };
    const list = (value: unknown): string[] => (Array.isArray(value) ? value.map((entry) => String(entry ?? '')).filter(Boolean).slice(0, 200) : []);
    return { offset: num(data?.offset), skip: num(data?.skip) ?? 0, rss: list(data?.rss), done: list(data?.done) };
  }
  catch {
    return first;
  }
}

export function postId(url: string): string {
  return /\/(\d+)\.html/.exec(url)?.[1] ?? '';
}

export async function feed(tab: TabController, site: string) {
  const response = await tab.fetch(`https://${site}/data/rss`);
  if (!response.ok) {
    return [];
  }

  const xml = response.body;
  const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((match) => match[1]);
  return items.map((block: string): social_resource => {
    const link = tag(block, 'link');
    const description = rawTag(block, 'description');
    const text = decode(description);
    const images = [...description.matchAll(/<img[^>]+src="([^"]+)"/g)].map((match) => match[1]);
    const categories = [...block.matchAll(/<category>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/category>/g)].map((match) => decode(match[1]));
    return {
      type: 'posts',
      resource_id: postId(link) || tag(block, 'guid'),
      url: link,
      parent_url: `https://${site}/`,
      title: tag(block, 'title'),
      caption: text.slice(0, 2000),
      author: tag(block, 'lj:poster') || site.split('.')[0],
      datetime: tag(block, 'pubDate'),
      media_type: images.length ? 'image' : 'post',
      media_url: images[0] ?? '',
      thumbnail_url: images[0] ?? '',
      likes: '',
      shares: '',
      views: '',
      post_id: postId(link),
      guid: tag(block, 'guid'),
      title_text: tag(block, 'title'),
      content_text: text.slice(0, 8000),
      content_length: text.length,
      word_count: text.split(/\s+/).filter(Boolean).length,
      comment_count: Number(tag(block, 'lj:reply-count')) || 0,
      comments_url: tag(block, 'comments'),
      security: tag(block, 'lj:security'),
      mood: tag(block, 'lj:mood'),
      music: tag(block, 'lj:music'),
      location: tag(block, 'lj:location'),
      poster: tag(block, 'lj:poster'),
      journal: site.split('.')[0],
      journal_host: site,
      categories: categories.join(', '),
      categories_count: categories.length,
      images_count: images.length,
      image_urls: images.slice(0, 20).join(', '),
      links: [...new Set([...description.matchAll(/<a[^>]+href="([^"]+)"/g)].map((match) => match[1]))].slice(0, 20).join(', '),
      published_at: tag(block, 'pubDate'),
    };
  }).filter((item) => item.url);
}

export function bare(site: string, id: string): social_resource {
  return {
    type: 'posts', resource_id: id, url: `https://${site}/${id}.html`, parent_url: `https://${site}/`, title: '', caption: '',
    author: site.split('.')[0], datetime: '', media_type: 'post', media_url: '', thumbnail_url: '',
    likes: '', shares: '', views: '', post_id: id, guid: '', title_text: '', content_text: '',
    content_length: 0, word_count: 0, comment_count: 0, comments_url: '', security: '', mood: '',
    music: '', location: '', poster: '', journal: site.split('.')[0], journal_host: site,
    categories: '', categories_count: 0, images_count: 0, image_urls: '', links: '', published_at: '',
  };
}

export function entryIds(html: string, site: string): string[] {
  const re = new RegExp(`https?://${escapeRe(site)}/(\\d+)\\.html([^"'\\s<>]*)`, 'gi');
  const ids: string[] = [];
  for (const match of html.matchAll(re)) {
    if (/(?:^|[?&;])(?:amp;)?(?:thread|replyto)=/i.test(match[2] ?? '')) {
      continue;
    }
    if (!ids.includes(match[1])) {
      ids.push(match[1]);
    }
  }
  return ids;
}

export function olderSkip(html: string, site: string, skip: number): number | null {
  const re = new RegExp(`href=["'](?:https?://${escapeRe(site)})?/?\\?(?:[^"'#]*?&(?:amp;)?)?skip=(\\d+)`, 'gi');
  const values = [...html.matchAll(re)].map((match) => Number(match[1])).filter((value) => Number.isFinite(value) && value > skip);
  return values.length ? Math.min(...values) : null;
}
