import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { limitOf } from '../../helper/helper';
import { EMPTY } from './constant';
import { bare, entryIds, feed, host, olderSkip, parseCursor } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const site = host(payload);
  if (!site) {
    return EMPTY;
  }

  const want = limitOf(payload, 25, 100);
  const cursor = parseCursor(payload.cursor);

  const tab = await openSession(`https://${site}/`);
  if (!tab) {
    return EMPTY;
  }

  try {
    const items: social_resource[] = [];
    let rss = cursor.rss;
    let skip = cursor.skip;
    let done = cursor.done;

    if (cursor.offset != null) {
      const rich = await feed(tab, site);
      rss = rich.map((item) => String(item['post_id'] ?? item.resource_id ?? '')).filter(Boolean).slice(0, 100);
      items.push(...rich.slice(cursor.offset, cursor.offset + want));
      if (cursor.offset + want < rich.length) {
        return { items, next_cursor: items.length ? JSON.stringify({ offset: cursor.offset + want, rss }) : undefined };
      }
      skip = rich.length;
      done = [];
      if (items.length >= want) {
        return { items, next_cursor: JSON.stringify({ skip, rss, done }) };
      }
    }

    let more = false;
    const emitted = done.slice();
    const exclude = new Set<string>([...rss, ...done, ...items.map((item) => String(item['post_id'] ?? ''))]);
    const maxHops = Math.min(12, Math.ceil(want / 10) + 2);
    for (let hop = 0; hop < maxHops && items.length < want; hop++) {
      await tab.navigate(`https://${site}/?skip=${skip}`);
      const html = await tab.html();
      const ids = entryIds(html, site);
      if (!ids.length) {
        more = false;
        break;
      }

      const older = olderSkip(html, site, skip);
      const fresh = ids.filter((id) => !exclude.has(id));
      const consumed = new Set<string>();
      for (const id of fresh) {
        if (items.length >= want) {
          break;
        }
        exclude.add(id);
        consumed.add(id);
        emitted.push(id);
        items.push(bare(site, id));
      }

      if (consumed.size < fresh.length) {
        more = true;
        break;
      }

      if (older == null) {
        more = false;
        break;
      }
      skip = older;
      more = true;
    }

    done = emitted.slice(-100);
    return { items, next_cursor: items.length && more ? JSON.stringify({ skip, rss, done }) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  const tab = await openSession('https://www.livejournal.com/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const response = await tab.fetch(`https://www.livejournal.com/misc/fdata.bml?user=${encodeURIComponent(username)}`, { headers: { Accept: 'text/plain' } });
    if (!response.ok) {
      return EMPTY;
    }

    const names = response.body.split(/\r?\n/)
      .filter((line) => /^<\s+\S/.test(line))
      .map((line) => line.replace(/^<\s+/, '').trim())
      .filter(Boolean);
    const unique = [...new Set(names)];

    const want = limitOf(payload, 25, 200);
    const start = Math.max(0, Math.floor(Number(String(payload.cursor ?? '').trim())) || 0);
    const slice = unique.slice(start, start + want);

    const items = slice.map((name: string): social_resource => {
      const url = `https://${name.replace(/_/g, '-')}.livejournal.com/`;
      return {
        type: 'friends',
        resource_id: name,
        url,
        parent_url: `https://${host(payload)}`,
        title: name,
        caption: '',
        author: name,
        datetime: '',
        media_type: 'user',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        profile_username: name,
        profile_url: url,
      };
    });

    const nextIndex = start + slice.length;
    return { items, next_cursor: items.length && nextIndex < unique.length ? String(nextIndex) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
