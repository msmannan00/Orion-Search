import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { ApiPage } from './model';

export function origin(payload: CrawlPayload): string {
  return /^https?:\/\/[^/]+/.exec(payload.url ?? '')?.[0] ?? 'https://mastodon.social';
}

export async function api(tab: TabController, base: string, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`${base}${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function cursorOf(payload: CrawlPayload): string {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return '';
  }
  try {
    const parsed = JSON.parse(raw);
    return String(parsed?.max_id ?? '').trim();
  }
  catch {
    return /^[A-Za-z0-9_-]+$/.test(raw) ? raw : '';
  }
}

export async function apiPage(tab: TabController, base: string, path: string, limit: number, maxId: string): Promise<ApiPage> {
  try {
    const response = await tab.fetch(`${base}${path}?limit=${limit}${maxId ? `&max_id=${encodeURIComponent(maxId)}` : ''}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return { data: [], next: '' };
    }
    const data = JSON.parse(response.body);
    const list = Array.isArray(data) ? data : [];
    const linkNext = /max_id=([^&>]+)[^>]*>\s*;\s*rel="next"/.exec(response.headers?.['link'] ?? '')?.[1] ?? '';
    const last = linkNext ? decodeURIComponent(linkNext) : (list.length >= limit ? String(list[list.length - 1]?.id ?? '').trim() : '');
    return { data: list, next: last };
  }
  catch {
    return { data: [], next: '' };
  }
}

export function page(items: social_resource[], upstream: ApiPage, previous: string): CrawlPage {
  const next = upstream.next && upstream.next !== previous ? upstream.next : '';
  return { items, next_cursor: items.length && next ? JSON.stringify({ max_id: next }) : undefined };
}

export async function lookup(tab: TabController, base: string, username: string): Promise<any> {
  return await api(tab, base, `/api/v1/accounts/lookup?acct=${encodeURIComponent(username)}`);
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<br\s*\/?>/gi, ' ').replace(/<\/p>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'").replace(/\s+/g, ' ').trim();
}

export function person(base: string, username: string, type: 'followers' | 'friends' | 'connections', entry: any): social_resource {
  const fields: any[] = Array.isArray(entry.fields) ? entry.fields : [];
  const emojis: any[] = Array.isArray(entry.emojis) ? entry.emojis : [];
  return {
    type,
    resource_id: entry.id ?? '',
    url: entry.url ?? '',
    parent_url: `${base}/@${username}`,
    title: entry.display_name ?? entry.username ?? '',
    caption: clean(entry.note).slice(0, 600),
    author: entry.acct ?? entry.username ?? '',
    datetime: entry.created_at ?? '',
    media_type: entry.bot ? 'bot' : entry.group ? 'group' : 'user',
    media_url: entry.url ?? '',
    thumbnail_url: entry.avatar ?? '',
    likes: '',
    shares: '',
    views: '',
    account_id: entry.id ?? '',
    username: entry.username ?? '',
    acct: entry.acct ?? '',
    domain: String(entry.acct ?? '').split('@')[1] ?? new URL(base).host,
    display_name: entry.display_name ?? '',
    note: clean(entry.note),
    uri: entry.uri ?? '',
    avatar: entry.avatar ?? '',
    avatar_static: entry.avatar_static ?? '',
    header: entry.header ?? '',
    header_static: entry.header_static ?? '',
    followers_count: entry.followers_count ?? 0,
    statuses_count: entry.statuses_count ?? 0,
    last_status_at: entry.last_status_at ?? '',
    is_locked: entry.locked ?? false,
    is_bot: entry.bot ?? false,
    is_group: entry.group ?? false,
    is_discoverable: entry.discoverable ?? false,
    is_indexable: entry.indexable ?? false,
    is_suspended: entry.suspended ?? false,
    is_limited: entry.limited ?? false,
    hide_collections: entry.hide_collections ?? false,
    noindex: entry.noindex ?? false,
    fields_count: fields.length,
    field_names: fields.map((field: any) => field?.name ?? '').filter(Boolean).join(', '),
    field_values: fields.map((field: any) => clean(field?.value)).filter(Boolean).join(' | '),
    field_verified: fields.filter((field: any) => field?.verified_at).map((field: any) => field?.name ?? '').join(', '),
    emojis: emojis.map((emoji: any) => emoji?.shortcode ?? '').filter(Boolean).join(', '),
    roles: Array.isArray(entry.roles) ? entry.roles.map((role: any) => role?.name ?? '').filter(Boolean).join(', ') : '',
    created_at: entry.created_at ?? '',
  };
}
