import { CrawlPage } from '../../../app/extension/model/extension.model';

export const MEDIUM_QUERY = 'query UserProfileQuery($username: ID, $limit: PaginationLimit, $from: String) { userResult(username: $username) { ... on User { id name username homepagePostsConnection(paging: {limit: $limit, from: $from}) { posts { id title mediumUrl uniqueSlug firstPublishedAt latestPublishedAt readingTime clapCount postResponses { count } extendedPreviewContent { subtitle } creator { id name username } tags { displayTitle } } pagingInfo { next { limit from } } } } } }';

export const EMPTY: CrawlPage = { items: [] };
