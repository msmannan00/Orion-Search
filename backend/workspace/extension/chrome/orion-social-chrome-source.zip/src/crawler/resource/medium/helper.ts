import { social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { MEDIUM_QUERY } from './constant';
import { MediumPage } from './model';

export function iso(ms: unknown): string {
  const value = Number(ms);
  return Number.isFinite(value) && value > 0 ? new Date(value).toISOString() : '';
}

export function mediumPost(post: any, username: string): social_resource {
  const subtitle = decode(post.extendedPreviewContent?.subtitle ?? '');
  const tags: any[] = Array.isArray(post.tags) ? post.tags : [];
  const url = post.mediumUrl ?? '';
  return {
    type: 'posts',
    resource_id: String(post.id ?? ''),
    url,
    parent_url: `https://medium.com/@${username}`,
    title: post.title ?? '',
    caption: subtitle.slice(0, 2000),
    author: post.creator?.name ?? username,
    datetime: iso(post.firstPublishedAt),
    media_type: 'article',
    media_url: url,
    thumbnail_url: '',
    likes: String((post.clapCount ?? 0) || ''),
    shares: '',
    views: '',
    post_id: String(post.id ?? ''),
    guid: String(post.id ?? ''),
    title_text: post.title ?? '',
    slug: post.uniqueSlug ?? url.split('/').pop() ?? '',
    content_text: subtitle.slice(0, 8000),
    content_length: subtitle.length,
    word_count: subtitle.split(/\s+/).filter(Boolean).length,
    reading_time_minutes: Math.max(1, Math.round(Number(post.readingTime) || 0)) || 0,
    responses: post.postResponses?.count ?? 0,
    categories: tags.map((tag: any) => tag?.displayTitle ?? '').filter(Boolean).join(', '),
    categories_count: tags.length,
    images_count: 0,
    image_urls: '',
    first_image: '',
    links: '',
    creator: post.creator?.name ?? '',
    creator_username: post.creator?.username ?? '',
    atom_updated: iso(post.latestPublishedAt),
    published_at: iso(post.firstPublishedAt),
    is_publication_post: false,
    publication: '',
  };
}

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export async function fetchPage(tab: TabController, username: string, limit: number, from: string | null): Promise<MediumPage | null> {
  const body = JSON.stringify([{ operationName: 'UserProfileQuery', variables: { username, limit, from }, query: MEDIUM_QUERY }]);
  const response = await tab.fetch('https://medium.com/_/graphql', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
  if (!response.ok) {
    return null;
  }

  let json: any;
  try {
    json = JSON.parse(response.body);
  }
  catch {
    return null;
  }

  const connection = json?.[0]?.data?.userResult?.homepagePostsConnection;
  const from_next = connection?.pagingInfo?.next?.from;
  return { posts: Array.isArray(connection?.posts) ? connection.posts : [], from: from_next ? String(from_next) : null };
}
