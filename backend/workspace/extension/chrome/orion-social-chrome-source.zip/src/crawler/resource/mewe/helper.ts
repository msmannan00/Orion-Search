import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { ORIGIN } from './constant';

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function jsonBlocks(html: string): any[] {
  const parsed: any[] = [];
  for (const match of html.matchAll(/<script[^>]*type="application\/json"[^>]*>([\s\S]*?)<\/script>/g)) {
    try {
      parsed.push(JSON.parse(match[1]));
    }
    catch {
    }
  }
  const next = /<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1];
  if (next) {
    try {
      parsed.push(JSON.parse(next));
    }
    catch {
    }
  }
  return parsed;
}

export function collect(node: any, key: string, out: any[] = []): any[] {
  if (Array.isArray(node)) {
    node.forEach((entry) => collect(entry, key, out));
    return out;
  }
  if (node && typeof node === 'object') {
    for (const [name, value] of Object.entries(node)) {
      if (name === key) {
        out.push(value);
      }
      collect(value, key, out);
    }
  }
  return out;
}

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(path.startsWith('http') ? path : `${ORIGIN}${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function link(href: unknown): string {
  const value = String(href ?? '').trim();
  if (!value) {
    return '';
  }
  const filled = value.replace(/\{imageSize\}/g, '800x800').replace(/\{static\}/g, '0').replace(/\{[^}]*\}/g, '');
  return /^https?:\/\//i.test(filled) ? filled : `${ORIGIN}${filled.startsWith('/') ? '' : '/'}${filled}`;
}

export function mediaUrl(image: any): string {
  if (!image) {
    return '';
  }
  if (typeof image === 'string') {
    return image;
  }
  return image.url_list?.[0] ?? image.url ?? link(image.photo?._links?.img?.href ?? image.video?._links?.linkTemplate?.href ?? image._links?.img?.href ?? '');
}

export function thumbUrl(image: any): string {
  if (!image || typeof image === 'string') {
    return '';
  }
  return image.thumb_url ?? image.url_list?.[0] ?? link(image.photo?._links?.img?.href ?? image._links?.img?.href ?? '');
}

export function timestamp(value: unknown): string {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return new Date(value < 1e12 ? value * 1000 : value).toISOString();
  }
  return String(value ?? '');
}

export async function resolveUserId(tab: TabController, username: string): Promise<string> {
  if (/^[0-9a-f]{24}$/i.test(username)) {
    return username;
  }
  const handle = encodeURIComponent(username);
  for (const path of [`/api/v2/mycontacts/user/${handle}`, `/api/v2/profile/${handle}`, `/api/v2/users/${handle}`]) {
    const data = await api(tab, path);
    const id = String(data?.id ?? data?.user?.id ?? data?.userId ?? '');
    if (/^[0-9a-f]{24}$/i.test(id)) {
      return id;
    }
  }
  try {
    const response = await tab.fetch(`${ORIGIN}/i/${handle}`);
    if (response.ok) {
      const html = response.body;
      const id = /\/api\/v2\/home\/user\/([0-9a-f]{24})\//i.exec(html)?.[1] ?? /"userId"\s*:\s*"([0-9a-f]{24})"/i.exec(html)?.[1] ?? '';
      if (id) {
        return id;
      }
    }
  }
  catch {
  }
  return '';
}

export function parseCursor(payload: CrawlPayload): { next: string; userId: string } {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { next: '', userId: '' };
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return { next: String(parsed.next ?? ''), userId: String(parsed.userId ?? '') };
    }
  }
  catch {
  }
  return { next: raw.startsWith('/') || raw.startsWith('http') ? raw : '', userId: '' };
}

export function withLimit(href: string, limit: number): string {
  try {
    const url = new URL(href, ORIGIN);
    url.searchParams.set('limit', String(limit));
    return `${url.pathname}${url.search}`;
  }
  catch {
    return href;
  }
}

export function nextHref(data: any): string {
  const href = String(data?._links?.nextPage?.href ?? data?._links?.next?.href ?? data?.nextPage ?? '').trim();
  if (!href) {
    return '';
  }
  try {
    const url = new URL(href, ORIGIN);
    return `${url.pathname}${url.search}`;
  }
  catch {
    return '';
  }
}

export function toResource(entry: any, username: string, users: Map<string, any>): social_resource {
  const origin = ORIGIN;
  const id = String(entry.postItemId ?? entry.id ?? entry.item_id ?? entry.post_id ?? entry.postId ?? '');
  const user = entry.user ?? (entry.userId ? users.get(String(entry.userId)) : undefined) ?? undefined;
  const text = entry.text ?? entry.desc ?? entry.content ?? entry.title ?? '';
  const images: any[] = Array.isArray(entry.image_list) ? entry.image_list : Array.isArray(entry.images) ? entry.images : Array.isArray(entry.medias) ? entry.medias : [];
  const preview = entry.link && typeof entry.link === 'object' ? entry.link : null;
  const shareUrl = entry.share_url ?? entry.url ?? (typeof entry.link === 'string' ? entry.link : undefined) ?? (entry._links?.post?.href ? link(entry._links.post.href) : undefined) ?? preview?._links?.url?.href ?? `${origin}/${username}`;
  const likeCount = entry.like_count ?? entry.digg_count ?? entry.likes ?? entry.emojis?.total ?? 0;
  const commentCount = entry.comment_count ?? (typeof entry.comments === 'number' ? entry.comments : entry.comments?.total) ?? 0;
  const shareCount = entry.share_count ?? entry.shares ?? entry.sharesCount ?? 0;
  const created = entry.create_time ? new Date(Number(entry.create_time) * 1000).toISOString() : timestamp(entry.createdAt ?? entry.published_at ?? '');
  const tags: any[] = Array.isArray(entry.hashtags) ? entry.hashtags : Array.isArray(entry.hashTags) ? entry.hashTags : [];
  return {
    type: 'posts',
    resource_id: id,
    url: shareUrl,
    parent_url: `${origin}/${username}`,
    title: decode(String(entry.title ?? preview?.title ?? '')),
    caption: decode(String(text)),
    author: entry.author?.nickname ?? user?.name ?? username,
    datetime: created,
    media_type: images.length ? (images[0]?.video ? 'video' : 'image') : 'text',
    media_url: mediaUrl(images[0]),
    thumbnail_url: thumbUrl(images[0]),
    likes: String(likeCount || ''),
    shares: String(shareCount || ''),
    views: String((entry.view_count ?? entry.play_count ?? 0) || ''),
    post_id: id,
    text: decode(String(text)),
    text_length: decode(String(text)).length,
    like_count: likeCount,
    comment_count: commentCount,
    share_count: shareCount,
    collect_count: entry.collect_count ?? 0,
    view_count: entry.view_count ?? entry.play_count ?? 0,
    images_count: images.length,
    image_urls: images.map((image: any) => mediaUrl(image)).filter(Boolean).slice(0, 20).join(', '),
    tags: tags.map((tag: any) => tag?.name ?? tag).filter(Boolean).join(', '),
    author_id: entry.author?.id ?? user?.id ?? entry.userId ?? '',
    author_name: entry.author?.nickname ?? user?.name ?? '',
    author_handle: entry.author?.unique_id ?? user?.username ?? user?.publicLinkId ?? '',
    author_avatar: entry.author?.avatar_thumb?.url_list?.[0] ?? (typeof user?.avatar === 'string' ? user.avatar : undefined) ?? link(user?._links?.avatar?.href ?? ''),
    created_at: entry.create_time ? new Date(Number(entry.create_time) * 1000).toISOString() : timestamp(entry.createdAt ?? ''),
  };
}

export function dedupe(candidates: any[], username: string, users: Map<string, any>): social_resource[] {
  const seen = new Set<string>();
  const items: social_resource[] = [];
  candidates.filter((entry: any) => entry && typeof entry === 'object').forEach((entry: any) => {
    const item = toResource(entry, username, users);
    if (!item.resource_id || seen.has(item.resource_id)) {
      return;
    }
    seen.add(item.resource_id);
    items.push(item);
  });
  return items;
}

export async function scrape(tab: TabController, username: string): Promise<Array<social_resource>> {
  try {
    const response = await tab.fetch(`${ORIGIN}/${encodeURIComponent(username)}`);
    if (!response.ok) {
      return [];
    }
    const html = response.body;
    const blocks = jsonBlocks(html);
    const candidates = [
      ...blocks.flatMap((block: any) => collect(block, 'item_list')).flat(),
      ...blocks.flatMap((block: any) => collect(block, 'posts')).flat(),
      ...blocks.flatMap((block: any) => collect(block, 'feed')).flat(),
    ];
    return dedupe(candidates, username, new Map());
  }
  catch {
    return [];
  }
}
