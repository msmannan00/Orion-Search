import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, ORIGIN } from './constant';
import { api, dedupe, nextHref, parseCursor, resolveUserId, scrape, withLimit } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').replace(/^@/, '');
  const tab = username ? await openSession(`${ORIGIN}/`) : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 25, 50);
    const cursor = parseCursor(payload);

    let userId = cursor.userId;
    let path = cursor.next ? withLimit(cursor.next, limit) : '';
    if (!path) {
      if (cursor.next) {
        return EMPTY;
      }
      userId = await resolveUserId(tab, username);
      path = `/api/v2/home/user/${encodeURIComponent(userId || username)}/postsfeed?limit=${limit}`;
    }

    const data = await api(tab, path);
    const feed: any[] = Array.isArray(data?.feed) ? data.feed : Array.isArray(data?.posts) ? data.posts : [];
    if (feed.length) {
      const users = new Map<string, any>(((Array.isArray(data?.users) ? data.users : []) as any[]).map((user: any) => [String(user?.id ?? ''), user]));
      const items = dedupe(feed, username, users);
      const next = nextHref(data);
      const nextCursor = next && next !== cursor.next ? JSON.stringify({ next, userId }) : '';
      return { items, next_cursor: items.length && nextCursor ? nextCursor : undefined };
    }

    if (cursor.next) {
      return EMPTY;
    }
    return { items: await scrape(tab, username) };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
