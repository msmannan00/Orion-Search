import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}

export async function feed(tab: TabController, url: string): Promise<any> {
  try {
    const response = await tab.fetch(url, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function cursorOf(payload: CrawlPayload): { offset: number; last: string } {
  try {
    const parsed = JSON.parse(String(payload.cursor ?? ''));
    const offset = Number(parsed?.offset);
    return { offset: Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0, last: String(parsed?.last ?? '') };
  }
  catch {
    return { offset: 0, last: '' };
  }
}

export function entry(username: string, type: 'posts', item: any): social_resource {
  const author = item.author ?? {};
  const microblog = item._microblog ?? {};
  const images: string[] = Array.isArray(item.attachments) ? item.attachments.map((attachment: any) => attachment?.url ?? '').filter(Boolean) : [];
  const inline = [...String(item.content_html ?? '').matchAll(/<img[^>]+src="([^"]+)"/g)].map((match) => match[1]);
  return {
    type,
    resource_id: String(item.id ?? ''),
    url: item.url ?? '',
    parent_url: `https://micro.blog/${username}`,
    title: clean(item.title),
    caption: clean(item.content_html ?? item.content_text),
    author: author._microblog?.username ?? author.name ?? username,
    datetime: item.date_published ?? '',
    media_type: images.length || inline.length ? 'image' : 'post',
    media_url: images[0] ?? inline[0] ?? '',
    thumbnail_url: images[0] ?? inline[0] ?? '',
    likes: '',
    shares: '',
    views: '',
    post_id: item.id ?? '',
    title_text: clean(item.title),
    content_text: clean(item.content_html ?? item.content_text),
    content_length: clean(item.content_html ?? item.content_text).length,
    content_html: String(item.content_html ?? '').slice(0, 4000),
    external_url: item.external_url ?? '',
    is_reply: Boolean(microblog.is_reply ?? item.in_reply_to),
    in_reply_to: item.in_reply_to ?? microblog.in_reply_to ?? '',
    is_bookmark: microblog.is_bookmark ?? false,
    is_deleted: microblog.is_deleted ?? false,
    is_conversation: microblog.is_conversation ?? false,
    is_mention: microblog.is_mention ?? false,
    post_type: microblog.post_type ?? '',
    audio_url: microblog.audio_url ?? '',
    images_count: images.length + inline.length,
    image_urls: [...new Set([...images, ...inline])].join(', '),
    attachments_count: Array.isArray(item.attachments) ? item.attachments.length : 0,
    attachment_types: Array.isArray(item.attachments) ? [...new Set(item.attachments.map((attachment: any) => attachment?.mime_type ?? '').filter(Boolean))].join(', ') : '',
    tags: Array.isArray(item.tags) ? item.tags.join(', ') : '',
    author_name: author.name ?? '',
    author_url: author.url ?? '',
    author_avatar: author.avatar ?? '',
    author_username: author._microblog?.username ?? '',
    author_followed_by: author._microblog?.followed_by ?? false,
    author_bio: clean(author._microblog?.bio),
    date_published: item.date_published ?? '',
    date_modified: item.date_modified ?? '',
  };
}
