export interface Cursor {
  id: string;
  until: string;
}

export interface Upstream {
  raw: any[];
  next?: string;
}
