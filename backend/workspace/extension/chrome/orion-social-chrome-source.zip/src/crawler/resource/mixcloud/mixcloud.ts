import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, page, pagedPath, person, picture } from './helper';

export async function tracks(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.mixcloud.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, pagedPath(`/${encodeURIComponent(username)}/cloudcasts/`, payload));
    return page(((data?.data ?? []) as any[]).map((cast: any): social_resource => {
      const tags: any[] = Array.isArray(cast.tags) ? cast.tags : [];
      const sections: any[] = Array.isArray(cast.sections) ? cast.sections : [];
      return {
        type: 'tracks',
        resource_id: cast.key ?? '',
        url: cast.url ?? '',
        parent_url: `https://www.mixcloud.com/${username}/`,
        title: cast.name ?? '',
        caption: clean(cast.description),
        author: cast.user?.username ?? username,
        datetime: cast.created_time ?? '',
        media_type: 'cloudcast',
        media_url: cast.url ?? '',
        thumbnail_url: picture(cast.pictures),
        likes: String((cast.favorite_count ?? 0) || ''),
        shares: String((cast.repost_count ?? 0) || ''),
        views: String((cast.play_count ?? 0) || ''),
        cast_key: cast.key ?? '',
        slug: cast.slug ?? '',
        name: cast.name ?? '',
        description: clean(cast.description),
        audio_length: cast.audio_length ?? 0,
        play_count: cast.play_count ?? 0,
        favorite_count: cast.favorite_count ?? 0,
        listener_count: cast.listener_count ?? 0,
        repost_count: cast.repost_count ?? 0,
        comment_count: cast.comment_count ?? 0,
        is_exclusive: cast.is_exclusive ?? false,
        is_explicit: cast.is_explicit ?? false,
        hidden_stats: cast.hidden_stats ?? false,
        tags: tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        tags_count: tags.length,
        tag_urls: tags.map((tag: any) => tag?.url ?? '').filter(Boolean).join(', '),
        sections_count: sections.length,
        section_artists: [...new Set(sections.map((section: any) => section?.artist?.name ?? '').filter(Boolean))].join(', '),
        section_songs: sections.map((section: any) => section?.song?.name ?? '').filter(Boolean).slice(0, 40).join(' | '),
        picture: picture(cast.pictures),
        picture_medium: cast.pictures?.medium ?? '',
        user_key: cast.user?.key ?? '',
        user_name: cast.user?.name ?? '',
        user_username: cast.user?.username ?? '',
        user_url: cast.user?.url ?? '',
        user_picture: picture(cast.user?.pictures),
        created_time: cast.created_time ?? '',
        updated_time: cast.updated_time ?? '',
      };
    }).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.mixcloud.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, pagedPath(`/${encodeURIComponent(username)}/playlists/`, payload));
    return page(((data?.data ?? []) as any[]).map((playlist: any): social_resource => ({
      type: 'albums',
      resource_id: playlist.key ?? '',
      url: playlist.url ?? '',
      parent_url: `https://www.mixcloud.com/${username}/`,
      title: playlist.name ?? '',
      caption: clean(playlist.description),
      author: playlist.owner?.username ?? username,
      datetime: playlist.created_time ?? '',
      media_type: 'playlist',
      media_url: playlist.url ?? '',
      thumbnail_url: picture(playlist.pictures),
      likes: '',
      shares: '',
      views: '',
      playlist_key: playlist.key ?? '',
      slug: playlist.slug ?? '',
      name: playlist.name ?? '',
      description: clean(playlist.description),
      cloudcast_count: playlist.cloudcast_count ?? 0,
      owner_key: playlist.owner?.key ?? '',
      owner_name: playlist.owner?.name ?? '',
      owner_username: playlist.owner?.username ?? '',
      owner_url: playlist.owner?.url ?? '',
      owner_picture: picture(playlist.owner?.pictures),
      picture: picture(playlist.pictures),
      created_time: playlist.created_time ?? '',
      updated_time: playlist.updated_time ?? '',
    })).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.mixcloud.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, pagedPath(`/${encodeURIComponent(username)}/followers/`, payload));
    return page(((data?.data ?? []) as any[]).map((entry: any) => person(username, 'followers', entry)).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.mixcloud.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await api(tab, pagedPath(`/${encodeURIComponent(username)}/following/`, payload));
    return page(((data?.data ?? []) as any[]).map((entry: any) => person(username, 'friends', entry)).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

