import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function userProjects(username: string): Promise<any[]> {
  const response = await fetch(`https://api.modrinth.com/v2/user/${encodeURIComponent(username)}/projects`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data) ? data : [];
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const all = await userProjects(username);
    if (!all.length) {
      return EMPTY;
    }

    all.sort((a: any, b: any) => Number(b?.downloads ?? 0) - Number(a?.downloads ?? 0));
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = all.slice(offset, offset + limit);

    const items = slice.map((project: any): social_resource => {
      const slug = String(project.slug ?? project.id ?? '');
      const categories = Array.isArray(project.categories) ? project.categories : [];
      return {
        type: 'projects',
        resource_id: String(project.id ?? slug),
        url: `https://modrinth.com/project/${slug}`,
        parent_url: `https://modrinth.com/user/${username}`,
        title: clean(project.title) || slug,
        caption: clean(project.description),
        author: username,
        datetime: project.updated ?? project.published ?? '',
        media_type: 'project',
        media_url: '',
        thumbnail_url: project.icon_url ?? '',
        likes: String((project.followers ?? 0) || ''),
        shares: '',
        views: String((project.downloads ?? 0) || ''),
        name: slug,
        description: clean(project.description),
        project_type: project.project_type ?? '',
        categories: categories.join(', '),
        client_side: project.client_side ?? '',
        server_side: project.server_side ?? '',
        downloads: project.downloads ?? 0,
        followers: project.followers ?? 0,
        status: project.status ?? '',
        license: typeof project.license === 'object' ? (project.license?.id ?? '') : (project.license ?? ''),
        published: project.published ?? '',
        updated: project.updated ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < all.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
