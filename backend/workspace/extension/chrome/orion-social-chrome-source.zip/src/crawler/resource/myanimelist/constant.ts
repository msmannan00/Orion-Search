import { CrawlPage } from '../../../app/extension/model/extension.model';
import { Kind } from './model';

export const KINDS: readonly Kind[] = ['anime', 'manga'];

export const PAGE = 300;

export const EMPTY: CrawlPage = { items: [] };

export const STATUS: Record<number, string> = { 1: 'watching', 2: 'completed', 3: 'on_hold', 4: 'dropped', 6: 'plan_to_watch' };
