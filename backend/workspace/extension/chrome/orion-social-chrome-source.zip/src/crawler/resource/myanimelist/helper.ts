import { social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { KINDS, STATUS } from './constant';
import { Cursor, Kind } from './model';

export function parseCursor(raw: unknown): Cursor {
  try {
    const parsed = JSON.parse(String(raw ?? '').trim() || '{}');
    const kind = KINDS.includes(parsed?.kind) ? (parsed.kind as Kind) : 'anime';
    const offset = Number(parsed?.offset);
    return { kind, offset: Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0 };
  }
  catch {
    return { kind: 'anime', offset: 0 };
  }
}

export async function list(tab: TabController, username: string, kind: Kind, offset: number): Promise<any[]> {
  try {
    const response = await tab.fetch(`https://myanimelist.net/${kind}list/${encodeURIComponent(username)}/load.json?status=7&offset=${offset}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return [];
    }
    const data = JSON.parse(response.body);
    return Array.isArray(data) ? data : [];
  }
  catch {
    return [];
  }
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function entry(username: string, kind: Kind, item: any): social_resource {
  const id = item[`${kind}_id`] ?? 0;
  const title = item[`${kind}_title`] ?? '';
  const url = item[`${kind}_url`] ? `https://myanimelist.net${item[`${kind}_url`]}` : (id ? `https://myanimelist.net/${kind}/${id}` : '');
  return {
    type: 'reviews',
    resource_id: `${kind}-${id}`,
    url,
    parent_url: `https://myanimelist.net/profile/${username}`,
    title,
    caption: `${STATUS[Number(item.status)] ?? item.status ?? ''}${item.score ? ` · score ${item.score}` : ''}`,
    author: username,
    datetime: stamp(item.updated_at),
    media_type: kind,
    media_url: url,
    thumbnail_url: item[`${kind}_image_path`] ?? '',
    likes: '',
    shares: '',
    views: '',
    media_kind: kind,
    media_id: id,
    title_text: title,
    title_english: item[`${kind}_title_eng`] ?? '',
    score: item.score ?? 0,
    status_code: item.status ?? 0,
    status: STATUS[Number(item.status)] ?? '',
    tags: item.tags ?? '',
    priority: item.priority_string ?? '',
    is_rewatching: Boolean(item.is_rewatching),
    is_rereading: Boolean(item.is_rereading),
    watched_episodes: item.num_watched_episodes ?? 0,
    read_chapters: item.num_read_chapters ?? 0,
    read_volumes: item.num_read_volumes ?? 0,
    total_episodes: item.anime_num_episodes ?? 0,
    total_chapters: item.manga_num_chapters ?? 0,
    total_volumes: item.manga_num_volumes ?? 0,
    airing_status: item.anime_airing_status ?? item.manga_publishing_status ?? 0,
    media_type_name: item[`${kind}_media_type_string`] ?? '',
    studios: Array.isArray(item.anime_studios) ? item.anime_studios.map((studio: any) => studio?.name ?? '').filter(Boolean).join(', ') : '',
    licensors: Array.isArray(item.anime_licensors) ? item.anime_licensors.map((licensor: any) => licensor?.name ?? '').filter(Boolean).join(', ') : '',
    magazines: Array.isArray(item.manga_magazines) ? item.manga_magazines.map((magazine: any) => magazine?.name ?? '').filter(Boolean).join(', ') : '',
    season: item.anime_season ? `${item.anime_season?.season ?? ''} ${item.anime_season?.year ?? ''}`.trim() : '',
    total_members: item[`${kind}_total_members`] ?? 0,
    total_scores: item[`${kind}_total_scores`] ?? 0,
    score_val: item[`${kind}_score_val`] ?? 0,
    score_diff: item[`${kind}_score_diff`] ?? 0,
    popularity: item[`${kind}_popularity`] ?? 0,
    start_date_string: item[`${kind}_start_date_string`] ?? '',
    end_date_string: item[`${kind}_end_date_string`] ?? '',
    started_at: item.start_date_string ?? '',
    finished_at: item.finish_date_string ?? '',
    days_string: item.days_string ?? '',
    storage_string: item.storage_string ?? '',
    notes: item.tags ?? '',
    image: item[`${kind}_image_path`] ?? '',
    created_at: stamp(item.created_at),
    updated_at: stamp(item.updated_at),
  };
}
