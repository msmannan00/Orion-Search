export type Kind = 'anime' | 'manga';

export interface Cursor {
  kind: Kind;
  offset: number;
}
