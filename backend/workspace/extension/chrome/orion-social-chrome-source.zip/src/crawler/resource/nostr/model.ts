export interface NostrEvent { id: string; pubkey: string; created_at: number; kind: number; content: string; tags: string[][] }
export interface NostrCursor { until: number; skip: string[] }
