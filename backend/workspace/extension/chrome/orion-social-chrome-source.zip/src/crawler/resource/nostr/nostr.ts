import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { EMPTY, MAX_SKIP } from './constant';
import { NostrCursor } from './model';
import { nevent, parseCursor, pubkeyOf, relayNotes, scrapeLastNotes, text } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').trim();
  const npub = /(npub1[02-9ac-hj-np-z]{58})/i.exec(String(payload.url ?? ''))?.[1] ?? username;
  if (!npub) {
    return EMPTY;
  }

  try {
    const cursor = parseCursor(payload);
    const limit = limitOf(payload, 25, 100);
    const pubkey = pubkeyOf(npub);
    const events = pubkey ? await relayNotes(pubkey, limit, cursor) : [];
    if (!events.length) {
      return cursor ? EMPTY : await scrapeLastNotes(npub);
    }

    const page = events.slice(0, limit);
    const items = page.map((event): social_resource => ({
      type: 'posts',
      resource_id: nevent(event),
      url: `https://njump.me/${nevent(event)}`,
      parent_url: `https://njump.me/${npub}`,
      title: '',
      caption: text(event.content),
      author: npub,
      datetime: new Date(event.created_at * 1000).toISOString(),
      media_type: 'note',
      media_url: '',
      thumbnail_url: '',
      likes: '',
      shares: '',
      views: '',
    }));

    const oldest = page[page.length - 1].created_at;
    const skip = page.filter((event) => event.created_at === oldest).map((event) => event.id);
    if (cursor?.until === oldest) {
      skip.push(...cursor.skip.filter((id) => !skip.includes(id)));
    }
    const hasMore = events.length >= limit;
    return { items, next_cursor: items.length && hasMore ? JSON.stringify({ until: oldest, skip: skip.slice(0, MAX_SKIP) } as NostrCursor) : undefined };
  }
  catch {
    return EMPTY;
  }
}
