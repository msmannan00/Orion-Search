import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function query(username: string, skip: number, take: number): Promise<any> {
  const response = await fetch(`https://azuresearch-usnc.nuget.org/query?q=owner:${encodeURIComponent(username)}&skip=${skip}&take=${take}&prerelease=true&semVerLevel=2.0.0`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function ownerTotal(username: string): Promise<number> {
  const data = await query(username, 0, 1);
  return Number(data?.totalHits ?? 0);
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const data = await query(username, offset, limit);
    const total = Number(data?.totalHits ?? 0);
    const packages: any[] = Array.isArray(data?.data) ? data.data : [];
    if (!packages.length) {
      return EMPTY;
    }

    const items = packages.map((pkg: any): social_resource => {
      const id = String(pkg.id ?? '');
      const authors = Array.isArray(pkg.authors) ? pkg.authors : (pkg.authors ? [pkg.authors] : []);
      const owners = Array.isArray(pkg.owners) ? pkg.owners : (pkg.owners ? [pkg.owners] : []);
      const tags = Array.isArray(pkg.tags) ? pkg.tags : [];
      return {
        type: 'repositories',
        resource_id: id,
        url: `https://www.nuget.org/packages/${id}`,
        parent_url: `https://www.nuget.org/profiles/${username}`,
        title: id,
        caption: clean(pkg.description ?? pkg.summary),
        author: owners.join(', ') || username,
        datetime: '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: pkg.iconUrl ?? '',
        likes: '',
        shares: '',
        views: String((pkg.totalDownloads ?? 0) || ''),
        name: id,
        version: pkg.version ?? '',
        description: clean(pkg.description ?? pkg.summary),
        title_text: clean(pkg.title),
        project_url: pkg.projectUrl ?? '',
        license: pkg.licenseUrl ?? '',
        tags: tags.join(', '),
        authors: authors.join(', '),
        owners: owners.join(', '),
        total_downloads: pkg.totalDownloads ?? 0,
        verified: Boolean(pkg.verified),
        versions_count: Array.isArray(pkg.versions) ? pkg.versions.length : 0,
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + packages.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
