import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function members(slug: string, offset: number, limit: number): Promise<any[]> {
  const response = await fetch(`https://opencollective.com/${encodeURIComponent(slug.trim())}/members/all.json?limit=${limit}&offset=${offset}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data) ? data : [];
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const slug = String(payload.username ?? '');
  if (!slug) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 100);
    const rows = await members(slug, offset, limit);
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((member: any): social_resource => {
      const name = clean(member.name);
      return {
        type: 'connections',
        resource_id: String(member.MemberId ?? member.profile ?? name),
        url: member.profile ?? (member.github ? `https://github.com/${member.github}` : `https://opencollective.com/${slug}`),
        parent_url: `https://opencollective.com/${slug}`,
        title: name || 'Anonymous',
        caption: clean(member.description),
        author: name,
        datetime: member.createdAt ?? '',
        media_type: 'member',
        media_url: '',
        thumbnail_url: member.image ?? '',
        likes: '',
        shares: '',
        views: '',
        name,
        role: member.role ?? '',
        tier: member.tier ?? '',
        company: clean(member.company),
        description: clean(member.description),
        profile: member.profile ?? '',
        github: member.github ?? '',
        twitter: member.twitter ?? '',
        website: member.website ?? '',
        total_donated: member.totalAmountDonated ?? 0,
        currency: member.currency ?? '',
        is_active: Boolean(member.isActive),
        since: member.createdAt ?? '',
        last_transaction_at: member.lastTransactionAt ?? '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length && rows.length >= limit ? String(offset + rows.length) : undefined };
  }
  catch {
    return EMPTY;
  }
}
