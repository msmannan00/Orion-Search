import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function userLists(username: string): Promise<any[]> {
  const response = await fetch(`https://openlibrary.org/people/${encodeURIComponent(username)}/lists.json`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data?.entries) ? data.entries : [];
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const all = await userLists(username);
    if (!all.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = all.slice(offset, offset + limit);

    const items = slice.map((list: any): social_resource => {
      const path = list.url ?? '';
      return {
        type: 'projects',
        resource_id: String(list.url ?? list.name ?? ''),
        url: path ? `https://openlibrary.org${path}` : `https://openlibrary.org/people/${username}/lists`,
        parent_url: `https://openlibrary.org/people/${username}/lists`,
        title: clean(list.name) || 'Untitled list',
        caption: clean(list.description),
        author: username,
        datetime: list.last_update ?? '',
        media_type: 'list',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: String((list.seeds_count ?? 0) || ''),
        name: clean(list.name),
        description: clean(list.description),
        seeds_count: list.seeds_count ?? 0,
        last_update: list.last_update ?? '',
      };
    }).filter((item) => item.url);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < all.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
