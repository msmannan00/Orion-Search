import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function queryAll(namespace: string): Promise<{ total: number; extensions: any[] }> {
  const response = await fetch(`https://open-vsx.org/api/-/query?namespaceName=${encodeURIComponent(namespace)}&size=500&offset=0`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return { total: 0, extensions: [] };
  }
  const data = await response.json();
  const raw: any[] = Array.isArray(data?.extensions) ? data.extensions : [];
  const seen = new Set<string>();
  const extensions = raw.filter((extension: any) => {
    const key = `${extension?.namespace ?? ''}.${extension?.name ?? ''}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
  return { total: extensions.length, extensions };
}

export async function namespaceTotal(namespace: string): Promise<number> {
  return (await queryAll(namespace)).total;
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const namespace = String(payload.username ?? '');
  if (!namespace) {
    return EMPTY;
  }

  try {
    const { total, extensions } = await queryAll(namespace);
    if (!extensions.length) {
      return EMPTY;
    }

    extensions.sort((a: any, b: any) => Number(b?.downloadCount ?? 0) - Number(a?.downloadCount ?? 0));
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = extensions.slice(offset, offset + limit);

    const items = slice.map((extension: any): social_resource => {
      const ns = String(extension.namespace ?? namespace);
      const name = String(extension.name ?? '');
      const files = extension.files ?? {};
      const categories = Array.isArray(extension.categories) ? extension.categories : [];
      const tags = Array.isArray(extension.tags) ? extension.tags : [];
      return {
        type: 'projects',
        resource_id: `${ns}.${name}`,
        url: `https://open-vsx.org/extension/${ns}/${name}`,
        parent_url: extension.namespaceUrl ?? `https://open-vsx.org/namespace/${ns}`,
        title: clean(extension.displayName) || name,
        caption: clean(extension.description),
        author: ns,
        datetime: extension.timestamp ?? '',
        media_type: 'extension',
        media_url: '',
        thumbnail_url: files.icon ?? '',
        likes: String((extension.reviewCount ?? 0) || ''),
        shares: '',
        views: String((extension.downloadCount ?? 0) || ''),
        name,
        display_name: clean(extension.displayName),
        description: clean(extension.description),
        namespace: ns,
        version: extension.version ?? '',
        license: extension.license ?? '',
        homepage: extension.homepage ?? '',
        repository: extension.repository ?? '',
        categories: categories.join(', '),
        tags: tags.join(', '),
        download_count: extension.downloadCount ?? 0,
        average_rating: extension.averageRating ?? 0,
        review_count: extension.reviewCount ?? 0,
        verified: Boolean(extension.verified),
        timestamp: extension.timestamp ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
