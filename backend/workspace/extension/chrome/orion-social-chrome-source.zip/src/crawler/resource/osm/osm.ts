import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

async function changesets(username: string, before: string): Promise<any[]> {
  const time = before ? `&time=2001-01-01T00:00:00Z,${encodeURIComponent(before)}` : '';
  const response = await fetch(`https://api.openstreetmap.org/api/0.6/changesets.json?display_name=${encodeURIComponent(username)}${time}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data?.changesets) ? data.changesets : [];
}

export async function userProfile(username: string): Promise<any> {
  const first = await changesets(username, '');
  if (!first.length) {
    return null;
  }
  const uid = first[0]?.uid;
  if (!uid) {
    return { first, user: null };
  }
  const response = await fetch(`https://api.openstreetmap.org/api/0.6/user/${uid}.json`, { headers: { Accept: 'application/json' } });
  const user = response.ok ? (await response.json())?.user ?? null : null;
  return { first, user };
}

export async function details(username: string): Promise<social_profile_details[]> {
  const profile = await userProfile(username);
  if (!profile) {
    return [];
  }

  const user = profile.user ?? {};
  const count = user.changesets?.count ?? profile.first.length;
  return [{
    real_name: user.display_name ?? username,
    bio: clean(user.description),
    description: clean(user.description),
    location: '',
    profile_url: `https://www.openstreetmap.org/user/${encodeURIComponent(user.display_name ?? username)}`,
    total_posts: String(count || ''),
    total_followers: '',
    total_likes: '',
    avatar: user.img?.href ?? '',
    banner: '',
    crawl_type: ['details', 'posts'],
    platform: 'osm',
    username: user.display_name ?? username,
    changesets_count: count,
    traces_count: user.traces?.count ?? 0,
    account_created: user.account_created ?? '',
  }];
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const cursor = String(payload.cursor ?? '').trim();
    const rows = await changesets(username, cursor);
    if (!rows.length) {
      return EMPTY;
    }

    const limit = limitOf(payload, 25, 100);
    const slice = rows.slice(0, limit);

    const items = slice.map((changeset: any): social_resource => {
      const id = String(changeset.id ?? '');
      const tags = changeset.tags ?? {};
      const comment = clean(tags.comment) || `Changeset ${id}`;
      return {
        type: 'posts',
        resource_id: id,
        url: `https://www.openstreetmap.org/changeset/${id}`,
        parent_url: `https://www.openstreetmap.org/user/${encodeURIComponent(changeset.user ?? username)}`,
        title: comment,
        caption: comment,
        author: changeset.user ?? username,
        datetime: changeset.closed_at ?? changeset.created_at ?? '',
        media_type: 'changeset',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        content: comment,
        changes_count: changeset.changes_count ?? 0,
        comments_count: changeset.comments_count ?? 0,
        created_at: changeset.created_at ?? '',
        closed_at: changeset.closed_at ?? '',
        open: Boolean(changeset.open),
        created_by: clean(tags.created_by),
        imagery_used: clean(tags.imagery_used),
        source: clean(tags.source),
        bbox: [changeset.min_lon, changeset.min_lat, changeset.max_lon, changeset.max_lat].filter((value) => value != null).join(', '),
      };
    }).filter((item) => item.url);

    const oldest = slice[slice.length - 1]?.created_at;
    let nextCursor: string | undefined;
    if (rows.length >= 100 && oldest) {
      const parsed = Date.parse(oldest);
      nextCursor = Number.isFinite(parsed) ? new Date(parsed - 1000).toISOString() : undefined;
    }
    return { items, next_cursor: nextCursor };
  }
  catch {
    return EMPTY;
  }
}
