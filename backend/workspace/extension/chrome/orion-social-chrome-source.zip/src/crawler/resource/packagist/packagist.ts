import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function vendorPackages(username: string): Promise<string[]> {
  const response = await fetch(`https://packagist.org/packages/list.json?vendor=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data?.packageNames) ? data.packageNames : [];
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const names = await vendorPackages(username);
    if (!names.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 40);
    const slice = names.slice(offset, offset + limit);
    const docs = await Promise.all(slice.map((name) => fetch(`https://packagist.org/packages/${name}.json`, { headers: { Accept: 'application/json' } })
      .then((response) => response.ok ? response.json() : null)
      .catch(() => null)));

    const items = slice.map((name: string, index: number): social_resource => {
      const pkg: any = docs[index]?.package ?? {};
      const versions = pkg.versions ?? {};
      const stableKey = Object.keys(versions).find((key) => !/dev|alpha|beta|-rc/i.test(key)) ?? Object.keys(versions)[0] ?? '';
      const version: any = versions[stableKey] ?? {};
      const downloads = pkg.downloads ?? {};
      return {
        type: 'repositories',
        resource_id: name,
        url: `https://packagist.org/packages/${name}`,
        parent_url: `https://packagist.org/packages/${username}/`,
        title: name,
        caption: clean(pkg.description ?? version.description),
        author: username,
        datetime: version.time ?? '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: String((pkg.favers ?? 0) || ''),
        shares: '',
        views: String((downloads.total ?? 0) || ''),
        name,
        description: clean(pkg.description),
        repository: pkg.repository ?? '',
        language: pkg.language ?? '',
        package_type: pkg.type ?? '',
        latest_version: stableKey,
        license: Array.isArray(version.license) ? version.license.join(', ') : '',
        keywords: Array.isArray(version.keywords) ? version.keywords.join(', ') : '',
        downloads_total: downloads.total ?? 0,
        downloads_monthly: downloads.monthly ?? 0,
        downloads_daily: downloads.daily ?? 0,
        favers: pkg.favers ?? 0,
        github_stars: pkg.github_stars ?? 0,
        github_forks: pkg.github_forks ?? 0,
        github_watchers: pkg.github_watchers ?? 0,
        github_open_issues: pkg.github_open_issues ?? 0,
        dependents: pkg.dependents ?? 0,
        suggesters: pkg.suggesters ?? 0,
        maintainers: Array.isArray(pkg.maintainers) ? pkg.maintainers.map((maintainer: any) => maintainer?.name ?? '').filter(Boolean).join(', ') : '',
        homepage: version.homepage ?? '',
        time: version.time ?? '',
      };
    }).filter((item) => item.url);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < names.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
