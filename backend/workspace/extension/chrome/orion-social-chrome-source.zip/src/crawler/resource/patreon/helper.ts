import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { PostsCursor } from './model';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

export async function campaignId(tab: TabController, username: string): Promise<string> {
  try {
    const response = await tab.fetch(`https://www.patreon.com/${encodeURIComponent(username)}`);
    if (!response.ok) {
      return '';
    }
    const html = response.body;
    return /"campaign":\{"data":\{"id":"(\d+)"/.exec(html)?.[1] ?? /campaign_id["']?\s*[:=]\s*["']?(\d+)/.exec(html)?.[1] ?? '';
  }
  catch {
    return '';
  }
}

export function parsePostsCursor(payload: CrawlPayload): PostsCursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { campaign: '', cursor: '' };
  }
  try {
    const parsed: any = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return { campaign: String(parsed.campaign ?? '').trim(), cursor: String(parsed.cursor ?? '').trim() };
    }
  }
  catch {
  }
  return { campaign: '', cursor: raw };
}

export function nextPostsCursor(data: any): string {
  const metaCursor = String(data?.meta?.pagination?.cursors?.next ?? '').trim();
  if (metaCursor) {
    return metaCursor;
  }
  const next = String(data?.links?.next ?? '').trim();
  if (!next) {
    return '';
  }
  const match = /[?&]page(?:%5B|\[)cursor(?:%5D|\])=([^&#]+)/i.exec(next);
  if (!match) {
    return '';
  }
  try {
    return decodeURIComponent(match[1]).trim();
  }
  catch {
    return match[1].trim();
  }
}
