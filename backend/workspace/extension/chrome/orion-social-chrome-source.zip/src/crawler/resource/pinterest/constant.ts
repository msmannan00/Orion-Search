import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };
export const END = '-end-';
export const PAGE_SIZE = 25;
export const MAX_PAGE_SIZE = 50;
export const MAX_UPSTREAM_PAGES = 4;
