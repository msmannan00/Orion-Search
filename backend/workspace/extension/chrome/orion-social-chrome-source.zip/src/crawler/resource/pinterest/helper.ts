import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, END, MAX_PAGE_SIZE, MAX_UPSTREAM_PAGES, PAGE_SIZE } from './constant';
import { PinBatch } from './model';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function cursorOf(payload: CrawlPayload): string {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return '';
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return String(parsed.bookmark ?? '').trim();
    }
    return String(parsed ?? '').trim();
  }
  catch {
    return raw;
  }
}

export function nextBookmark(bookmark: string, previous: string): string {
  const value = String(bookmark ?? '').trim();
  if (!value || value === END || value === previous) {
    return '';
  }
  return value;
}

export function bookmarkFromState(state: any): string {
  try {
    const resources = state?.resources ?? {};
    for (const key of ['UserActivityPinsResource', 'UserPinsResource']) {
      const entries = Object.values(resources?.[key] ?? {}) as any[];
      for (const entry of entries) {
        const found = String(entry?.nextBookmark ?? entry?.bookmark ?? '').trim();
        if (found && found !== END) {
          return found;
        }
      }
    }
  }
  catch {
  }
  return '';
}

export async function store(tab: TabController, username: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.pinterest.com/${encodeURIComponent(username)}/`);
    if (!response.ok) {
      return null;
    }

    const html = response.body;
    const raw = /<script id="__PWS_INITIAL_PROPS__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1]
      ?? /<script id="__PWS_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1] ?? '';
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw);
    return parsed?.initialReduxState ?? parsed?.props?.initialReduxState ?? null;
  }
  catch {
    return null;
  }
}

export async function resource(tab: TabController, name: string, username: string, pageSize: number, bookmark: string): Promise<any> {
  try {
    const options: Record<string, unknown> = { username, page_size: pageSize, field_set_key: 'grid_item', is_own_profile_pins: false };
    if (bookmark) {
      options['bookmarks'] = [bookmark];
    }
    const data = encodeURIComponent(JSON.stringify({ options, context: {} }));
    const sourceUrl = encodeURIComponent(`/${username}/`);
    const response = await tab.fetch(`https://www.pinterest.com/resource/${name}/get/?source_url=${sourceUrl}&data=${data}&_=${Date.now()}`, {
      headers: { Accept: 'application/json, text/javascript, */*, q=0.01', 'X-Requested-With': 'XMLHttpRequest', 'X-Pinterest-PWS-Handler': 'www/[username].js' },
    });
    if (!response.ok) {
      return null;
    }
    const json = JSON.parse(response.body);
    return json?.resource_response ?? null;
  }
  catch {
    return null;
  }
}

export async function batch(tab: TabController, username: string, pageSize: number, bookmark: string): Promise<PinBatch | null> {
  for (const name of ['UserActivityPinsResource', 'UserPinsResource']) {
    const data = await resource(tab, name, username, pageSize, bookmark);
    const list = Array.isArray(data?.data) ? data.data : Array.isArray(data?.data?.results) ? data.data.results : null;
    if (list) {
      return { pins: list, boards: {}, bookmark: nextBookmark(String(data?.bookmark ?? ''), bookmark) };
    }
  }

  if (bookmark) {
    return null;
  }

  const state = await store(tab, username);
  if (!state) {
    return null;
  }
  return { pins: Object.values(state?.pins ?? {}) as any[], boards: state?.boards ?? {}, bookmark: nextBookmark(bookmarkFromState(state), bookmark) };
}

export function image(images: any, key: string): string {
  return images?.[key]?.url ?? '';
}

export function toResource(username: string, boards: Record<string, any>, pin: any): social_resource {
  const images = pin.images ?? {};
  const video = pin.videos?.video_list ?? {};
  const best = video.V_720P ?? video.V_HLSV4 ?? video.V_HLSV3_MOBILE ?? {};
  const board = boards[String(pin.board?.id ?? '')] ?? pin.board ?? {};
  const rich = pin.rich_metadata ?? {};
  return {
    type: 'pins',
    resource_id: String(pin.id ?? ''),
    url: pin.id ? `https://www.pinterest.com/pin/${pin.id}/` : '',
    parent_url: `https://www.pinterest.com/${username}/`,
    title: clean(pin.grid_title ?? pin.title ?? rich.title),
    caption: clean(pin.description ?? pin.auto_alt_text ?? pin.alt_text ?? rich.description),
    author: pin.pinner?.username ?? username,
    datetime: pin.created_at ?? '',
    media_type: pin.videos ? 'video' : 'image',
    media_url: best.url ?? image(images, 'orig') ?? '',
    thumbnail_url: image(images, '736x') || image(images, '474x') || image(images, '236x'),
    likes: String((pin.favorite_user_count ?? pin.aggregated_pin_data?.aggregated_stats?.saves ?? 0) || ''),
    shares: String((pin.repin_count ?? 0) || ''),
    views: '',
    pin_id: pin.id ?? '',
    node_id: pin.node_id ?? '',
    pin_type: pin.type ?? '',
    grid_title: clean(pin.grid_title),
    title_text: clean(pin.title),
    description: clean(pin.description),
    alt_text: clean(pin.alt_text ?? pin.auto_alt_text ?? pin.seo_alt_text),
    link: pin.link ?? '',
    link_domain: pin.link ? String(pin.link).replace(/^https?:\/\//, '').split('/')[0] : '',
    dominant_color: pin.dominant_color ?? '',
    image_signature: pin.image_signature ?? '',
    image_236: image(images, '236x'),
    image_474: image(images, '474x'),
    image_736: image(images, '736x'),
    image_orig: image(images, 'orig'),
    image_width: images.orig?.width ?? 0,
    image_height: images.orig?.height ?? 0,
    is_video: Boolean(pin.videos),
    video_id: pin.videos?.id ?? '',
    video_url: best.url ?? '',
    video_duration: pin.videos?.duration ?? best.duration ?? 0,
    video_thumbnail: best.thumbnail ?? '',
    video_width: best.width ?? 0,
    video_height: best.height ?? 0,
    repin_count: pin.repin_count ?? 0,
    favorite_count: pin.favorite_user_count ?? 0,
    comment_count: pin.comment_count ?? 0,
    reaction_count: pin.reaction_counts ? Object.values(pin.reaction_counts).reduce((sum: number, value: any) => sum + (Number(value) || 0), 0) : 0,
    is_promoted: pin.is_promoted ?? false,
    is_native: pin.is_native ?? false,
    is_repin: pin.is_repin ?? false,
    is_eligible_for_related: pin.is_eligible_for_related_products ?? false,
    board_id: board.id ?? '',
    board_name: board.name ?? '',
    board_url: board.url ? `https://www.pinterest.com${board.url}` : '',
    board_pin_count: board.pin_count ?? 0,
    board_follower_count: board.follower_count ?? 0,
    pinner_username: pin.pinner?.username ?? '',
    pinner_full_name: pin.pinner?.full_name ?? '',
    pinner_id: pin.pinner?.id ?? '',
    pinner_image: pin.pinner?.image_medium_url ?? '',
    pinner_followers: pin.pinner?.follower_count ?? 0,
    rich_title: clean(rich.title),
    rich_description: clean(rich.description),
    rich_site_name: rich.site_name ?? '',
    rich_favicon: rich.favicon_images?.orig ?? '',
    created_at: pin.created_at ?? '',
  };
}

export function page(items: social_resource[], bookmark: string): CrawlPage {
  return { items, next_cursor: items.length && bookmark ? JSON.stringify({ bookmark }) : undefined };
}

export async function collect(payload: CrawlPayload, keep: (item: social_resource) => boolean): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.pinterest.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, PAGE_SIZE, MAX_PAGE_SIZE);
    let bookmark = cursorOf(payload);
    const items: social_resource[] = [];
    for (let round = 0; round < MAX_UPSTREAM_PAGES; round += 1) {
      const result = await batch(tab, username, limit, bookmark);
      if (!result) {
        break;
      }
      items.push(...result.pins.map((pin: any) => toResource(username, result.boards, pin)).filter((item) => item.url && keep(item)));
      bookmark = result.bookmark;
      if (!bookmark || items.length >= limit) {
        break;
      }
    }
    return page(items, bookmark);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
