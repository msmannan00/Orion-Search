export interface PinBatch {
  pins: any[];
  boards: Record<string, any>;
  bookmark: string;
}
