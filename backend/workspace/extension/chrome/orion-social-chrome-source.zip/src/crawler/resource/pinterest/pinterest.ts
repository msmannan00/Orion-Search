import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { EMPTY } from './constant';
import { collect } from './helper';

export async function pins(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    return await collect(payload, () => true);
  }
  catch {
    return EMPTY;
  }
}

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const result = await collect(payload, (item) => !item['is_video']);
    return { ...result, items: result.items.map((item) => ({ ...item, type: 'images' as const })) };
  }
  catch {
    return EMPTY;
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const result = await collect(payload, (item) => Boolean(item['is_video']));
    return { ...result, items: result.items.map((item) => ({ ...item, type: 'videos' as const })) };
  }
  catch {
    return EMPTY;
  }
}
