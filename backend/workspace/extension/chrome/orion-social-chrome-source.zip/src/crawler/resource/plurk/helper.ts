import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { OWNER_FIELDS } from './constant';
import { PostsCursor } from './model';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

export function base36(id: number): string {
  return Number(id).toString(36);
}

export function parseJs(raw: string): any {
  try {
    return JSON.parse(raw.replace(/new Date\((".*?")\)/g, '$1'));
  }
  catch {
    return null;
  }
}

export function balancedObject(source: string, start: number): string {
  if (start < 0 || source[start] !== '{') {
    return '';
  }

  let depth = 0;
  let quoted = false;
  for (let index = start; index < source.length; index++) {
    const char = source[index];
    if (quoted) {
      if (char === '\\') {
        index++;
      }
      else if (char === '"') {
        quoted = false;
      }
      continue;
    }
    if (char === '"') {
      quoted = true;
    }
    else if (char === '{') {
      depth++;
    }
    else if (char === '}') {
      depth--;
      if (depth === 0) {
        return source.slice(start, index + 1);
      }
    }
  }
  return '';
}

export function isoOf(posted: unknown): string {
  const time = new Date(String(posted ?? '')).getTime();
  return Number.isFinite(time) ? new Date(time).toISOString() : '';
}

export function ownerSnapshot(owner: any): Record<string, unknown> | undefined {
  if (!owner || typeof owner !== 'object') {
    return undefined;
  }

  const snapshot: Record<string, unknown> = {};
  for (const field of OWNER_FIELDS) {
    if (owner[field] !== undefined && owner[field] !== null) {
      snapshot[field] = owner[field];
    }
  }
  return Object.keys(snapshot).length ? snapshot : undefined;
}

export function parseCursor(payload: CrawlPayload): PostsCursor | null {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return null;
  }

  try {
    const parsed = JSON.parse(raw);
    const userId = Number(parsed?.user_id);
    const offset = isoOf(parsed?.offset);
    if (!Number.isFinite(userId) || userId <= 0 || !offset) {
      return null;
    }
    return { user_id: userId, offset, owner: ownerSnapshot(parsed?.owner) };
  }
  catch {
    return null;
  }
}

export async function profilePage(tab: TabController, username: string): Promise<{ plurks: any[]; owners: Record<string, any>; userId: number } | null> {
  const response = await tab.fetch(`https://www.plurk.com/${encodeURIComponent(username)}`);
  if (!response.ok) {
    return null;
  }

  const html = response.body;
  const raw = /PUBLIC_PLURKS\s*=\s*(\[[\s\S]*?\]);/.exec(html)?.[1];
  if (!raw) {
    return null;
  }

  const plurks = parseJs(raw);
  if (!Array.isArray(plurks)) {
    return null;
  }

  const users = /plurk_users\s*=\s*(\{[\s\S]*?\});/.exec(html)?.[1] ?? '';
  const owners: Record<string, any> = (users && parseJs(users)) || {};

  const pageUserAt = /"page_user"\s*:\s*\{/.exec(html);
  const pageUser = pageUserAt ? parseJs(balancedObject(html, pageUserAt.index + pageUserAt[0].length - 1)) : null;
  const userId = Number(pageUser?.id ?? plurks.find((plurk: any) => plurk?.owner_id)?.owner_id ?? plurks.find((plurk: any) => plurk?.user_id)?.user_id ?? 0) || 0;
  if (userId && pageUser && !owners[String(userId)]) {
    owners[String(userId)] = pageUser;
  }

  return { plurks, owners, userId };
}

export async function timelinePage(tab: TabController, userId: number, offset: string): Promise<any[] | null> {
  const body = new URLSearchParams({ user_id: String(userId), offset });
  const response = await tab.fetch('https://www.plurk.com/TimeLine/getPlurks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' },
    body: body.toString(),
  });
  if (!response.ok) {
    return null;
  }

  const data = parseJs(response.body);
  return Array.isArray(data?.plurks) ? data.plurks : null;
}

export function toResource(plurk: any, owners: Record<string, any>, username: string): social_resource {
  const owner = owners[String(plurk.owner_id ?? plurk.user_id ?? '')] ?? {};
  const images = [...String(plurk.content ?? '').matchAll(/<img[^>]+src="([^"]+)"/g)].map((match) => match[1]).filter((url: string) => !/emos\.plurk\.com/.test(url));
  const links = [...String(plurk.content ?? '').matchAll(/<a[^>]+href="([^"]+)"/g)].map((match) => match[1]);
  return {
    type: 'posts',
    resource_id: String(plurk.plurk_id ?? plurk.id ?? ''),
    url: `https://www.plurk.com/p/${base36(plurk.plurk_id ?? plurk.id ?? 0)}`,
    parent_url: `https://www.plurk.com/${username}`,
    title: '',
    caption: clean(plurk.content_raw ?? plurk.content),
    author: owner.nick_name ?? username,
    datetime: plurk.posted ?? '',
    media_type: plurk.with_video ? 'video' : images.length ? 'image' : 'text',
    media_url: images[0] ?? '',
    thumbnail_url: images[0] ?? '',
    likes: String((plurk.favorite_count ?? 0) || ''),
    shares: String((plurk.replurkers_count ?? 0) || ''),
    views: '',
    plurk_id: plurk.plurk_id ?? plurk.id ?? 0,
    plurk_base36: base36(plurk.plurk_id ?? plurk.id ?? 0),
    user_id: plurk.user_id ?? 0,
    owner_id: plurk.owner_id ?? 0,
    qualifier: plurk.qualifier ?? '',
    content_text: clean(plurk.content_raw ?? plurk.content),
    content_length: clean(plurk.content_raw ?? plurk.content).length,
    content_html: String(plurk.content ?? '').slice(0, 3000),
    language: plurk.lang ?? '',
    plurk_type: plurk.plurk_type ?? 0,
    response_count: plurk.response_count ?? 0,
    responses_seen: plurk.responses_seen ?? 0,
    favorite_count: plurk.favorite_count ?? 0,
    replurkers_count: plurk.replurkers_count ?? 0,
    is_replurked: plurk.replurked ?? false,
    is_replurkable: plurk.replurkable ?? false,
    replurker_id: plurk.replurker_id ?? 0,
    coins: plurk.coins ?? 0,
    has_gift: plurk.has_gift ?? false,
    is_porn: plurk.porn ?? false,
    no_comments: plurk.no_comments ?? 0,
    limited_to: plurk.limited_to ?? '',
    is_anonymous: plurk.anonymous ?? false,
    with_poll: plurk.with_poll ?? false,
    with_video: plurk.with_video ?? false,
    publish_to_followers: plurk.publish_to_followers ?? false,
    reaction_permission: plurk.reaction_permission ?? 0,
    images_count: images.length,
    image_urls: images.slice(0, 20).join(', '),
    links: [...new Set(links)].slice(0, 20).join(', '),
    favorers_count: Array.isArray(plurk.favorers) ? plurk.favorers.length : 0,
    owner_nick: owner.nick_name ?? '',
    owner_display_name: owner.display_name ?? '',
    owner_full_name: owner.full_name ?? '',
    owner_location: owner.location ?? '',
    owner_timezone: owner.timezone ?? '',
    owner_karma: owner.karma ?? 0,
    owner_verified: owner.verified_account ?? false,
    owner_gender: owner.gender ?? 0,
    owner_relationship: owner.relationship ?? '',
    last_edited: plurk.last_edited ?? '',
    posted_at: plurk.posted ?? '',
  };
}
