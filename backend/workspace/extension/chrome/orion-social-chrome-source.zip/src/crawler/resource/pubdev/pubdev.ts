import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

async function search(publisher: string, page: number): Promise<{ names: string[]; hasNext: boolean }> {
  const response = await fetch(`https://pub.dev/api/search?q=publisher:${encodeURIComponent(publisher)}&page=${page}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return { names: [], hasNext: false };
  }
  const data = await response.json();
  const names = Array.isArray(data?.packages) ? data.packages.map((entry: any) => String(entry?.package ?? '')).filter(Boolean) : [];
  return { names, hasNext: Boolean(data?.next) };
}

export async function packageCount(publisher: string): Promise<number> {
  return (await search(publisher, 1)).names.length;
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const publisher = String(payload.username ?? '');
  if (!publisher) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const { names, hasNext } = await search(publisher, page);
    if (!names.length) {
      return EMPTY;
    }

    const docs = await Promise.all(names.map((name) => fetch(`https://pub.dev/api/packages/${encodeURIComponent(name)}`, { headers: { Accept: 'application/json' } })
      .then((response) => response.ok ? response.json() : null)
      .catch(() => null)));

    const items = names.map((name: string, index: number): social_resource => {
      const doc: any = docs[index] ?? {};
      const latest = doc.latest ?? {};
      const pubspec = latest.pubspec ?? {};
      return {
        type: 'repositories',
        resource_id: name,
        url: `https://pub.dev/packages/${name}`,
        parent_url: `https://pub.dev/publishers/${publisher}/packages`,
        title: name,
        caption: clean(pubspec.description),
        author: publisher,
        datetime: latest.published ?? '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        name,
        description: clean(pubspec.description),
        version: latest.version ?? '',
        homepage: pubspec.homepage ?? '',
        repository: pubspec.repository ?? '',
        documentation: pubspec.documentation ?? '',
        issue_tracker: pubspec.issue_tracker ?? '',
        environment_sdk: pubspec.environment?.sdk ?? '',
        published: latest.published ?? '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length && hasNext ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
