import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { NO_LISTING } from './constant';
import { Listing } from './model';

export async function listing(tab: TabController, username: string, kind: string, payload: CrawlPayload): Promise<Listing> {
  try {
    const after = String(payload.cursor ?? '').trim();
    const query = `limit=${limitOf(payload, 25, 100)}&raw_json=1${after ? `&after=${encodeURIComponent(after)}` : ''}`;
    const response = await tab.fetch(`https://www.reddit.com/user/${encodeURIComponent(username)}/${kind}.json?${query}`, {
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) {
      return NO_LISTING;
    }
    const data = JSON.parse(response.body);
    const children = Array.isArray(data?.data?.children) ? data.data.children : [];
    return {
      items: children.map((child: any) => child?.data).filter(Boolean),
      after: String(data?.data?.after ?? '').trim(),
    };
  }
  catch {
    return NO_LISTING;
  }
}

export function page(items: social_resource[], source: Listing, payload: CrawlPayload): CrawlPage {
  const previous = String(payload.cursor ?? '').trim();
  const next = source.after;
  return { items, next_cursor: items.length && next && next !== previous ? next : undefined };
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}
