import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { clean, listing, page, stamp } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.reddit.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const source = await listing(tab, username, 'submitted', payload);
    return page(source.items.map((post: any): social_resource => {
      const gallery: any[] = post.gallery_data?.items ?? [];
      const preview = post.preview?.images?.[0]?.source?.url ?? '';
      return {
        type: 'posts',
        resource_id: post.id ?? '',
        url: post.permalink ? `https://www.reddit.com${post.permalink}` : (post.url ?? ''),
        parent_url: `https://www.reddit.com/user/${username}`,
        title: clean(post.title),
        caption: clean(post.selftext).slice(0, 4000),
        author: post.author ?? username,
        datetime: stamp(post.created_utc),
        media_type: post.post_hint ?? (post.is_self ? 'text' : post.is_video ? 'video' : post.is_gallery ? 'gallery' : 'link'),
        media_url: post.url_overridden_by_dest ?? post.url ?? '',
        thumbnail_url: String(post.thumbnail ?? '').startsWith('http') ? post.thumbnail : preview,
        likes: String((post.score ?? 0) || ''),
        shares: String((post.num_crossposts ?? 0) || ''),
        views: String((post.view_count ?? 0) || ''),
        post_id: post.id ?? '',
        fullname: post.name ?? '',
        permalink: post.permalink ? `https://www.reddit.com${post.permalink}` : '',
        title_text: clean(post.title),
        selftext: clean(post.selftext).slice(0, 8000),
        selftext_length: String(post.selftext ?? '').length,
        subreddit: post.subreddit ?? '',
        subreddit_id: post.subreddit_id ?? '',
        subreddit_prefixed: post.subreddit_name_prefixed ?? '',
        subreddit_subscribers: post.subreddit_subscribers ?? 0,
        subreddit_type: post.subreddit_type ?? '',
        author_name: post.author ?? '',
        author_fullname: post.author_fullname ?? '',
        author_flair: clean(post.author_flair_text),
        author_premium: post.author_premium ?? false,
        author_patreon_flair: post.author_patreon_flair ?? false,
        score: post.score ?? 0,
        ups: post.ups ?? 0,
        downs: post.downs ?? 0,
        upvote_ratio: post.upvote_ratio ?? 0,
        num_comments: post.num_comments ?? 0,
        num_crossposts: post.num_crossposts ?? 0,
        total_awards: post.total_awards_received ?? 0,
        gilded: post.gilded ?? 0,
        view_count: post.view_count ?? 0,
        is_self: post.is_self ?? false,
        is_video: post.is_video ?? false,
        is_gallery: post.is_gallery ?? false,
        is_original_content: post.is_original_content ?? false,
        is_meta: post.is_meta ?? false,
        is_crosspostable: post.is_crosspostable ?? false,
        is_reddit_media_domain: post.is_reddit_media_domain ?? false,
        over_18: post.over_18 ?? false,
        spoiler: post.spoiler ?? false,
        locked: post.locked ?? false,
        stickied: post.stickied ?? false,
        archived: post.archived ?? false,
        quarantine: post.quarantine ?? false,
        hidden: post.hidden ?? false,
        pinned: post.pinned ?? false,
        distinguished: post.distinguished ?? '',
        link_flair_text: clean(post.link_flair_text),
        link_flair_type: post.link_flair_type ?? '',
        domain: post.domain ?? '',
        external_url: post.url_overridden_by_dest ?? '',
        post_hint: post.post_hint ?? '',
        thumbnail: String(post.thumbnail ?? '').startsWith('http') ? post.thumbnail : '',
        thumbnail_width: post.thumbnail_width ?? 0,
        thumbnail_height: post.thumbnail_height ?? 0,
        preview_image: preview,
        gallery_count: gallery.length,
        gallery_ids: gallery.map((entry: any) => entry?.media_id ?? '').filter(Boolean).join(', '),
        video_url: post.media?.reddit_video?.fallback_url ?? post.secure_media?.reddit_video?.fallback_url ?? '',
        video_duration: post.media?.reddit_video?.duration ?? 0,
        media_provider: post.media?.type ?? post.secure_media?.type ?? '',
        oembed_title: clean(post.media?.oembed?.title ?? post.secure_media?.oembed?.title),
        crosspost_parent: post.crosspost_parent ?? '',
        removed_by_category: post.removed_by_category ?? '',
        suggested_sort: post.suggested_sort ?? '',
        created_at: stamp(post.created_utc),
        edited_at: typeof post.edited === 'number' ? stamp(post.edited) : '',
      };
    }).filter((item) => item.url), source, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.reddit.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const source = await listing(tab, username, 'comments', payload);
    return page(source.items.map((comment: any): social_resource => ({
      type: 'comments',
      resource_id: comment.id ?? '',
      url: comment.permalink ? `https://www.reddit.com${comment.permalink}` : '',
      parent_url: `https://www.reddit.com/user/${username}`,
      title: clean(comment.link_title),
      caption: clean(comment.body).slice(0, 4000),
      author: comment.author ?? username,
      datetime: stamp(comment.created_utc),
      media_type: 'comment',
      media_url: comment.link_url ?? '',
      thumbnail_url: '',
      likes: String((comment.score ?? 0) || ''),
      shares: '',
      views: '',
      comment_id: comment.id ?? '',
      fullname: comment.name ?? '',
      permalink: comment.permalink ? `https://www.reddit.com${comment.permalink}` : '',
      body: clean(comment.body).slice(0, 8000),
      body_length: String(comment.body ?? '').length,
      link_id: comment.link_id ?? '',
      link_title: clean(comment.link_title),
      link_url: comment.link_url ?? '',
      link_author: comment.link_author ?? '',
      parent_id: comment.parent_id ?? '',
      is_top_level: String(comment.parent_id ?? '').startsWith('t3_'),
      subreddit: comment.subreddit ?? '',
      subreddit_id: comment.subreddit_id ?? '',
      subreddit_prefixed: comment.subreddit_name_prefixed ?? '',
      subreddit_type: comment.subreddit_type ?? '',
      author_name: comment.author ?? '',
      author_fullname: comment.author_fullname ?? '',
      author_flair: clean(comment.author_flair_text),
      author_premium: comment.author_premium ?? false,
      score: comment.score ?? 0,
      ups: comment.ups ?? 0,
      downs: comment.downs ?? 0,
      controversiality: comment.controversiality ?? 0,
      total_awards: comment.total_awards_received ?? 0,
      gilded: comment.gilded ?? 0,
      is_submitter: comment.is_submitter ?? false,
      score_hidden: comment.score_hidden ?? false,
      stickied: comment.stickied ?? false,
      locked: comment.locked ?? false,
      archived: comment.archived ?? false,
      over_18: comment.over_18 ?? false,
      distinguished: comment.distinguished ?? '',
      num_comments: comment.num_comments ?? 0,
      depth: comment.depth ?? 0,
      collapsed: comment.collapsed ?? false,
      collapsed_reason: comment.collapsed_reason_code ?? '',
      created_at: stamp(comment.created_utc),
      edited_at: typeof comment.edited === 'number' ? stamp(comment.edited) : '',
    })).filter((item) => item.url), source, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.reddit.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const response = await tab.fetch(`https://www.reddit.com/user/${encodeURIComponent(username)}/moderated_subreddits.json?raw_json=1`, {
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) {
      return EMPTY;
    }

    const data = JSON.parse(response.body);
    const list = (Array.isArray(data?.data) ? data.data : []) as any[];
    const items = list.map((entry: any): social_resource => ({
      type: 'organizations',
      resource_id: entry.name ?? entry.sr ?? '',
      url: entry.url ? `https://www.reddit.com${entry.url}` : '',
      parent_url: `https://www.reddit.com/user/${username}`,
      title: entry.sr_display_name_prefixed ?? entry.sr ?? '',
      caption: clean(entry.community_description ?? entry.public_description),
      author: username,
      datetime: '',
      media_type: 'subreddit',
      media_url: entry.url ? `https://www.reddit.com${entry.url}` : '',
      thumbnail_url: entry.community_icon ?? entry.icon_img ?? '',
      likes: '',
      shares: String((entry.subscribers ?? 0) || ''),
      views: '',
      subreddit_name: entry.sr ?? '',
      subreddit_fullname: entry.name ?? '',
      display_name: entry.sr_display_name_prefixed ?? '',
      subscribers: entry.subscribers ?? 0,
      description: clean(entry.community_description ?? entry.public_description),
      subreddit_type: entry.subreddit_type ?? '',
      is_nsfw: entry.over_18 ?? entry.over18 ?? false,
      community_icon: entry.community_icon ?? '',
      icon_img: entry.icon_img ?? '',
      banner_img: entry.banner_img ?? '',
      key_color: entry.key_color ?? '',
      primary_color: entry.primary_color ?? '',
      mod_permissions: Array.isArray(entry.mod_permissions) ? entry.mod_permissions.join(', ') : '',
      subreddit_url: entry.url ? `https://www.reddit.com${entry.url}` : '',
    })).filter((item) => item.url);
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const postUrl = String(payload.url ?? '');
  const named = /\/comments\/([a-z0-9]+)/i.exec(postUrl)?.[1] ?? '';
  const username = String(payload.username ?? '');
  if (!named && !username) {
    return EMPTY;
  }
  const tab = await openSession('https://www.reddit.com/');
  if (!tab) {
    return EMPTY;
  }
  try {
    // What gets tracked is a profile, so a post to read commenters from has to be
    // found rather than assumed: the newest submission stands in when the crawl
    // was given a profile instead of a permalink.
    let id = named;
    if (!id) {
      const source = await listing(tab, username, 'submitted', payload);
      id = String(source.items.find((post: any) => post?.id)?.id ?? '');
    }
    if (!id) {
      return EMPTY;
    }
    const response = await tab.fetch(`https://www.reddit.com/comments/${id}.json?limit=100&raw_json=1`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }
    const data = JSON.parse(response.body);
    const children: any[] = Array.isArray(data?.[1]?.data?.children) ? data[1].data.children : [];
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const child of children) {
      if (child?.kind !== 't1') {
        continue;
      }
      const comment = child.data ?? {};
      const author = String(comment.author ?? '');
      if (!author || author === '[deleted]' || seen.has(author)) {
        continue;
      }
      seen.add(author);
      items.push({
        type: 'connections',
        resource_id: author,
        url: `https://www.reddit.com/user/${encodeURIComponent(author)}`,
        parent_url: postUrl || `https://www.reddit.com/comments/${id}`,
        title: author,
        caption: clean(comment.body).slice(0, 600),
        author,
        datetime: stamp(comment.created_utc),
        media_type: 'user',
        media_url: `https://www.reddit.com/user/${encodeURIComponent(author)}`,
        thumbnail_url: '',
        likes: String((comment.score ?? 0) || ''),
        shares: '',
        views: '',
        handle: author,
        comment_id: comment.id ?? '',
        comment_text: clean(comment.body),
        comment_url: comment.permalink ? `https://www.reddit.com${comment.permalink}` : '',
        comment_at: stamp(comment.created_utc),
        author_flair: clean(comment.author_flair_text),
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
