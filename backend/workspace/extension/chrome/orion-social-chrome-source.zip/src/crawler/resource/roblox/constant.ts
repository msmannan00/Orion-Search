import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const GAME_PAGE_SIZES = [10, 25, 50];

export const MAX_GROUPS = 100;
