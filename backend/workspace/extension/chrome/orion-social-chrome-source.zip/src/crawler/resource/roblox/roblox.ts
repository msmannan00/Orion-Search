import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY, MAX_GROUPS } from './constant';
import { api, clean, gamePageSize, groupOffset, userId } from './helper';

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.roblox.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const id = await userId(tab, username);
    if (!id) {
      return EMPTY;
    }

    const cursor = String(payload.cursor ?? '').trim();
    const list = await api(tab, `https://games.roblox.com/v2/users/${id}/games?limit=${gamePageSize(payload)}&sortOrder=Desc${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
    const items = (Array.isArray(list?.data) ? list.data : []) as any[];
    if (!items.length) {
      return EMPTY;
    }

    const ids = items.map((game: any) => game.id).filter(Boolean).slice(0, 50);
    const details = await api(tab, `https://games.roblox.com/v1/games?universeIds=${ids.join(',')}`);
    const votes = await api(tab, `https://games.roblox.com/v1/games/votes?universeIds=${ids.join(',')}`);
    const thumbs = await api(tab, `https://thumbnails.roblox.com/v1/games/icons?universeIds=${ids.join(',')}&size=512x512&format=Png&isCircular=false`);

    const byId = new Map<number, any>((Array.isArray(details?.data) ? details.data : []).map((entry: any) => [entry.id, entry]));
    const voteById = new Map<number, any>((Array.isArray(votes?.data) ? votes.data : []).map((entry: any) => [entry.id, entry]));
    const thumbById = new Map<number, any>((Array.isArray(thumbs?.data) ? thumbs.data : []).map((entry: any) => [entry.targetId, entry]));

    const resources = items.map((game: any): social_resource => {
      const full: any = byId.get(game.id) ?? {};
      const vote: any = voteById.get(game.id) ?? {};
      const thumb: any = thumbById.get(game.id) ?? {};
      return {
        type: 'games',
        resource_id: String(game.id ?? ''),
        url: game.rootPlace?.id ? `https://www.roblox.com/games/${game.rootPlace.id}/` : `https://www.roblox.com/games/${game.id}/`,
        parent_url: `https://www.roblox.com/users/${id}/profile`,
        title: game.name ?? '',
        caption: clean(game.description),
        author: full.creator?.name ?? username,
        datetime: game.created ?? '',
        media_type: 'game',
        media_url: thumb.imageUrl ?? '',
        thumbnail_url: thumb.imageUrl ?? '',
        likes: String((vote.upVotes ?? 0) || ''),
        shares: '',
        views: String((game.placeVisits ?? full.visits ?? 0) || ''),
        universe_id: game.id ?? 0,
        place_id: game.rootPlace?.id ?? full.rootPlaceId ?? 0,
        name: game.name ?? '',
        description: clean(game.description),
        source_name: full.sourceName ?? '',
        source_description: clean(full.sourceDescription),
        place_visits: game.placeVisits ?? full.visits ?? 0,
        playing: full.playing ?? 0,
        favorited_count: full.favoritedCount ?? 0,
        up_votes: vote.upVotes ?? 0,
        down_votes: vote.downVotes ?? 0,
        vote_ratio: (vote.upVotes ?? 0) + (vote.downVotes ?? 0) ? Math.round(((vote.upVotes ?? 0) / ((vote.upVotes ?? 0) + (vote.downVotes ?? 0))) * 10000) / 100 : 0,
        max_players: full.maxPlayers ?? 0,
        genre: full.genre ?? '',
        genre_l1: full.genre_l1 ?? '',
        genre_l2: full.genre_l2 ?? '',
        is_genre_enforced: full.isGenreEnforced ?? false,
        price: full.price ?? 0,
        copying_allowed: full.copyingAllowed ?? false,
        studio_access_to_apis: full.studioAccessToApisAllowed ?? false,
        create_vip_servers_allowed: full.createVipServersAllowed ?? false,
        universe_avatar_type: full.universeAvatarType ?? '',
        is_all_genre: full.isAllGenre ?? false,
        is_favorited_by_user: full.isFavoritedByUser ?? false,
        allowed_gear_genres: Array.isArray(full.allowedGearGenres) ? full.allowedGearGenres.join(', ') : '',
        allowed_gear_categories: Array.isArray(full.allowedGearCategories) ? full.allowedGearCategories.join(', ') : '',
        creator_id: full.creator?.id ?? game.creator?.id ?? 0,
        creator_name: full.creator?.name ?? '',
        creator_type: full.creator?.type ?? game.creator?.type ?? '',
        creator_verified: full.creator?.hasVerifiedBadge ?? false,
        thumbnail_state: thumb.state ?? '',
        created_at: game.created ?? full.created ?? '',
        updated_at: game.updated ?? full.updated ?? '',
      };
    }).filter((item) => item.url);

    const nextCursor = String(list?.nextPageCursor ?? '').trim();
    return { items: resources, next_cursor: resources.length && nextCursor && nextCursor !== cursor ? nextCursor : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.roblox.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const id = await userId(tab, username);
    if (!id) {
      return EMPTY;
    }

    const limit = limitOf(payload, 25, MAX_GROUPS);
    const offset = groupOffset(payload);
    const list = await api(tab, `https://groups.roblox.com/v2/users/${id}/groups/roles`);
    const rows = (Array.isArray(list?.data) ? list.data : []) as any[];
    const items = rows.slice(offset, offset + limit);
    if (!items.length) {
      return EMPTY;
    }

    const end = offset + items.length;
    const details = await Promise.all(items.map((entry: any) => api(tab, `https://groups.roblox.com/v1/groups/${entry.group?.id ?? 0}`)));

    const resources = items.map((entry: any, index: number): social_resource => {
      const group = entry.group ?? {};
      const role = entry.role ?? {};
      const full: any = details[index] ?? {};
      return {
        type: 'organizations',
        resource_id: String(group.id ?? ''),
        url: group.id ? `https://www.roblox.com/groups/${group.id}/` : '',
        parent_url: `https://www.roblox.com/users/${id}/profile`,
        title: group.name ?? '',
        caption: clean(full.description).slice(0, 1000),
        author: full.owner?.username ?? '',
        datetime: '',
        media_type: 'group',
        media_url: group.id ? `https://www.roblox.com/groups/${group.id}/` : '',
        thumbnail_url: '',
        likes: '',
        shares: String((group.memberCount ?? 0) || ''),
        views: '',
        group_id: group.id ?? 0,
        name: group.name ?? '',
        description: clean(full.description),
        member_count: group.memberCount ?? full.memberCount ?? 0,
        has_verified_badge: group.hasVerifiedBadge ?? false,
        is_builders_club_only: full.isBuildersClubOnly ?? false,
        public_entry_allowed: full.publicEntryAllowed ?? false,
        is_locked: full.isLocked ?? false,
        has_shout: Boolean(full.shout),
        shout_body: clean(full.shout?.body).slice(0, 500),
        shout_poster: full.shout?.poster?.username ?? '',
        shout_created: full.shout?.created ?? '',
        shout_updated: full.shout?.updated ?? '',
        owner_id: full.owner?.userId ?? 0,
        owner_username: full.owner?.username ?? '',
        owner_display_name: full.owner?.displayName ?? '',
        owner_verified: full.owner?.hasVerifiedBadge ?? false,
        role_id: role.id ?? 0,
        role_name: role.name ?? '',
        role_rank: role.rank ?? 0,
        role_member_count: role.memberCount ?? 0,
      };
    }).filter((item) => item.url);

    return { items: resources, next_cursor: resources.length && end < rows.length ? JSON.stringify({ offset: end }) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
