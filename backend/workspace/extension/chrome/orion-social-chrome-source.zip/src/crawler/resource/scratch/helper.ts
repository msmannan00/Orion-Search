import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://api.scratch.mit.edu${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function offsetOf(payload: CrawlPayload): number {
  const parsed = Number.parseInt(String(payload.cursor ?? '').trim(), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

export function pagedPath(path: string, payload: CrawlPayload): string {
  const offset = offsetOf(payload);
  return `${path}?limit=${limitOf(payload, 25, 40)}${offset ? `&offset=${offset}` : ''}`;
}

export async function fetchPage(tab: TabController, path: string, payload: CrawlPayload, map: (entry: any) => social_resource): Promise<CrawlPage> {
  const limit = limitOf(payload, 25, 40);
  const offset = offsetOf(payload);
  const raw = await api(tab, pagedPath(path, payload));
  const list = (Array.isArray(raw) ? raw : []) as any[];
  const items = list.map(map).filter((item) => item.url);
  const next = offset + list.length;
  return { items, next_cursor: items.length && list.length >= limit && next > offset ? String(next) : undefined };
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function person(username: string, type: 'followers' | 'friends', entry: any): social_resource {
  const profile = entry.profile ?? {};
  const images = profile.images ?? {};
  return {
    type,
    resource_id: String(entry.id ?? ''),
    url: entry.username ? `https://scratch.mit.edu/users/${entry.username}/` : '',
    parent_url: `https://scratch.mit.edu/users/${username}/`,
    title: entry.username ?? '',
    caption: clean(profile.bio).slice(0, 600),
    author: entry.username ?? '',
    datetime: entry.history?.joined ?? '',
    media_type: 'user',
    media_url: entry.username ? `https://scratch.mit.edu/users/${entry.username}/` : '',
    thumbnail_url: images['90x90'] ?? '',
    likes: '',
    shares: '',
    views: '',
    user_id: entry.id ?? 0,
    username: entry.username ?? '',
    is_scratchteam: entry.scratchteam ?? false,
    joined_at: entry.history?.joined ?? '',
    profile_id: profile.id ?? 0,
    bio: clean(profile.bio),
    status: clean(profile.status),
    country: profile.country ?? '',
    avatar_90: images['90x90'] ?? '',
    avatar_60: images['60x60'] ?? '',
    avatar_55: images['55x55'] ?? '',
    avatar_50: images['50x50'] ?? '',
    avatar_32: images['32x32'] ?? '',
  };
}
