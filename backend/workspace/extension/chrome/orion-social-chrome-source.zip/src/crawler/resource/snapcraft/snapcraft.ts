import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };
const HEADERS = { Accept: 'application/json', 'Snap-Device-Series': '16' };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function publisherSnaps(publisher: string): Promise<any[]> {
  const response = await fetch(`https://api.snapcraft.io/v2/snaps/find?publisher=${encodeURIComponent(publisher.trim())}&fields=title,summary,publisher,media,store-url,version,categories`, { headers: HEADERS });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data?.results) ? data.results : [];
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const publisher = String(payload.username ?? '');
  if (!publisher) {
    return EMPTY;
  }

  try {
    const all = await publisherSnaps(publisher);
    if (!all.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = all.slice(offset, offset + limit);

    const items = slice.map((result: any): social_resource => {
      const snap = result.snap ?? {};
      const name = String(result.name ?? '');
      const media = Array.isArray(snap.media) ? snap.media : [];
      const icon = media.find((entry: any) => entry?.type === 'icon')?.url ?? '';
      const categories = Array.isArray(snap.categories) ? snap.categories.map((category: any) => category?.name ?? '').filter(Boolean) : [];
      return {
        type: 'repositories',
        resource_id: String(result['snap-id'] ?? name),
        url: snap['store-url'] ?? `https://snapcraft.io/${name}`,
        parent_url: `https://snapcraft.io/publisher/${publisher}`,
        title: clean(snap.title) || name,
        caption: clean(snap.summary),
        author: snap.publisher?.['display-name'] ?? publisher,
        datetime: '',
        media_type: 'snap',
        media_url: '',
        thumbnail_url: icon,
        likes: '',
        shares: '',
        views: '',
        name,
        description: clean(snap.summary),
        version: snap.version ?? '',
        publisher_name: snap.publisher?.['display-name'] ?? '',
        publisher_id: snap.publisher?.id ?? snap.publisher?.username ?? '',
        verified: snap.publisher?.validation === 'verified',
        categories: categories.join(', '),
        store_url: snap['store-url'] ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < all.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
