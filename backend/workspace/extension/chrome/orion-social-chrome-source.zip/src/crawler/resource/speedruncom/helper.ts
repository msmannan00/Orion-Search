import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { GamesCursor } from './model';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.speedrun.com/api/v1${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function parseCursor(payload: CrawlPayload): GamesCursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { user_id: '', offset: 0 };
  }
  try {
    const parsed: any = JSON.parse(raw);
    const offset = Math.floor(Number(parsed?.offset));
    return { user_id: String(parsed?.user_id ?? ''), offset: Number.isFinite(offset) && offset > 0 ? offset : 0 };
  }
  catch {
    return { user_id: '', offset: 0 };
  }
}

export async function resolveUserId(tab: TabController, username: string): Promise<string> {
  const lookup = await api(tab, `/users?lookup=${encodeURIComponent(username.toLowerCase())}`);
  return String(lookup?.data?.[0]?.id ?? (await api(tab, `/users/${encodeURIComponent(username)}`))?.data?.id ?? '');
}
