export interface GamesCursor {
  user_id: string;
  offset: number;
}
