import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { Account, ApiResult, Cursor } from './model';

export async function api(tab: TabController, path: string): Promise<ApiResult> {
  try {
    const response = await tab.fetch(`https://api.stackexchange.com/2.3${path}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return { items: [], hasMore: false };
    }
    const data = JSON.parse(response.body);
    return { items: Array.isArray(data?.items) ? data.items : [], hasMore: Boolean(data?.has_more) };
  }
  catch {
    return { items: [], hasMore: false };
  }
}

export async function account(tab: TabController, accountId: string): Promise<Account> {
  const { items } = await api(tab, `/users/${encodeURIComponent(accountId)}/associated`);
  const best = items.slice().sort((left: any, right: any) => (right.reputation ?? 0) - (left.reputation ?? 0))[0];
  if (!best?.user_id || !best?.site_url) {
    return { site: '', userId: 0, siteName: '', siteUrl: '' };
  }

  const host = String(best.site_url).replace(/^https?:\/\//, '');
  const site = host.replace(/\.com$/, '').replace(/\.stackexchange$/, '');
  return { site, userId: Number(best.user_id), siteName: best.site_name ?? '', siteUrl: best.site_url ?? '' };
}

export function parseCursor(payload: CrawlPayload): Cursor | null {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    const page = Number(parsed?.page);
    const userId = Number(parsed?.userId);
    const site = String(parsed?.site ?? '');
    if (!Number.isFinite(page) || page < 2 || !Number.isFinite(userId) || userId <= 0 || !site) {
      return null;
    }
    return { page: Math.floor(page), site, userId, siteName: String(parsed?.siteName ?? ''), siteUrl: String(parsed?.siteUrl ?? '') };
  }
  catch {
    return null;
  }
}

export async function resolve(tab: TabController, payload: CrawlPayload, accountId: string): Promise<Cursor> {
  const cursor = parseCursor(payload);
  if (cursor) {
    return cursor;
  }
  return { page: 1, ...(await account(tab, accountId)) };
}

export async function listing(tab: TabController, path: string, payload: CrawlPayload, cursor: Cursor): Promise<ApiResult> {
  return api(tab, `${path}&page=${cursor.page}&pagesize=${limitOf(payload, 25, 100)}`);
}

export function page(items: social_resource[], result: ApiResult, cursor: Cursor): CrawlPage {
  if (!items.length || !result.hasMore) {
    return { items };
  }
  const next: Cursor = { ...cursor, page: cursor.page + 1 };
  return { items, next_cursor: JSON.stringify(next) };
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function owner(entry: any): Record<string, unknown> {
  const user = entry.owner ?? {};
  return {
    owner_user_id: user.user_id ?? 0,
    owner_account_id: user.account_id ?? 0,
    owner_display_name: user.display_name ?? '',
    owner_reputation: user.reputation ?? 0,
    owner_user_type: user.user_type ?? '',
    owner_accept_rate: user.accept_rate ?? 0,
    owner_profile_image: user.profile_image ?? '',
    owner_link: user.link ?? '',
  };
}
