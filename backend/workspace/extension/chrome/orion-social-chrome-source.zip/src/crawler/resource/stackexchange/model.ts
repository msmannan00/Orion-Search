export interface ApiResult {
  items: any[];
  hasMore: boolean;
}

export interface Account {
  site: string;
  userId: number;
  siteName: string;
  siteUrl: string;
}

export interface Cursor extends Account {
  page: number;
}
