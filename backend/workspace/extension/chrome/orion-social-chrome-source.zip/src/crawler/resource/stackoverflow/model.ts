export interface ApiResponse {
  items: any[];
  has_more: boolean;
}
