import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, owner, page, pagedPath, stamp } from './helper';

export async function answers(payload: CrawlPayload): Promise<CrawlPage> {
  const userId = String(payload.username ?? '');
  const tab = userId ? await openSession('https://stackoverflow.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const data = await api(tab, pagedPath(`/users/${encodeURIComponent(userId)}/answers?site=stackoverflow&order=desc&sort=votes&filter=!nNPvSNdWme`, payload));
    return page(data.items.map((entry: any): social_resource => ({
      type: 'answers',
      resource_id: String(entry.answer_id ?? ''),
      url: entry.link ?? `https://stackoverflow.com/a/${entry.answer_id ?? ''}`,
      parent_url: `https://stackoverflow.com/users/${userId}`,
      title: clean(entry.title),
      caption: clean(entry.body).slice(0, 2000),
      author: entry.owner?.display_name ?? '',
      datetime: stamp(entry.creation_date),
      media_type: 'answer',
      media_url: entry.question_id ? `https://stackoverflow.com/q/${entry.question_id}` : '',
      thumbnail_url: entry.owner?.profile_image ?? '',
      likes: String((entry.score ?? 0) || ''),
      shares: '',
      views: '',
      answer_id: entry.answer_id ?? 0,
      question_id: entry.question_id ?? 0,
      question_url: entry.question_id ? `https://stackoverflow.com/q/${entry.question_id}` : '',
      title_text: clean(entry.title),
      body_text: clean(entry.body).slice(0, 6000),
      body_length: String(entry.body ?? '').length,
      score: entry.score ?? 0,
      up_vote_count: entry.up_vote_count ?? 0,
      down_vote_count: entry.down_vote_count ?? 0,
      is_accepted: entry.is_accepted ?? false,
      comment_count: entry.comment_count ?? 0,
      content_license: entry.content_license ?? '',
      tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
      tags_count: Array.isArray(entry.tags) ? entry.tags.length : 0,
      site: 'stackoverflow',
      ...owner(entry),
      creation_date: stamp(entry.creation_date),
      last_activity_date: stamp(entry.last_activity_date),
      last_edit_date: stamp(entry.last_edit_date),
      community_owned_date: stamp(entry.community_owned_date),
      locked_date: stamp(entry.locked_date),
    })).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const userId = String(payload.username ?? '');
  const tab = userId ? await openSession('https://stackoverflow.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const data = await api(tab, pagedPath(`/users/${encodeURIComponent(userId)}/questions?site=stackoverflow&order=desc&sort=votes&filter=!nNPvSNdWme`, payload));
    return page(data.items.map((entry: any): social_resource => ({
      type: 'posts',
      resource_id: String(entry.question_id ?? ''),
      url: entry.link ?? `https://stackoverflow.com/q/${entry.question_id ?? ''}`,
      parent_url: `https://stackoverflow.com/users/${userId}`,
      title: clean(entry.title),
      caption: clean(entry.body).slice(0, 2000),
      author: entry.owner?.display_name ?? '',
      datetime: stamp(entry.creation_date),
      media_type: 'question',
      media_url: entry.link ?? '',
      thumbnail_url: entry.owner?.profile_image ?? '',
      likes: String((entry.score ?? 0) || ''),
      shares: '',
      views: String((entry.view_count ?? 0) || ''),
      question_id: entry.question_id ?? 0,
      title_text: clean(entry.title),
      body_text: clean(entry.body).slice(0, 6000),
      body_length: String(entry.body ?? '').length,
      score: entry.score ?? 0,
      up_vote_count: entry.up_vote_count ?? 0,
      down_vote_count: entry.down_vote_count ?? 0,
      view_count: entry.view_count ?? 0,
      answer_count: entry.answer_count ?? 0,
      comment_count: entry.comment_count ?? 0,
      favorite_count: entry.favorite_count ?? 0,
      is_answered: entry.is_answered ?? false,
      accepted_answer_id: entry.accepted_answer_id ?? 0,
      bounty_amount: entry.bounty_amount ?? 0,
      bounty_closes_date: stamp(entry.bounty_closes_date),
      closed_date: stamp(entry.closed_date),
      closed_reason: entry.closed_reason ?? '',
      protected_date: stamp(entry.protected_date),
      locked_date: stamp(entry.locked_date),
      content_license: entry.content_license ?? '',
      tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
      tags_count: Array.isArray(entry.tags) ? entry.tags.length : 0,
      site: 'stackoverflow',
      ...owner(entry),
      creation_date: stamp(entry.creation_date),
      last_activity_date: stamp(entry.last_activity_date),
      last_edit_date: stamp(entry.last_edit_date),
    })).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const userId = String(payload.username ?? '');
  const tab = userId ? await openSession('https://stackoverflow.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const data = await api(tab, pagedPath(`/users/${encodeURIComponent(userId)}/comments?site=stackoverflow&order=desc&sort=creation&filter=withbody`, payload));
    return page(data.items.map((entry: any): social_resource => ({
      type: 'comments',
      resource_id: String(entry.comment_id ?? ''),
      url: entry.link ?? (entry.post_id ? `https://stackoverflow.com/posts/${entry.post_id}#comment${entry.comment_id}_${entry.post_id}` : ''),
      parent_url: `https://stackoverflow.com/users/${userId}`,
      title: '',
      caption: clean(entry.body),
      author: entry.owner?.display_name ?? '',
      datetime: stamp(entry.creation_date),
      media_type: 'comment',
      media_url: entry.post_id ? `https://stackoverflow.com/posts/${entry.post_id}` : '',
      thumbnail_url: entry.owner?.profile_image ?? '',
      likes: String((entry.score ?? 0) || ''),
      shares: '',
      views: '',
      comment_id: entry.comment_id ?? 0,
      post_id: entry.post_id ?? 0,
      post_type: entry.post_type ?? '',
      post_url: entry.post_id ? `https://stackoverflow.com/posts/${entry.post_id}` : '',
      body_text: clean(entry.body),
      body_length: String(entry.body ?? '').length,
      score: entry.score ?? 0,
      edited: entry.edited ?? false,
      content_license: entry.content_license ?? '',
      reply_to_user_id: entry.reply_to_user?.user_id ?? 0,
      reply_to_display_name: entry.reply_to_user?.display_name ?? '',
      site: 'stackoverflow',
      ...owner(entry),
      creation_date: stamp(entry.creation_date),
    })).filter((item) => item.url), data, payload);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const postUrl = String(payload.url ?? '');
  const named = /\/questions\/(\d+)/.exec(postUrl)?.[1] ?? '';
  const userId = String(payload.username ?? '');
  if (!named && !userId) {
    return EMPTY;
  }
  const tab = await openSession('https://stackoverflow.com/');
  if (!tab) {
    return EMPTY;
  }
  try {
    // What gets tracked is a profile, so the question to read answerers from has
    // to be found rather than assumed: the user's best question stands in when
    // the crawl was given a profile instead of a question.
    let id = named;
    if (!id) {
      const owned = await api(tab, `/users/${encodeURIComponent(userId)}/questions?site=stackoverflow&order=desc&sort=votes&pagesize=1`);
      id = String(owned.items[0]?.question_id ?? '');
    }
    if (!id) {
      return EMPTY;
    }
    const data = await api(tab, `/questions/${id}/answers?site=stackoverflow&pagesize=100&order=desc&sort=votes&filter=withbody`);
    const answers: any[] = Array.isArray(data.items) ? data.items : [];
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const answer of answers) {
      const person = answer?.owner ?? {};
      const uid = String(person.user_id ?? '');
      if (!uid || seen.has(uid)) {
        continue;
      }
      seen.add(uid);
      items.push({
        type: 'connections',
        resource_id: uid,
        url: person.link ?? '',
        parent_url: postUrl || `https://stackoverflow.com/q/${id}`,
        title: clean(person.display_name),
        caption: clean(answer.body).slice(0, 600),
        author: clean(person.display_name),
        datetime: stamp(answer.creation_date),
        media_type: 'user',
        media_url: person.link ?? '',
        thumbnail_url: person.profile_image ?? '',
        likes: String((answer.score ?? 0) || ''),
        shares: '',
        views: '',
        handle: clean(person.display_name),
        user_id: uid,
        reputation: person.reputation ?? 0,
        answer_id: answer.answer_id ?? '',
        is_accepted: answer.is_accepted ?? false,
        comment_text: clean(answer.body),
        comment_url: answer.answer_id ? `${postUrl}#${answer.answer_id}` : postUrl,
        comment_at: stamp(answer.creation_date),
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
