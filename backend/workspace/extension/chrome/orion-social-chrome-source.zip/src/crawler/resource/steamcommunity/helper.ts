import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function base(payload: CrawlPayload): string {
  const url = String(payload.url ?? '');
  const match = /^https?:\/\/steamcommunity\.com\/(id|profiles)\/([^/?#]+)/i.exec(url);
  if (match) {
    return `https://steamcommunity.com/${match[1]}/${match[2]}`;
  }

  const username = String(payload.username ?? '');
  return username ? `https://steamcommunity.com/${/^\d{17}$/.test(username) ? 'profiles' : 'id'}/${encodeURIComponent(username)}` : '';
}

export async function page(tab: TabController, url: string): Promise<string> {
  try {
    const response = await tab.fetch(url);
    return response.ok ? response.body : '';
  }
  catch {
    return '';
  }
}

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function cdata(block: string, tag: string): string {
  return decode(new RegExp(`<${tag}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${tag}>`, 'i').exec(block)?.[1] ?? '');
}
