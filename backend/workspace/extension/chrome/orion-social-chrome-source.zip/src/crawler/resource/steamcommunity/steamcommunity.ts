import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { base, cdata, decode, page } from './helper';

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const profile = base(payload);
  const tab = profile ? await openSession('https://steamcommunity.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const html = await page(tab, `${profile}/games/?tab=all`);
    const raw = /var rgGames = (\[[\s\S]*?\]);/.exec(html)?.[1] ?? /"rgGames":(\[[\s\S]*?\]),"/.exec(html)?.[1] ?? '';
    let list: any[];
    try {
      list = raw ? JSON.parse(raw) : [];
    }
    catch {
      list = [];
    }

    const items = list.map((game: any): social_resource => ({
      type: 'games',
      resource_id: String(game.appid ?? ''),
      url: game.appid ? `https://store.steampowered.com/app/${game.appid}` : '',
      parent_url: profile,
      title: decode(String(game.name ?? '')),
      caption: game.hours_forever ? `${game.hours_forever} hrs on record` : '',
      author: '',
      datetime: game.last_played ? new Date(Number(game.last_played) * 1000).toISOString() : '',
      media_type: 'game',
      media_url: game.appid ? `https://store.steampowered.com/app/${game.appid}` : '',
      thumbnail_url: game.logo ?? (game.appid ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${game.appid}/header.jpg` : ''),
      likes: '',
      shares: '',
      views: '',
      app_id: game.appid ?? 0,
      name: decode(String(game.name ?? '')),
      logo: game.logo ?? '',
      hours_forever: game.hours_forever ?? '',
      hours_on_record: Number(String(game.hours_forever ?? '0').replace(/,/g, '')) || 0,
      hours_last_two_weeks: game.hours ?? '',
      last_played: game.last_played ? new Date(Number(game.last_played) * 1000).toISOString() : '',
      availability_stats_link: game.availStatLinks ? Object.keys(game.availStatLinks).filter((key) => game.availStatLinks[key]).join(', ') : '',
      stats_link: game.stats_link ?? '',
      global_stats_link: game.global_stats_link ?? '',
      friendly_url: game.friendlyURL ?? '',
      store_url: game.appid ? `https://store.steampowered.com/app/${game.appid}` : '',
      hub_url: game.appid ? `https://steamcommunity.com/app/${game.appid}` : '',
      header_image: game.appid ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${game.appid}/header.jpg` : '',
      capsule_image: game.appid ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${game.appid}/capsule_231x87.jpg` : '',
    })).filter((item) => item.url);
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const profile = base(payload);
  const tab = profile ? await openSession('https://steamcommunity.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const xml = await page(tab, `${profile}/?xml=1`);
    const groups = [...xml.matchAll(/<group\b([^>]*)>([\s\S]*?)<\/group>/g)];
    const steamId = cdata(xml, 'steamID64');

    const items = groups.map((match): social_resource => {
      const attributes = match[1] ?? '';
      const block = match[2] ?? '';
      const groupUrl = cdata(block, 'groupURL');
      return {
        type: 'organizations',
        resource_id: cdata(block, 'groupID64'),
        url: groupUrl ? `https://steamcommunity.com/groups/${groupUrl}` : '',
        parent_url: profile,
        title: cdata(block, 'groupName'),
        caption: cdata(block, 'summary').slice(0, 1000),
        author: '',
        datetime: '',
        media_type: 'group',
        media_url: groupUrl ? `https://steamcommunity.com/groups/${groupUrl}` : '',
        thumbnail_url: cdata(block, 'avatarFull'),
        likes: '',
        shares: cdata(block, 'memberCount'),
        views: '',
        group_id64: cdata(block, 'groupID64'),
        group_name: cdata(block, 'groupName'),
        group_url_name: groupUrl,
        headline: cdata(block, 'headline'),
        summary: cdata(block, 'summary'),
        avatar_icon: cdata(block, 'avatarIcon'),
        avatar_medium: cdata(block, 'avatarMedium'),
        avatar_full: cdata(block, 'avatarFull'),
        member_count: Number(cdata(block, 'memberCount')) || 0,
        members_in_chat: Number(cdata(block, 'membersInChat')) || 0,
        members_in_game: Number(cdata(block, 'membersInGame')) || 0,
        members_online: Number(cdata(block, 'membersOnline')) || 0,
        is_primary: /isPrimary="1"/.test(attributes),
        member_steam_id: steamId,
        members_url: groupUrl ? `https://steamcommunity.com/groups/${groupUrl}/members` : '',
      };
    }).filter((item) => item.url);
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const profile = base(payload);
  const tab = profile ? await openSession('https://steamcommunity.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const current = Math.max(1, Number.parseInt(String(payload.cursor ?? '').trim(), 10) || 1);
    const html = await page(tab, `${profile}/recommended/?p=${current}`);
    const hasNext = new RegExp(`[?&]p=${current + 1}\\b`).test(html);
    const boxes = [...html.matchAll(/<div[^>]+class="review_box"[\s\S]*?<div style="clear: left;"><\/div>\s*<\/div>/g)].map((match) => match[0]);

    const items = boxes.map((block: string): social_resource => {
      const appId = /steamcommunity\.com\/app\/(\d+)/.exec(block)?.[1] ?? /recommended\/(\d+)\//.exec(block)?.[1] ?? '';
      const recommendationId = /RecommendationVoteUpBtn(\d+)/.exec(block)?.[1] ?? '';
      const verdict = decode(/<div class="title"><a[^>]*>([\s\S]*?)<\/a>/.exec(block)?.[1] ?? '');
      const hours = decode(/<div class="hours">([\s\S]*?)<\/div>/.exec(block)?.[1] ?? '');
      const content = decode(/<div class="content\s*">([\s\S]*?)<\/div>/.exec(block)?.[1] ?? '');
      const posted = decode(/<div class="posted">([\s\S]*?)<\/div>/.exec(block)?.[1] ?? '');
      const header = decode(/<div class="header">([\s\S]*?)<div/.exec(block)?.[1] ?? '');
      return {
        type: 'reviews',
        resource_id: recommendationId || appId,
        url: appId ? `${profile}/recommended/${appId}/` : '',
        parent_url: profile,
        title: verdict,
        caption: content,
        author: '',
        datetime: posted.replace(/^Posted\s*/i, '').replace(/\.$/, ''),
        media_type: 'review',
        media_url: appId ? `https://store.steampowered.com/app/${appId}` : '',
        thumbnail_url: /<img class="game_capsule"src="([^"]+)"/.exec(block)?.[1] ?? '',
        likes: String(/(\d[\d,]*) people found this review helpful/.exec(block)?.[1]?.replace(/,/g, '') ?? ''),
        shares: '',
        views: '',
        recommendation_id: recommendationId,
        app_id: appId,
        app_url: appId ? `https://store.steampowered.com/app/${appId}` : '',
        hub_url: appId ? `https://steamcommunity.com/app/${appId}` : '',
        capsule_image: /<img class="game_capsule"src="([^"]+)"/.exec(block)?.[1] ?? '',
        verdict,
        is_recommended: /Recommended/i.test(verdict) && !/Not Recommended/i.test(verdict),
        review_text: content,
        review_length: content.length,
        hours_text: hours,
        hours_on_record: Number((/([\d,.]+)\s*hrs on record/.exec(hours)?.[1] ?? '').replace(/,/g, '')) || 0,
        hours_at_review: Number((/\(([\d,.]+)\s*hrs at review time\)/.exec(hours)?.[1] ?? '').replace(/,/g, '')) || 0,
        helpful_count: Number((/(\d[\d,]*) people found this review helpful/.exec(block)?.[1] ?? '').replace(/,/g, '')) || 0,
        funny_count: Number((/(\d[\d,]*) people found this review funny/.exec(block)?.[1] ?? '').replace(/,/g, '')) || 0,
        awards_count: (block.match(/class="review_award tooltip/g) ?? []).length,
        award_names: [...new Set([...block.matchAll(/reaction_award_name&quot;&gt;([^&]+)&lt;/g)].map((match) => decode(match[1])))].join(', '),
        is_key_activated: /icon_review_notcounted/.test(block),
        posted_text: posted,
        header_text: header,
      };
    }).filter((item) => item.url);
    return { items, next_cursor: items.length && hasNext ? String(current + 1) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const profile = base(payload);
  const tab = profile ? await openSession('https://steamcommunity.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const html = await page(tab, `${profile}/friends/`);
    const blocks = [...html.matchAll(/<div[^>]+class="[^"]*friend_block_v2[^"]*"[\s\S]{0,2500}?<\/div>\s*<\/div>/g)].map((match) => match[0]);

    const items = blocks.map((block: string): social_resource => {
      const steamId = /data-steamid="(\d+)"/.exec(block)?.[1] ?? '';
      const link = /<a[^>]+class="selectable_overlay"[^>]*href="([^"]+)"/.exec(block)?.[1] ?? (steamId ? `https://steamcommunity.com/profiles/${steamId}` : '');
      const name = decode(/<div class="friend_block_content">([\s\S]*?)<br/.exec(block)?.[1] ?? '');
      const avatar = /<img[^>]+src="([^"]+)"/.exec(block)?.[1] ?? '';
      const search = decode(/data-search="([^"]*)"/.exec(block)?.[1] ?? '');
      const state = decode(/<span class="friend_small_text">([\s\S]*?)<\/span>/.exec(block)?.[1] ?? /<div class="friend_block_content">[\s\S]*?<br>\s*<span[^>]*>([\s\S]*?)<\/span>/.exec(block)?.[1] ?? '');
      return {
        type: 'followers',
        resource_id: steamId,
        url: link,
        parent_url: profile,
        title: name,
        caption: state,
        author: name,
        datetime: '',
        media_type: 'friend',
        media_url: link,
        thumbnail_url: avatar,
        likes: '',
        shares: '',
        views: '',
        steam_id64: steamId,
        persona_name: name,
        profile_url: link,
        avatar,
        avatar_full: avatar.replace(/_medium\.jpg$/, '_full.jpg'),
        mini_profile_id: /data-miniprofile="(\d+)"/.exec(block)?.[1] ?? '',
        search_terms: search,
        state_text: state,
        is_in_game: /friend_block_v2[^"]*in-game/.test(block),
        is_online: /friend_block_v2[^"]*online/.test(block),
        is_offline: /friend_block_v2[^"]*offline/.test(block),
        current_game: decode(/<span class="friend_game_link">([\s\S]*?)<\/span>/.exec(block)?.[1] ?? ''),
        friends_url: `${profile}/friends/`,
      };
    }).filter((item) => item.url);
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
