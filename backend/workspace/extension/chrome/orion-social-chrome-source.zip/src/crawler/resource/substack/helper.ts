import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function origin(payload: CrawlPayload): string {
  const url = String(payload.url ?? '');
  const host = /^https?:\/\/([^/]+)/.exec(url)?.[1] ?? '';
  if (host && /substack\.com$/i.test(host) && !/^(www\.)?substack\.com$/i.test(host)) {
    return `https://${host}`;
  }
  if (host && !/substack\.com$/i.test(host)) {
    return `https://${host}`;
  }
  const username = String(payload.username ?? '').replace(/^@/, '');
  return username ? `https://${username}.substack.com` : '';
}

export async function api(tab: TabController, base: string, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`${base}${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

export function cursorOffset(payload: CrawlPayload): number {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return 0;
  }
  const direct = Number(raw);
  if (Number.isFinite(direct) && direct > 0) {
    return Math.floor(direct);
  }
  try {
    const parsed: any = JSON.parse(raw);
    const value = Number(parsed?.o ?? parsed?.offset);
    return Number.isFinite(value) && value > 0 ? Math.floor(value) : 0;
  }
  catch {
    return 0;
  }
}
