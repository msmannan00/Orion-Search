import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { blocks, clean, collect, stamp } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').replace(/^@/, '');
  const tab = username ? await openSession('https://www.threads.net/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const parsed = await blocks(tab, username);
    const threads = parsed.flatMap((block: any) => collect(block, 'thread_items')).flat();
    const seen = new Set<string>();
    const items: social_resource[] = [];

    threads.forEach((entry: any) => {
      const post = entry?.post ?? entry;
      const code = post?.code ?? '';
      if (!code || seen.has(code)) {
        return;
      }
      seen.add(code);
      const user = post.user ?? {};
      const images: any[] = Array.isArray(post.carousel_media) ? post.carousel_media : [];
      const candidate = post.image_versions2?.candidates?.[0] ?? images[0]?.image_versions2?.candidates?.[0] ?? {};
      const video = post.video_versions?.[0] ?? {};
      const text = post.caption?.text ?? post.text_post_app_info?.text_fragments?.fragments?.map((fragment: any) => fragment?.plaintext ?? '').join('') ?? '';
      items.push({
        type: 'posts',
        resource_id: String(post.pk ?? post.id ?? code),
        url: `https://www.threads.net/@${user.username ?? username}/post/${code}`,
        parent_url: `https://www.threads.net/@${username}`,
        title: '',
        caption: clean(text),
        author: user.username ?? username,
        datetime: stamp(post.taken_at),
        media_type: video.url ? 'video' : images.length ? 'carousel' : candidate.url ? 'image' : 'text',
        media_url: video.url ?? candidate.url ?? '',
        thumbnail_url: candidate.url ?? '',
        likes: String((post.like_count ?? 0) || ''),
        shares: String((post.text_post_app_info?.repost_count ?? 0) || ''),
        views: '',
        post_id: post.pk ?? post.id ?? '',
        code,
        text: clean(text),
        text_length: clean(text).length,
        like_count: post.like_count ?? 0,
        reply_count: post.text_post_app_info?.direct_reply_count ?? 0,
        repost_count: post.text_post_app_info?.repost_count ?? 0,
        quote_count: post.text_post_app_info?.quote_count ?? 0,
        is_reply: Boolean(post.text_post_app_info?.reply_to_author),
        reply_to: post.text_post_app_info?.reply_to_author?.username ?? '',
        is_quote: Boolean(post.text_post_app_info?.share_info?.quoted_post),
        is_repost: Boolean(post.text_post_app_info?.share_info?.reposted_post),
        is_paid_partnership: post.is_paid_partnership ?? false,
        has_audio: post.has_audio ?? false,
        media_count: images.length,
        media_urls: images.map((entry_item: any) => entry_item?.image_versions2?.candidates?.[0]?.url ?? entry_item?.video_versions?.[0]?.url ?? '').filter(Boolean).join(', '),
        video_url: video.url ?? '',
        video_duration: post.video_duration ?? 0,
        image_url: candidate.url ?? '',
        image_width: candidate.width ?? 0,
        image_height: candidate.height ?? 0,
        accessibility_caption: clean(post.accessibility_caption),
        link_url: post.text_post_app_info?.link_preview_attachment?.url ?? '',
        link_title: clean(post.text_post_app_info?.link_preview_attachment?.title),
        link_domain: post.text_post_app_info?.link_preview_attachment?.display_url ?? '',
        user_id: user.pk ?? user.id ?? '',
        user_username: user.username ?? '',
        user_full_name: user.full_name ?? '',
        user_avatar: user.profile_pic_url ?? '',
        user_is_verified: user.is_verified ?? false,
        user_followers: user.follower_count ?? 0,
        taken_at: stamp(post.taken_at),
      });
    });

    return { items: items.filter((item) => item.url) };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
