import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { ItemPage } from './model';

export async function account(tab: TabController, username: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://www.tiktok.com/@${encodeURIComponent(username)}`);
    if (!response.ok) {
      return null;
    }

    const html = response.body;
    const raw = /<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1];
    const scope = raw ? JSON.parse(raw)?.__DEFAULT_SCOPE__ : null;
    return scope?.['webapp.user-detail']?.userInfo ?? null;
  }
  catch {
    return null;
  }
}

export function cookie(name: string): string {
  return new RegExp(`(?:^|;\\s*)${name}=([^;]+)`).exec(globalThis.document?.cookie ?? '')?.[1] ?? '';
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export async function items(tab: TabController, username: string, count = 35, cursor = '0'): Promise<ItemPage> {
  const info = await account(tab, username);
  const user = info?.user ?? {};
  const secUid = user.secUid ?? '';
  if (!secUid) {
    return { list: [], user, cursor: '', hasMore: false };
  }

  try {
    const params = new URLSearchParams({
      aid: '1988',
      app_language: 'en',
      app_name: 'tiktok_web',
      browser_language: 'en-US',
      browser_platform: 'Win32',
      channel: 'tiktok_web',
      cookie_enabled: 'true',
      count: String(count),
      cursor: cursor || '0',
      device_platform: 'web_pc',
      history_len: '3',
      secUid,
      msToken: cookie('msToken'),
    });
    const response = await tab.fetch(`https://www.tiktok.com/api/post/item_list/?${params.toString()}`, {
      headers: { Accept: 'application/json', Referer: `https://www.tiktok.com/@${username}` },
    });
    if (!response.ok) {
      return { list: [], user, cursor: '', hasMore: false };
    }

    const data = JSON.parse(response.body);
    return { list: Array.isArray(data?.itemList) ? data.itemList : [], user, cursor: String(data?.cursor ?? ''), hasMore: Boolean(data?.hasMore) };
  }
  catch {
    return { list: [], user, cursor: '', hasMore: false };
  }
}

export function post(username: string, type: 'posts' | 'videos', item: any, user: any): social_resource {
  const video = item.video ?? {};
  const stats = item.stats ?? item.statsV2 ?? {};
  const music = item.music ?? {};
  const author = item.author ?? {};
  const challenges: any[] = Array.isArray(item.challenges) ? item.challenges : [];
  const hashtags = [...String(item.desc ?? '').matchAll(/#([\p{L}\p{N}_]+)/gu)].map((match) => match[1]);
  const mentions = [...String(item.desc ?? '').matchAll(/@([\w.]+)/g)].map((match) => match[1]);
  return {
    type,
    resource_id: String(item.id ?? ''),
    url: item.id ? `https://www.tiktok.com/@${author.uniqueId ?? username}/video/${item.id}` : '',
    parent_url: `https://www.tiktok.com/@${username}`,
    title: clean(item.desc).slice(0, 120),
    caption: clean(item.desc),
    author: author.uniqueId ?? username,
    datetime: stamp(item.createTime),
    media_type: video.duration ? 'video' : 'photo',
    media_url: video.playAddr ?? video.downloadAddr ?? '',
    thumbnail_url: video.dynamicCover ?? video.cover ?? video.originCover ?? '',
    likes: String((stats.diggCount ?? 0) || ''),
    shares: String((stats.shareCount ?? 0) || ''),
    views: String((stats.playCount ?? 0) || ''),
    video_id: item.id ?? '',
    description: clean(item.desc),
    description_length: String(item.desc ?? '').length,
    hashtags: hashtags.join(', '),
    hashtags_count: hashtags.length,
    mentions: mentions.join(', '),
    mentions_count: mentions.length,
    challenges: challenges.map((challenge: any) => challenge?.title ?? '').filter(Boolean).join(', '),
    digg_count: stats.diggCount ?? 0,
    share_count: stats.shareCount ?? 0,
    comment_count: stats.commentCount ?? 0,
    play_count: stats.playCount ?? 0,
    collect_count: Number(stats.collectCount ?? 0),
    duration: video.duration ?? 0,
    width: video.width ?? 0,
    height: video.height ?? 0,
    ratio: video.ratio ?? '',
    format: video.format ?? '',
    bitrate: video.bitrate ?? 0,
    codec_type: video.codecType ?? '',
    definition: video.definition ?? '',
    play_addr: video.playAddr ?? '',
    download_addr: video.downloadAddr ?? '',
    cover: video.cover ?? '',
    origin_cover: video.originCover ?? '',
    dynamic_cover: video.dynamicCover ?? '',
    is_ad: item.isAd ?? false,
    is_pinned: item.isPinnedItem ?? false,
    duet_enabled: item.duetEnabled ?? false,
    stitch_enabled: item.stitchEnabled ?? false,
    share_enabled: item.shareEnabled ?? false,
    is_private: item.privateItem ?? false,
    music_id: music.id ?? '',
    music_title: music.title ?? '',
    music_author: music.authorName ?? '',
    music_original: music.original ?? false,
    music_duration: music.duration ?? 0,
    music_url: music.playUrl ?? '',
    music_cover: music.coverLarge ?? '',
    author_id: author.id ?? '',
    author_unique_id: author.uniqueId ?? '',
    author_nickname: author.nickname ?? '',
    author_avatar: author.avatarLarger ?? '',
    author_verified: author.verified ?? false,
    author_signature: clean(author.signature),
    author_followers: user?.stats?.followerCount ?? 0,
    create_time: stamp(item.createTime),
  };
}

function domPost(username: string, type: 'posts' | 'videos', id: string, url: string, desc: string, views: string, image: string): social_resource {
  const hashtags = [...desc.matchAll(/#([\p{L}\p{N}_]+)/gu)].map((match) => match[1]);
  const mentions = [...desc.matchAll(/@([\w.]+)/g)].map((match) => match[1]);
  return {
    type,
    resource_id: id,
    url,
    parent_url: `https://www.tiktok.com/@${username}`,
    title: clean(desc).slice(0, 120),
    caption: clean(desc),
    author: username,
    datetime: '',
    media_type: 'video',
    is_video: true,
    media_url: url,
    thumbnail_url: image,
    cover: image,
    thumbnail: image,
    likes: '',
    shares: '',
    views,
    video_id: id,
    description: clean(desc),
    description_length: String(desc).length,
    hashtags: hashtags.join(', '),
    hashtags_count: hashtags.length,
    mentions: mentions.join(', '),
    mentions_count: mentions.length,
    play_count_text: views,
    author_unique_id: username,
  };
}

export async function pageOf(payload: CrawlPayload, type: 'posts' | 'videos'): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`https://www.tiktok.com/@${encodeURIComponent(username)}`) : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    await tab.overlay(`Fetching TikTok videos for @${username}…`);
    let ready = await tab.query('div[data-e2e="user-post-item"] img');
    for (let attempt = 0; attempt < 6 && !ready.length; attempt += 1) {
      await tab.scrollLoad(4);
      ready = await tab.query('div[data-e2e="user-post-item"] img');
    }
    const collected = await tab.scrollCollect('div[data-e2e="user-post-item"]', limitOf(payload, 60, 120));

    const seen = new Set<string>();
    const mapped: social_resource[] = [];
    collected.forEach((item) => {
      const idMatch = /\/video\/(\d+)/.exec(item.href ?? '');
      if (!idMatch || seen.has(idMatch[1])) {
        return;
      }
      seen.add(idMatch[1]);
      const desc = String(item.alt ?? '').replace(/\s*created by\s[\s\S]*$/i, '').trim();
      const views = (/([\d.,]+\s*[KMB]?)\s*$/i.exec(String(item.text ?? '')) || [])[1] || String(item.text ?? '').trim();
      mapped.push(domPost(username, type, idMatch[1], item.href ?? '', desc, views, item.src ?? ''));
    });

    return { items: mapped };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
