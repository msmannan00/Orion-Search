import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { pageOf } from './helper';

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  return pageOf(payload, 'videos');
}
