import { CrawlPage, CrawlPayload } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { media, site, walk } from './helper';

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://vsco.co/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const profile = await site(tab, username);
    if (!profile?.id) {
      return { items: [] };
    }

    const { rows, next } = await walk(tab, profile.id, payload, (item: any) => !item.is_video);
    return { items: rows.map((item: any) => media(username, 'images', item, profile)).filter((item) => item.url), next_cursor: next };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://vsco.co/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const profile = await site(tab, username);
    if (!profile?.id) {
      return { items: [] };
    }

    const { rows, next } = await walk(tab, profile.id, payload, (item: any) => Boolean(item.is_video));
    return { items: rows.map((item: any) => media(username, 'videos', item, profile)).filter((item) => item.url), next_cursor: next };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
