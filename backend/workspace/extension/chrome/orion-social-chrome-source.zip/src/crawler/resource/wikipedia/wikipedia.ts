import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { api, clean, origin } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '').replace(/_/g, ' ');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const data = await api(tab, base, {
      action: 'query',
      list: 'usercontribs',
      ucuser: username,
      uclimit: String(limitOf(payload, 50, 500)),
      ucprop: 'ids|title|timestamp|comment|parsedcomment|size|sizediff|flags|tags',
      ...(String(payload.cursor ?? '').trim() ? { uccontinue: String(payload.cursor).trim() } : {}),
    });

    const items = (data?.query?.usercontribs ?? []) as any[];
    const mapped = items.map((entry: any): social_resource => {
      const title = entry.title ?? '';
      return {
        type: 'posts',
        resource_id: String(entry.revid ?? ''),
        url: entry.revid ? `${base}/w/index.php?title=${encodeURIComponent(title)}&oldid=${entry.revid}` : '',
        parent_url: `${base}/wiki/User:${encodeURIComponent(username.replace(/ /g, '_'))}`,
        title,
        caption: clean(entry.comment),
        author: entry.user ?? username,
        datetime: entry.timestamp ?? '',
        media_type: 'revision',
        media_url: `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        revision_id: entry.revid ?? 0,
        parent_revision_id: entry.parentid ?? 0,
        page_id: entry.pageid ?? 0,
        page_title: title,
        page_url: `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        namespace: entry.ns ?? 0,
        namespace_name: title.includes(':') ? title.split(':')[0] : 'Article',
        user_id: entry.userid ?? 0,
        user_name: entry.user ?? username,
        comment: clean(entry.comment),
        parsed_comment: clean(entry.parsedcomment),
        section: /\/\*\s*(.*?)\s*\*\//.exec(String(entry.comment ?? ''))?.[1] ?? '',
        size_bytes: entry.size ?? 0,
        size_diff: entry.sizediff ?? 0,
        is_new: entry.new ?? false,
        is_minor: entry.minor ?? false,
        is_top: entry.top ?? false,
        is_anon: entry.anon ?? false,
        tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
        tags_count: Array.isArray(entry.tags) ? entry.tags.length : 0,
        is_mobile_edit: Array.isArray(entry.tags) && entry.tags.some((tag: string) => /mobile/i.test(tag)),
        is_visual_edit: Array.isArray(entry.tags) && entry.tags.some((tag: string) => /visualeditor/i.test(tag)),
        is_revert: Array.isArray(entry.tags) && entry.tags.some((tag: string) => /revert|undo|rollback/i.test(tag)),
        diff_url: entry.revid ? `${base}/w/index.php?title=${encodeURIComponent(title)}&diff=${entry.revid}&oldid=${entry.parentid ?? 0}` : '',
        history_url: `${base}/w/index.php?title=${encodeURIComponent(title)}&action=history`,
        wiki_host: base,
        timestamp: entry.timestamp ?? '',
      };
    }).filter((item) => item.url);
    return { items: mapped, next_cursor: data?.continue?.uccontinue ? String(data.continue.uccontinue) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '').replace(/_/g, ' ');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const data = await api(tab, base, {
      action: 'query',
      list: 'logevents',
      letype: 'upload',
      leuser: username,
      lelimit: String(limitOf(payload, 50, 500)),
      leprop: 'ids|title|type|user|userid|timestamp|comment|parsedcomment|details|tags',
      ...(String(payload.cursor ?? '').trim() ? { lecontinue: String(payload.cursor).trim() } : {}),
    });

    const items = (data?.query?.logevents ?? []) as any[];
    const titles = [...new Set(items.map((entry: any) => entry.title ?? '').filter(Boolean))].slice(0, 50);
    const info = titles.length
      ? await api(tab, base, { action: 'query', titles: titles.join('|'), prop: 'imageinfo', iiprop: 'timestamp|user|url|size|dimensions|mime|mediatype|sha1|comment', iilimit: '1' })
      : null;
    const byTitle = new Map<string, any>((info?.query?.pages ?? []).map((page: any) => [page.title, page]));

    const mapped = items.map((entry: any): social_resource => {
      const title = entry.title ?? '';
      const page: any = byTitle.get(title) ?? {};
      const image: any = Array.isArray(page.imageinfo) ? page.imageinfo[0] ?? {} : {};
      return {
        type: 'images',
        resource_id: String(entry.logid ?? ''),
        url: image.descriptionurl ?? `${base}/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        parent_url: `${base}/wiki/User:${encodeURIComponent(username.replace(/ /g, '_'))}`,
        title,
        caption: clean(entry.comment),
        author: entry.user ?? username,
        datetime: entry.timestamp ?? '',
        media_type: image.mime ?? 'image',
        media_url: image.url ?? '',
        thumbnail_url: image.thumburl ?? image.url ?? '',
        likes: '',
        shares: '',
        views: '',
        log_id: entry.logid ?? 0,
        log_action: entry.action ?? '',
        log_type: entry.type ?? '',
        file_title: title,
        file_name: title.replace(/^File:/i, ''),
        page_id: entry.pageid ?? page.pageid ?? 0,
        log_page: entry.logpage ?? 0,
        namespace: entry.ns ?? 0,
        user_name: entry.user ?? '',
        user_id: entry.userid ?? 0,
        comment: clean(entry.comment),
        parsed_comment: clean(entry.parsedcomment),
        tags: Array.isArray(entry.tags) ? entry.tags.join(', ') : '',
        tags_count: Array.isArray(entry.tags) ? entry.tags.length : 0,
        file_url: image.url ?? '',
        description_url: image.descriptionurl ?? '',
        mime: image.mime ?? '',
        media_class: image.mediatype ?? '',
        width: image.width ?? 0,
        height: image.height ?? 0,
        size_bytes: image.size ?? 0,
        sha1: image.sha1 ?? '',
        latest_uploader: image.user ?? '',
        latest_upload_time: image.timestamp ?? '',
        wiki_host: base,
        timestamp: entry.timestamp ?? '',
      };
    }).filter((item) => item.url);
    return { items: mapped, next_cursor: data?.continue?.lecontinue ? String(data.continue.lecontinue) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
