import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function site(payload: CrawlPayload): string {
  const host = /^https?:\/\/([^/]+)/.exec(payload.url ?? '')?.[1] ?? '';
  return host || String(payload.username ?? '');
}

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://public-api.wordpress.com/rest/v1.1${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&#8217;/g, "'").replace(/&#8216;/g, "'").replace(/&#8220;/g, '"').replace(/&#8221;/g, '"').replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}
