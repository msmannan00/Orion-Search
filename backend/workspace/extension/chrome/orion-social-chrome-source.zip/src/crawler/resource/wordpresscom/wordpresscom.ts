import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { api, clean, site } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const host = site(payload);
  const tab = host ? await openSession('https://wordpress.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const page = Math.max(1, Number.parseInt(String(payload.cursor ?? '').trim(), 10) || 1);
    const data = await api(tab, `/sites/${encodeURIComponent(host)}/posts/?number=20&page=${page}&fields=ID,site_ID,author,date,modified,title,URL,short_URL,content,excerpt,slug,guid,status,sticky,password,parent,type,discussion,likes_enabled,sharing_enabled,like_count,i_like,is_reblogged,global_ID,featured_image,post_thumbnail,format,geo,menu_order,page_template,publicize_URLs,terms,tags,categories,attachments,attachment_count,metadata,meta,capabilities,other_URLs`);
    const rows = (data?.posts ?? []) as any[];
    const items = rows.map((post: any): social_resource => {
      const author = post.author ?? {};
      const categories = Object.values(post.categories ?? {}) as any[];
      const tags = Object.values(post.tags ?? {}) as any[];
      const attachments = Object.values(post.attachments ?? {}) as any[];
      const thumbnail = post.post_thumbnail ?? {};
      return {
        type: 'posts',
        resource_id: String(post.ID ?? ''),
        url: post.URL ?? '',
        parent_url: `https://${host}`,
        title: clean(post.title),
        caption: clean(post.excerpt),
        author: author.name ?? author.login ?? '',
        datetime: post.date ?? '',
        media_type: post.type ?? 'post',
        media_url: post.featured_image ?? thumbnail.URL ?? '',
        thumbnail_url: post.featured_image ?? thumbnail.URL ?? '',
        likes: String((post.like_count ?? 0) || ''),
        shares: '',
        views: '',
        post_id: post.ID ?? 0,
        site_id: post.site_ID ?? 0,
        global_id: post.global_ID ?? '',
        guid: post.guid ?? '',
        slug: post.slug ?? '',
        short_url: post.short_URL ?? '',
        title_text: clean(post.title),
        excerpt: clean(post.excerpt),
        content_text: clean(post.content).slice(0, 6000),
        content_length: String(post.content ?? '').length,
        status: post.status ?? '',
        post_type: post.type ?? '',
        format: post.format ?? '',
        is_sticky: post.sticky ?? false,
        has_password: post.has_password ?? Boolean(post.password),
        parent_post: post.parent ? String(post.parent?.ID ?? post.parent) : '',
        menu_order: post.menu_order ?? 0,
        page_template: post.page_template ?? '',
        like_count: post.like_count ?? 0,
        likes_enabled: post.likes_enabled ?? false,
        sharing_enabled: post.sharing_enabled ?? false,
        is_reblogged: post.is_reblogged ?? false,
        comment_count: post.discussion?.comment_count ?? 0,
        comments_open: post.discussion?.comments_open ?? false,
        comment_status: post.discussion?.comment_status ?? '',
        pings_open: post.discussion?.pings_open ?? false,
        ping_status: post.discussion?.ping_status ?? '',
        featured_image: post.featured_image ?? '',
        thumbnail_width: thumbnail.width ?? 0,
        thumbnail_height: thumbnail.height ?? 0,
        thumbnail_mime: thumbnail.mime_type ?? '',
        categories: categories.map((category: any) => category?.name ?? '').filter(Boolean).join(', '),
        categories_count: categories.length,
        tags: tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        tags_count: tags.length,
        attachment_count: post.attachment_count ?? attachments.length,
        attachment_urls: attachments.map((attachment: any) => attachment?.URL ?? '').filter(Boolean).slice(0, 30).join(', '),
        attachment_types: [...new Set(attachments.map((attachment: any) => attachment?.mime_type ?? '').filter(Boolean))].join(', '),
        publicize_urls: Array.isArray(post.publicize_URLs) ? post.publicize_URLs.join(', ') : '',
        geo_latitude: post.geo?.latitude ?? 0,
        geo_longitude: post.geo?.longitude ?? 0,
        geo_address: post.geo?.address ?? '',
        author_id: author.ID ?? 0,
        author_login: author.login ?? '',
        author_name: author.name ?? '',
        author_nice_name: author.nice_name ?? '',
        author_url: author.URL ?? '',
        author_avatar: author.avatar_URL ?? '',
        author_profile_url: author.profile_URL ?? '',
        author_site_id: author.site_ID ?? 0,
        date: post.date ?? '',
        modified: post.modified ?? '',
      };
    }).filter((item) => item.url);
    return { items, next_cursor: rows.length >= 20 && Number(data?.found ?? 0) > page * 20 ? String(page + 1) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const host = site(payload);
  const tab = host ? await openSession('https://wordpress.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const page = Math.max(1, Number.parseInt(String(payload.cursor ?? '').trim(), 10) || 1);
    const data = await api(tab, `/sites/${encodeURIComponent(host)}/comments/?number=20&page=${page}`);
    const rows = (data?.comments ?? []) as any[];
    const items = rows.map((comment: any): social_resource => {
      const author = comment.author ?? {};
      const post = comment.post ?? {};
      return {
        type: 'comments',
        resource_id: String(comment.ID ?? ''),
        url: comment.URL ?? '',
        parent_url: `https://${host}`,
        title: clean(post.title),
        caption: clean(comment.content),
        author: author.name ?? '',
        datetime: comment.date ?? '',
        media_type: comment.type ?? 'comment',
        media_url: post.link ?? '',
        thumbnail_url: author.avatar_URL ?? '',
        likes: String((comment.like_count ?? 0) || ''),
        shares: '',
        views: '',
        comment_id: comment.ID ?? 0,
        post_id: post.ID ?? 0,
        post_title: clean(post.title),
        post_url: post.link ?? '',
        parent_comment_id: comment.parent ? String(comment.parent?.ID ?? comment.parent) : '',
        is_reply: Boolean(comment.parent),
        content_text: clean(comment.content),
        content_length: String(comment.content ?? '').length,
        status: comment.status ?? '',
        comment_type: comment.type ?? '',
        like_count: comment.like_count ?? 0,
        i_like: comment.i_like ?? false,
        short_url: comment.short_URL ?? '',
        author_id: author.ID ?? 0,
        author_login: author.login ?? '',
        author_name: author.name ?? '',
        author_email: author.email === false ? '' : String(author.email ?? ''),
        author_url: author.URL ?? '',
        author_avatar: author.avatar_URL ?? '',
        author_profile_url: author.profile_URL ?? '',
        author_site_id: author.site_ID ?? 0,
        author_ip: author.ip_address === false ? '' : String(author.ip_address ?? ''),
        date: comment.date ?? '',
      };
    }).filter((item) => item.url);
    return { items, next_cursor: rows.length >= 20 && Number(data?.found ?? 0) > page * 20 ? String(page + 1) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
