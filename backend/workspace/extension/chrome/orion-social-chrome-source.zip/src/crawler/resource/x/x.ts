import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { clean } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').replace(/^@/, '');
  const tab = username ? await openSession('https://x.com/') : null;
  if (!tab) {
    return { items: [] };
  }
  try {
    await tab.navigate(`https://x.com/${encodeURIComponent(username)}`);
    await tab.scrollLoad(15);
    const html = await tab.html();
    if (!html) {
      return { items: [] };
    }

    const seen = new Set<string>();
    const items: social_resource[] = [];
    const re = /href="(\/([^"/]+)\/status\/(\d+))"[^>]*>(?:(?!<\/a>)[\s\S]){0,200}?<time[^>]+datetime="([^"]+)"/g;
    for (const match of html.matchAll(re)) {
      const path = match[1];
      const author = match[2];
      const id = match[3];
      const datetime = match[4];
      if (seen.has(id) || /^(i|home|search|notifications|messages|explore)$/i.test(author)) {
        continue;
      }
      seen.add(id);
      const after = html.slice((match.index ?? 0) + match[0].length);
      const nextStatus = after.search(/\/status\/\d+"/);
      const window = nextStatus > 0 ? after.slice(0, nextStatus) : after.slice(0, 4000);
      const textStart = window.indexOf('data-testid="tweetText"');
      const textOpen = textStart >= 0 ? window.indexOf('>', textStart) : -1;
      const caption = textOpen >= 0 ? clean(window.slice(textOpen + 1).replace(/<[^>]+>/g, ' ')).slice(0, 500) : '';
      items.push({
        type: 'posts',
        resource_id: id,
        url: `https://x.com${path}`,
        parent_url: `https://x.com/${username}`,
        title: '',
        caption,
        author: author || username,
        datetime,
        media_type: 'text',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        tweet_id: id,
        text: caption,
        text_length: caption.length,
        is_reply: false,
        created_at: datetime,
      });
    }
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
