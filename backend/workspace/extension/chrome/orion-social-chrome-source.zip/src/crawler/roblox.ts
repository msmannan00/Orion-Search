import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { games, organizations } from './resource/roblox/roblox';

export class Roblox implements Crawler {
  readonly platform = 'roblox';
  readonly base = 'https://www.roblox.com';
  readonly loginUrl = 'https://www.roblox.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'games':
        return games(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      let userId = /\/users\/(\d+)/.exec(url ?? '')?.[1] ?? '';
      if (!userId) {
        const lookup = await fetch('https://users.roblox.com/v1/usernames/users', {
          method: 'POST',
          headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
          body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
        });
        if (!lookup.ok) {
          return [];
        }
        const found = await lookup.json();
        userId = String(found?.data?.[0]?.id ?? '');
      }
      if (!userId) {
        return [];
      }

      const response = await fetch(`https://users.roblox.com/v1/users/${userId}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.displayName ?? data.name ?? username,
        bio: data.description ?? '',
        description: data.description ?? '',
        location: '',
        profile_url: `https://www.roblox.com/users/${data.id}/profile`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'games', 'organizations'],
        platform: this.platform,
        username: data.name ?? username,
        id: data.id ?? 0,
        display_name: data.displayName ?? '',
        has_verified_badge: data.hasVerifiedBadge ?? false,
        is_banned: data.isBanned ?? false,
        external_app_display_name: data.externalAppDisplayName ?? '',
        created_at: data.created ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://users.roblox.com/v1/users/authenticated', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
