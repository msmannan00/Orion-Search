import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, games, organizations, reviews } from './resource/steamcommunity/steamcommunity';

export class SteamCommunity implements Crawler {
  readonly platform = 'steamcommunity';
  readonly base = 'https://steamcommunity.com';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'games':
        return games(payload);
      case 'organizations':
        return organizations(payload);
      case 'reviews':
        return reviews(payload);
      case 'followers':
        return followers(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const match = /steamcommunity\.com\/(id|profiles)\/([^/?#]+)/.exec(url ?? '');
      const path = match ? `${match[1]}/${match[2]}` : `id/${username}`;
      const response = await fetch(`https://steamcommunity.com/${path}/?xml=1`);
      if (!response.ok) {
        return [];
      }

      const xml = await response.text();
      const tag = (name: string): string => {
        const found = new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`).exec(xml);
        return (found?.[1] ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      };
      const steamId = tag('steamID64');
      if (!steamId) {
        return [];
      }

      const groupBlocks = [...xml.matchAll(/<group[^>]*>([\s\S]*?)<\/group>/g)].map((m) => m[1]);
      const groupTag = (block: string, name: string): string => {
        const found = new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`).exec(block);
        return (found?.[1] ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      };
      const groupNames = groupBlocks.map((block) => groupTag(block, 'groupName')).filter(Boolean);
      const primaryGroup = groupBlocks[0] ?? '';

      return [{
        real_name: tag('realname') || tag('steamID'),
        bio: tag('summary'),
        description: tag('summary'),
        location: tag('location'),
        profile_url: `https://steamcommunity.com/${path}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: tag('avatarFull') || tag('avatarMedium'),
        banner: '',
        crawl_type: ['details', 'games', 'organizations', 'reviews'],
        platform: this.platform,
        username: tag('customURL') || username,
        steam_id64: steamId,
        persona_name: tag('steamID'),
        custom_url: tag('customURL'),
        headline: tag('headline'),
        online_state: tag('onlineState'),
        state_message: tag('stateMessage').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        privacy_state: tag('privacyState'),
        visibility_state: tag('visibilityState'),
        is_limited_account: tag('isLimitedAccount') === '1',
        vac_banned: tag('vacBanned') === '1',
        trade_ban_state: tag('tradeBanState'),
        steam_rating: tag('steamRating'),
        hours_played_2wk: tag('hoursPlayed2Wk'),
        member_since: tag('memberSince'),
        groups_count: groupBlocks.length,
        group_names: groupNames.slice(0, 20).join(', '),
        primary_group_name: groupTag(primaryGroup, 'groupName'),
        primary_group_id: groupTag(primaryGroup, 'groupID64'),
        primary_group_url: groupTag(primaryGroup, 'groupURL'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://steamcommunity.com/my/edit', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login\/home/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
