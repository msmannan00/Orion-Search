import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { comments, posts } from './resource/substack/substack';

export class Substack implements Crawler {
  readonly platform = 'substack';
  readonly base = 'https://substack.com';
  readonly loginUrl = 'https://substack.com/sign-in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const host = /^https?:\/\/([^/]+)/.exec(url ?? '')?.[1] ?? '';
      const handle = username || host.replace(/\.substack\.com$/, '');
      const response = await fetch(`https://substack.com/api/v1/user/${encodeURIComponent(handle)}/public_profile`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const data: any = await response.json();
      if (!data?.id) {
        return [];
      }

      const links: any[] = Array.isArray(data.userLinks) ? data.userLinks : [];
      const pubUsers: any[] = Array.isArray(data.publicationUsers) ? data.publicationUsers : [];
      const pub: any = data.primaryPublication ?? {};

      return [{
        real_name: data.name ?? handle,
        bio: data.bio ?? '',
        description: data.bio ?? '',
        location: '',
        profile_url: `https://substack.com/@${data.handle ?? handle}`,
        total_posts: '',
        total_followers: String((data.subscriberCount ?? data.followerCount ?? 0) || ''),
        total_likes: '',
        avatar: data.photo_url ?? '',
        banner: '',
        crawl_type: ['details', 'posts', 'comments'],
        platform: this.platform,
        username: data.handle ?? handle,
        user_id: data.id ?? 0,
        handle: data.handle ?? '',
        slug: data.slug ?? '',
        previous_name: data.previous_name ?? '',
        follower_count: data.followerCount ?? 0,
        subscriber_count: data.subscriberCount ?? 0,
        subscriber_count_string: data.subscriberCountString ?? '',
        visible_subscriptions: data.visibleSubscriptionsCount ?? 0,
        user_links: links.map((l: any) => l.href ?? l.url ?? '').filter(Boolean).join(', '),
        user_links_count: links.length,
        publication_name: pub.name ?? '',
        publication_subdomain: pub.subdomain ?? '',
        publication_custom_domain: pub.custom_domain ?? '',
        publication_url: pub.base_url ?? (pub.subdomain ? `https://${pub.subdomain}.substack.com` : ''),
        publications_count: pubUsers.length,
        has_posts: data.hasPosts ?? false,
        has_activity: data.hasActivity ?? false,
        bestseller_tier: data.bestseller_tier ?? 0,
        profile_set_up_at: data.profile_set_up_at ?? '',
        reader_installed_at: data.reader_installed_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://substack.com/api/v1/user', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
