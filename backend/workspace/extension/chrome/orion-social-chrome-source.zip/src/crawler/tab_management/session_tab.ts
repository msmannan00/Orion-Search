import { openSession, TabController } from './tab.controller';

interface CrawlSession {
  tab: TabController;
  cache: Record<string, unknown>;
  timer: ReturnType<typeof setTimeout> | null;
}

const IDLE_CLOSE_MS = 20000;
const sessions = new Map<string, CrawlSession>();

export function liveSession(key: string): CrawlSession | undefined {
  const session = sessions.get(key);
  if (session && session.tab.ready) {
    if (session.timer) {
      clearTimeout(session.timer);
      session.timer = null;
    }
    return session;
  }
  if (session) {
    sessions.delete(key);
  }
  return undefined;
}

export async function openSessionTab(key: string, origin: string): Promise<TabController | null> {
  await closeSessionTab(key);
  const tab = await openSession(origin);
  if (!tab) {
    return null;
  }
  sessions.set(key, { tab, cache: {}, timer: null });
  return tab;
}

export function sessionCache(key: string): Record<string, unknown> {
  return sessions.get(key)?.cache ?? {};
}

export function cacheSession(key: string, values: Record<string, unknown>): void {
  const session = sessions.get(key);
  if (session) {
    session.cache = { ...session.cache, ...values };
  }
}

export function keepSessionAlive(key: string): void {
  const session = sessions.get(key);
  if (!session) {
    return;
  }
  if (session.timer) {
    clearTimeout(session.timer);
  }
  session.timer = setTimeout(() => { void closeSessionTab(key); }, IDLE_CLOSE_MS);
}

export async function closeSessionTab(key: string): Promise<void> {
  const session = sessions.get(key);
  if (!session) {
    return;
  }
  if (session.timer) {
    clearTimeout(session.timer);
  }
  sessions.delete(key);
  try {
    await session.tab.close();
  }
  catch {
  }
}
