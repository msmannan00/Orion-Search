import { CHALLENGE_INTERSTITIAL_MAX, CHALLENGE_STRONG_MARKERS } from '../constant/challenge';
import { closeTab, fetchInTab, getCookies, getHtml, navigate, openTab, overlayTab, queryTab, scrollCollectTab, TabCollectItem, TabQueryItem, scrollLoad, TabFetchOptions, TabFetchResult } from './tab.helper';

export class TabController {
  private tabId: number | null = null;
  private safety: ReturnType<typeof setTimeout> | null = null;

  get ready(): boolean {
    return this.tabId != null;
  }

  async launch(active = false, popup = false): Promise<boolean> {
    const handle = await openTab(active, popup);
    if (!handle) {
      return false;
    }
    this.tabId = handle.tabId;
    this.safety = setTimeout(() => { void this.close(); }, 120000);
    return true;
  }

  attach(tabId: number): void {
    this.tabId = tabId;
  }

  async scrollCollect(selector: string, steps = 40): Promise<TabCollectItem[]> {
    return this.tabId == null ? [] : scrollCollectTab(this.tabId, selector, steps);
  }

  async query(selector: string): Promise<TabQueryItem[]> {
    return this.tabId == null ? [] : queryTab(this.tabId, selector);
  }

  async cookies(): Promise<string> {
    return this.tabId == null ? '' : getCookies(this.tabId);
  }

  async navigate(url: string): Promise<string> {
    return this.tabId == null ? '' : navigate(this.tabId, url);
  }

  async html(): Promise<string> {
    return this.tabId == null ? '' : getHtml(this.tabId);
  }

  // An interstitial clears itself once its script has run, so a tab is given the
  // time the guard already allows before its markup is taken at face value. The
  // markers are the shared ones, so a challenge the fetch guard would catch is
  // not missed here because this had a shorter list of its own.
  async settle(timeoutMs = CHALLENGE_INTERSTITIAL_MAX, delayMs = 1000): Promise<void> {
    if (this.tabId == null) {
      return;
    }
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const html = await this.html();
      if (html && !CHALLENGE_STRONG_MARKERS.test(html)) {
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  async fetch(url: string, options?: TabFetchOptions): Promise<TabFetchResult> {
    return this.tabId == null ? { ok: false, status: 0, body: '' } : fetchInTab(this.tabId, url, options);
  }

  async overlay(text: string): Promise<void> {
    if (this.tabId != null) {
      await overlayTab(this.tabId, text);
    }
  }

  async scrollLoad(times = 12): Promise<void> {
    if (this.tabId != null) {
      await scrollLoad(this.tabId, times);
    }
  }

  async close(): Promise<void> {
    if (this.safety) {
      clearTimeout(this.safety);
      this.safety = null;
    }
    if (this.tabId != null) {
      await closeTab(this.tabId);
    }
    this.tabId = null;
  }
}

// Counted, not a flag: crawls overlap, and one finishing used to turn visible
// crawling off while another that needed it was still running.
let visibleCrawls = 0;

export function setVisibilityCrawling(value: boolean): void {
  visibleCrawls = Math.max(0, visibleCrawls + (value ? 1 : -1));
}

function visibilityCrawling(): boolean {
  return visibleCrawls > 0;
}

export async function openSession(origin: string, active = false, popup = visibilityCrawling()): Promise<TabController | null> {
  const tab = new TabController();
  if (!await tab.launch(active, popup)) {
    return null;
  }
  await tab.navigate(origin);
  await tab.settle();
  return tab;
}
