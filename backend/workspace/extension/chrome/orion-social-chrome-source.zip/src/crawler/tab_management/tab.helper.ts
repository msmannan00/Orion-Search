interface TabRuntimeApi {
  runtime?: {
    sendMessage?(message: unknown, callback: (response: unknown) => void): void;
    lastError?: unknown;
  };
}

const TAB_API = ((globalThis as { chrome?: TabRuntimeApi }).chrome ?? (globalThis as { browser?: TabRuntimeApi }).browser) as TabRuntimeApi | undefined;

export interface TabHandle {
  tabId: number;
}

const SEND_TIMEOUT_MS = 60_000;

interface BackgroundScope {
  tabOpen?(active: boolean, popup: boolean): Promise<any>;
  tabClose?(tabId: number): Promise<any>;
  tabRun?(tabId: number, action: string, value?: string): Promise<any>;
}

function backgroundScope(): BackgroundScope | null {
  try {
    const parent = globalThis.parent as unknown as BackgroundScope | undefined;
    if (!parent || (parent as unknown) === globalThis) {
      return null;
    }
    return typeof parent.tabOpen === 'function' ? parent : null;
  }
  catch {
    return null;
  }
}

function direct(message: Record<string, unknown>): Promise<any> | null {
  const scope = backgroundScope();
  if (!scope) {
    return null;
  }
  if (message['type'] === 'orion-tab-open') {
    return scope.tabOpen!(message['active'] === true, message['popup'] === true);
  }
  if (message['type'] === 'orion-tab-close') {
    return scope.tabClose!(message['tabId'] as number);
  }
  if (message['type'] === 'orion-tab-run') {
    return scope.tabRun!(message['tabId'] as number, message['action'] as string, message['value'] as string | undefined);
  }
  return null;
}

function send(message: Record<string, unknown>): Promise<any> {
  const local = direct(message);
  if (local) {
    return local.then((response) => response ?? null, () => null);
  }

  return new Promise((resolve) => {
    const runtime = TAB_API?.runtime;
    if (!runtime?.sendMessage) {
      resolve(null);
      return;
    }
    let timer: ReturnType<typeof setTimeout> | null = null;
    let settled = false;
    const finish = (response: unknown) => {
      if (settled) {
        return;
      }
      settled = true;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      resolve(response ?? null);
    };
    timer = setTimeout(() => finish(null), SEND_TIMEOUT_MS);
    runtime.sendMessage(message, (response) => {
      void runtime.lastError;
      finish(response);
    });
  });
}

function run(tabId: number, action: string, value?: string): Promise<any> {
  return send({ type: 'orion-tab-run', tabId, action, value });
}

export function openTab(active = false, popup = false): Promise<TabHandle | null> {
  return send({ type: 'orion-tab-open', active, popup });
}

export async function overlayTab(tabId: number, text: string): Promise<void> {
  await run(tabId, 'overlay', text);
}

export async function closeTab(tabId: number): Promise<void> {
  await send({ type: 'orion-tab-close', tabId });
}

export async function navigate(tabId: number, url: string): Promise<string> {
  const response = await run(tabId, 'navigate', url);
  return response?.url ?? '';
}

export async function getHtml(tabId: number): Promise<string> {
  const response = await run(tabId, 'html');
  return response?.html ?? '';
}

export async function scrollLoad(tabId: number, times = 12): Promise<void> {
  await run(tabId, 'scrollLoad', String(times));
}

export interface TabFetchResult {
  ok: boolean;
  status: number;
  body: string;
  headers?: Record<string, string>;
}

export interface TabFetchOptions {
  headers?: Record<string, string>;
  method?: string;
  body?: string;
}

export interface TabQueryItem {
  href: string;
  alt: string;
  text: string;
  testid: string;
  src: string;
}

export interface TabCollectItem {
  href: string;
  alt: string;
  text: string;
  src: string;
}

export async function scrollCollectTab(tabId: number, selector: string, steps = 40): Promise<TabCollectItem[]> {
  const response = await run(tabId, 'scrollCollect', JSON.stringify({ selector, steps }));
  return Array.isArray(response?.items) ? response.items : [];
}

export async function queryTab(tabId: number, selector: string): Promise<TabQueryItem[]> {
  const response = await run(tabId, 'query', selector);
  return Array.isArray(response?.items) ? response.items : [];
}

export async function getCookies(tabId: number): Promise<string> {
  const response = await run(tabId, 'cookie');
  return response?.cookie ?? '';
}

export async function fetchInTab(tabId: number, url: string, options?: TabFetchOptions): Promise<TabFetchResult> {
  const response = await run(tabId, 'fetch', JSON.stringify({ url, headers: options?.headers ?? {}, method: options?.method ?? 'GET', body: options?.body ?? null }));
  return response ?? { ok: false, status: 0, body: '' };
}
