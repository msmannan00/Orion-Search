import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { images, videos } from './resource/vsco/vsco';
import { openSession } from './tab_management/tab.controller';

export class VSCO implements Crawler {
  readonly platform = 'vsco';
  readonly base = 'https://vsco.co';
  readonly loginUrl = 'https://vsco.co/user/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'images':
        return images(payload);
      case 'videos':
        return videos(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    const tab = await openSession('https://vsco.co/');
    if (!tab) {
      return [];
    }
    try {
      const api = await tab.fetch(`https://vsco.co/api/2.0/sites?subdomain=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json', Authorization: 'Bearer 7356455548d0a1d886db010883388d08be84d0c9' } });
      if (api.ok) {
        const payload = JSON.parse(api.body);
        const site = Array.isArray(payload?.sites) ? payload.sites[0] : null;
        if (site?.id) {
          return [{
            real_name: site.name || site.subdomain || username,
            bio: site.description ?? '',
            description: site.description ?? '',
            location: '',
            profile_url: `https://vsco.co/${site.subdomain ?? username}/gallery`,
            total_posts: '',
            total_followers: '',
            total_likes: '',
            avatar: site.profile_image ? `https://${String(site.profile_image).replace(/^https?:\/\//, '')}` : '',
            banner: site.responsive_url ? `https://${String(site.responsive_url).replace(/^https?:\/\//, '')}` : '',
            crawl_type: ['details', 'images', 'videos'],
            platform: this.platform,
            username: site.subdomain ?? username,
            site_id: site.id ?? 0,
            user_id: site.user_id ?? 0,
            name: site.name ?? '',
            subdomain: site.subdomain ?? '',
            domain: site.domain ?? '',
            site_title: site.site_title ?? '',
            external_link: site.externalLink ?? '',
            external_link_text: site.externalLinkDisplayText ?? '',
            share_link: String(site.share_link ?? '').replace(/^http:/, 'https:'),
            collection_share_link: site.collection_share_link ?? '',
            grid_album_id: site.grid_album_id ?? '',
            site_collection_id: site.site_collection_id ?? '',
            profile_image_id: site.profile_image_id ?? '',
            recently_published: site.recently_published ? `https://${String(site.recently_published).replace(/^https?:\/\//, '')}` : '',
            has_article: site.has_article ?? false,
            has_collection: site.has_collection ?? false,
            is_brand: site.is_brand ?? false,
            is_internal: site.internal_site ?? false,
            is_museum: site.museum ?? false,
            status: site.status ?? '',
            site_type: site.type ?? 0,
            profile_visibility: site.profile_visibility ?? 0,
            is_password_protected: Boolean(site.password),
          }];
        }
      }

      const response = await tab.fetch(`https://vsco.co/${encodeURIComponent(username)}/gallery`);
      if (!response.ok) {
        return [];
      }
      const html = response.body;
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');

      const displayName = (meta('og:title') || decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '')).replace(/\s*\|\s*VSCO$/i, '').trim();
      if (!displayName || /^VSCO$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://vsco.co/${username}/gallery`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'images', 'videos'],
        platform: this.platform,
        username: username,
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://vsco.co/api/2.0/users/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.id);
    }
    catch {
      return false;
    }
  }
}
