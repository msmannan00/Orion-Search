import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, connections, posts, shorts, streams, videos } from './resource/youtube/youtube';

export class YouTube implements Crawler {
  readonly platform = 'youtube';
  readonly base = 'https://www.youtube.com';
  readonly loginUrl = 'https://accounts.google.com/ServiceLogin?service=youtube';
  readonly authwall = NO_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    signedIn: ['#avatar-btn', 'ytd-topbar-menu-button-renderer #avatar-btn', 'button#avatar-btn'],
    signedOut: ['a[href*="accounts.google.com/ServiceLogin"]', 'ytd-button-renderer a[href*="ServiceLogin"]'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'videos':
        return videos(payload);
      case 'shorts':
        return shorts(payload);
      case 'streams':
        return streams(payload);
      case 'albums':
        return albums(payload);
      case 'posts':
        return posts(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const handle = username.startsWith('@') ? username : `@${username}`;
      const profileUrl = `https://www.youtube.com/${handle}`;
      const response = await fetch(`${profileUrl}/about`, { redirect: 'follow', headers: { 'Accept-Language': 'en' } });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const start = html.indexOf('"channelMetadataRenderer":{');
      const block = start < 0 ? html : html.slice(start, start + 4000);
      const field = (source: string, key: string): string => {
        const found = new RegExp(`"${key}":"((?:[^"\\\\]|\\\\.)*)"`).exec(source);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const meta = (key: string): string => (new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? '').replace(/\s+/g, ' ').trim();
      const raw = (re: RegExp): string => (re.exec(html)?.[1] ?? '').trim();
      const title = field(block, 'title') || meta('og:title');
      if (!title) {
        return [];
      }

      const scale: Record<string, number> = { K: 1e3, M: 1e6, B: 1e9 };
      const toCount = (text: string): number => {
        const found = /([\d.,]+)\s*([KMB]?)/i.exec(text ?? '');
        return found ? Math.round(Number(found[1].replace(/,/g, '')) * (scale[found[2].toUpperCase()] ?? 1)) : 0;
      };
      const subsText = raw(/"subscriberCountText":"([^"]+)"/) || raw(/([\d.,]+\s*[KMB]?)\s*subscribers/i);
      const videosText = raw(/"videoCountText":"([^"]+)"/) || raw(/([\d.,]+)\s*videos/i);
      const viewsText = raw(/"viewCountText":"([^"]+)"/);
      const joined = raw(/"joinedDateText":\{"content":"([^"]+)"/) || raw(/Joined ([A-Z][a-z]+ \d+, \d{4})/);
      const links = [...html.matchAll(/"channelExternalLinkViewModel":\{"title":\{"content":"([^"]+)"\},"link":\{"content":"([^"]+)"/g)].map((m) => `${m[1]}: ${m[2]}`);

      return [{
        real_name: title,
        bio: field(block, 'description') || meta('og:description'),
        description: field(block, 'description') || meta('og:description'),
        location: raw(/"country":"([^"]+)"/),
        profile_url: field(block, 'vanityChannelUrl') || raw(/"canonicalChannelUrl":"([^"]+)"/) || profileUrl,
        total_posts: String(toCount(videosText) || ''),
        total_followers: String(toCount(subsText) || ''),
        total_likes: '',
        avatar: meta('og:image'),
        banner: [...html.matchAll(/https:\/\/yt3\.googleusercontent\.com\/[^"\\]+?=w(\d+)-fcrop64=[^"\\]+/g)].sort((a, b) => Number(b[1]) - Number(a[1]))[0]?.[0] ?? '',
        crawl_type: ['details', 'videos', 'shorts', 'streams', 'albums', 'posts', 'connections'],
        platform: this.platform,
        username: handle.replace(/^@/, ''),
        channel_id: field(block, 'externalId'),
        vanity_url: field(block, 'vanityChannelUrl'),
        subscribers: toCount(subsText),
        subscribers_text: subsText,
        video_count: toCount(videosText),
        total_views: Number((viewsText.match(/[\d,]+/)?.[0] ?? '0').replace(/,/g, '')) || 0,
        total_views_text: viewsText,
        joined_date: joined,
        country: raw(/"country":"([^"]+)"/),
        keywords: field(block, 'keywords'),
        links: links.join(' | '),
        links_count: links.length,
        rss_url: field(block, 'rssUrl'),
        family_safe: /"isFamilySafe":true/.test(html),
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const account = await tab.fetch('https://www.youtube.com/account');
    if (!account.ok || !/"LOGGED_IN"\s*:\s*true/.test(account.body)) {
      return NO_IDENTITY;
    }
    const switcher = await tab.fetch('https://www.youtube.com/getAccountSwitcherEndpoint');
    const source = (switcher.ok ? switcher.body : '') || account.body;
    const handle = (source.match(/(@[A-Za-z0-9._-]{3,40})/) || [])[1] || '';
    const email = (account.body.match(/([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/) || [])[1] || '';
    return { loggedIn: true, username: handle ? handle.replace(/^@/, '') : email };
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.youtube.com/account', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/accounts\.google\.com|ServiceLogin/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
