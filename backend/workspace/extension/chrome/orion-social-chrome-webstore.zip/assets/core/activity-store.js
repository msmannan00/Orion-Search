'use strict';

const ACTIVITY_LIMIT = 40;

const ACTIVITY_KEY = 'orion_activity';

async function readActivity() {
  try {
    const data = await api.storage.local.get(ACTIVITY_KEY);
    return Array.isArray(data[ACTIVITY_KEY]) ? data[ACTIVITY_KEY].slice(0, ACTIVITY_LIMIT) : [];
  }
  catch (error) {
    void error;
    return [];
  }
}

function activityIdentity(entry) {
  return entry.id ?? `${entry.platform || ''}|${entry.url || ''}|${entry.startedAt}`;
}

async function writeActivity(entry) {
  const items = await readActivity();
  const identity = activityIdentity(entry);
  const index = items.findIndex((item) => activityIdentity(item) === identity);
  if (index >= 0) {
    items[index] = entry;
  }
  else {
    items.unshift(entry);
  }
  try {
    await api.storage.local.set({ [ACTIVITY_KEY]: items.slice(0, ACTIVITY_LIMIT) });
  }
  catch (error) {
    void error;
  }
}

let activityWrites = Promise.resolve();

function recordActivity(entry) {
  activityWrites = activityWrites.then(() => writeActivity(entry)).catch((error) => void error);
  return activityWrites;
}

globalThis['recordActivity'] = recordActivity;
