'use strict';

const ORION_URL_KEY = 'orion-url';
const ORION_TOKEN_KEY = 'orion-token';

async function authHeaders(initialHeaders) {
  const headers = new Headers(initialHeaders);
  const saved = await api.storage.local.get(ORION_TOKEN_KEY);
  const token = saved[ORION_TOKEN_KEY];
  if (typeof token === 'string' && token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  return headers;
}

async function request(endpoint, options) {
  const saved = await api.storage.local.get(ORION_URL_KEY);
  const origin = saved[ORION_URL_KEY];
  if (!origin) {
    return null;
  }

  try {
    const headers = await authHeaders(options && options.headers);
    const response = await fetch(`${origin}/api/extension/${endpoint}`, { credentials: 'include', cache: 'no-store', ...options, headers });
    return response.ok ? origin : null;
  }
  catch (error) {
    void error;
    return null;
  }
}

async function wsTicket() {
  const saved = await api.storage.local.get(ORION_URL_KEY);
  const origin = saved[ORION_URL_KEY];
  if (!origin) {
    return null;
  }

  try {
    const response = await fetch(`${origin}/api/extension/ws-ticket`, { method: 'POST', credentials: 'include', cache: 'no-store', headers: await authHeaders() });
    if (!response.ok) {
      return null;
    }
    const body = await response.json();
    return body && typeof body.ticket === 'string' ? body.ticket : null;
  }
  catch (error) {
    void error;
    return null;
  }
}

globalThis['request'] = request;
globalThis['wsTicket'] = wsTicket;
