'use strict';

async function defaultStoreId() {
  try {
    const stores = await api.cookies['getAllCookieStores']();
    return stores && stores.length ? stores[0].id : '0';
  }
  catch (error) {
    void error;
    return '0';
  }
}

// A collector that needs a login reads it from the browser it runs in. Seeding
// an attached session first is what lets a signed-in crawl return more than the
// signed-out one, without the collector knowing a session was involved.
async function applySession(session) {
  const cookies = session && Array.isArray(session.cookies) ? session.cookies : [];
  if (!cookies.length) {
    return;
  }
  await seedCookies(await defaultStoreId(), cookies);
}

async function crawl(command) {
  console.info('[orion] crawl start', command.platform, command.crawl_type, command.url || command.username);
  if (command.session) {
    await applySession(command.session);
  }
  const entry = { platform: command.platform || '', url: command.url || '', status: 'crawling', startedAt: Date.now(), finishedAt: null };
  await recordActivity(entry);

  let items = [];
  if (command.url || command.username) {
    const response = await runInRunner(command);
    items = response && Array.isArray(response.items) ? response.items : [];
    entry.status = response ? (items.length ? 'done' : 'empty') : 'failed';
    entry.error = response?.error || (response ? '' : 'runner_unreachable');
  }
  else {
    entry.status = 'failed';
  }

  entry.finishedAt = Date.now();
  await recordActivity(entry);
  return { platform: command.platform, url: command.url, implemented: items.length > 0, items, error: entry.error || '' };
}

globalThis['crawl'] = crawl;
