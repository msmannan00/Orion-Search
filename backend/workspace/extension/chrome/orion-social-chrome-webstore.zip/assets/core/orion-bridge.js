(() => {
  'use strict';

  if (window.__orionBridgeLoaded) { return; }
  window.__orionBridgeLoaded = true;

  const api = globalThis['browser'] || globalThis['chrome'];
  const runtime = api?.runtime;
  const storage = api?.storage?.local;
  const markInstalled = () => document.documentElement?.setAttribute('data-orion-extension', 'installed');
  markInstalled();
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', markInstalled, { once: true }); }
  const version = () => {
    try {
      return runtime?.getManifest?.().version ?? '';
    }
    catch (error) {
      void error;
      return '';
    }
  };
  let lastPresence = null;
  const emit = (loggedIn, connected) => {
    lastPresence = { loggedIn, connected };
    markInstalled();
    window.postMessage({ source: 'orion-extension', type: 'presence', loggedIn, connected, version: version() }, window.location.origin);
  };
  const socketOpen = async () => {
    try {
      const v = await storage.get('orion-socket');
      return v['orion-socket']?.state === 'open';
    }
    catch (error) {
      void error;
      return false;
    }
  };
  const isLocal = (url) => /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|$)/i.test(url || '');
  const register = async () => {
    const origin = window.location.origin;
    const saved = await storage.get(['orion-url', 'orion-urls']);
    const urls = Array.isArray(saved['orion-urls']) ? saved['orion-urls'].filter(url => typeof url === 'string') : [];
    const selected = typeof saved['orion-url'] === 'string' ? saved['orion-url'] : '';
    const known = urls.includes(origin);

    const preferred = !selected || (isLocal(selected) && !isLocal(origin)) ? origin
      : urls.includes(selected) ? selected
        : urls.find(url => !isLocal(url)) || origin;

    if (known && preferred === selected) {
      return;
    }
    if (!known) {
      urls.push(origin);
    }
    console.warn('[orion] register: origin=' + origin + ' selected=' + selected + ' -> preferred=' + preferred);
    await storage.set({ 'orion-urls': urls, 'orion-url': preferred });
  };
  let keepAlivePort = null;
  const keepAlive = () => {
    if (keepAlivePort) {
      return;
    }
    keepAlivePort = runtime?.connect({ name: 'orion-keepalive' }) ?? null;
    keepAlivePort?.onDisconnect?.addListener(() => {
      keepAlivePort = null;
      setTimeout(keepAlive, 1000);
    });
  };
  const report = () => Promise.resolve(register()).catch(() => undefined)
    .then(() => Promise.all([Promise.resolve(runtime?.sendMessage({ type: 'orion-status' })).catch(() => null), socketOpen()]))
    .then(([response, socketOpen]) => {
      const loggedIn = Boolean(response?.loggedIn);
      emit(loggedIn, socketOpen && loggedIn);
    }, () => emit(false, false));

  window.addEventListener('message', (event) => {
    const { source, type, platform, url, username, crawl_type, session } = event.data ?? {};
    if (event['source'] !== window || source !== 'orion-app') {
      return;
    }
    if (type === 'ping') {
      keepAlive();
      if (lastPresence && lastPresence.loggedIn && lastPresence.connected) {
        emit(true, true);
      }
      void report();
    }
    else if (type === 'open') {
      runtime?.sendMessage({ type: 'orion-open' });
    }
    else if (type === 'crawl') {
      Promise.resolve(runtime?.sendMessage({ type: 'orion-crawl', platform, url, username, crawl_type, session }))
        .then((result) => window.postMessage({ source: 'orion-extension', type: 'crawl-result', platform: platform ?? '', crawl_type: crawl_type ?? '', items: result?.items ?? [], error: result?.error ?? '' }, window.location.origin),
          (error) => window.postMessage({ source: 'orion-extension', type: 'crawl-result', platform: platform ?? '', crawl_type: crawl_type ?? '', items: [], error: String(error?.message ?? error ?? 'crawl failed') }, window.location.origin));
    }
    else if (type === 'session') {
      Promise.resolve(runtime?.sendMessage({ type: 'orion-session', url, payload: session ? { seed: session } : undefined }))
        .then((result) => window.postMessage({ source: 'orion-extension', type: 'session-result', ok: Boolean(result), platform: platform ?? '', url: url ?? '', username: result?.username ?? '', captured: result ?? null }, window.location.origin),
          () => window.postMessage({ source: 'orion-extension', type: 'session-result', ok: false, platform: platform ?? '', url: url ?? '', username: '', captured: null }, window.location.origin));
    }
  });
})();
