'use strict';

const api = globalThis['browser'] || globalThis['chrome'];
const REFRESH_ALARM = 'orion-token-refresh';
const RUNNER_ALARM = 'orion-runner';
const BRIDGE_SCRIPT_ID = 'orion-bridge';
const BRIDGE_SCRIPT = 'assets/core/orion-bridge.js';
const HOST_ACCESS = { origins: ['<all_urls>'] };

const sessionPending = new Map();
let sessionWindowId = null;

if (typeof importScripts === 'function') {
  importScripts(
    '../tab/tab-service.js',
    'activity-store.js',
    'backend.js',
    'runner.js',
    'crawl.js',
    'cookies.js',
    'session-capture.js',
    'verify.js',
    'capture-page.js',
    'routes.js'
  );
  start();
}
else {
  globalThis.addEventListener('DOMContentLoaded', start, { once: true });
}

function start() {
  api.runtime.onConnect.addListener((port) => void port);

  api.permissions.onAdded.addListener(() => void ensureBridge());

  void ensureBridge();

  api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[ORION_URL_KEY]) {
      if (changes[ORION_URL_KEY]['oldValue'] === changes[ORION_URL_KEY]['newValue']) {
        return;
      }
      console.warn('[orion] orion-url changed:', changes[ORION_URL_KEY]['oldValue'], '->', changes[ORION_URL_KEY]['newValue']);
      void resetRunner();
    }
  });

  api.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === REFRESH_ALARM) {
      void request('refresh', { method: 'POST' });
    }
    void ensureRunner();
  });

  void api.alarms.create(REFRESH_ALARM, { periodInMinutes: 10 });

  void api.alarms.create(RUNNER_ALARM, { periodInMinutes: 1 });

  void request('refresh', { method: 'POST' });

  void ensureRunner();

  api.runtime['onStartup']?.addListener(() => void ensureRunner());

  api.runtime['onInstalled']?.addListener((details) => {
    void ensureRunner();
    if (details?.reason === 'install') {
      void openSetup();
    }
  });

  api.windows['onRemoved'].addListener((windowId) => {
    if (windowId !== sessionWindowId) {
      return;
    }
    sessionWindowId = null;
    for (const [tabId, entry] of Array.from(sessionPending)) {
      sessionPending.delete(tabId);
      if (entry.onReady) {
        api.tabs['onUpdated'].removeListener(entry.onReady);
      }
      entry.sendResponse(null);
    }
  });
}

async function ensureBridge() {
  try {
    const declared = (api.runtime.getManifest()['content_scripts'] || []).some((script) => (script.js || []).some((entry) => String(entry).endsWith(BRIDGE_SCRIPT)));
    if (declared || !(await api.permissions.contains(HOST_ACCESS))) {
      return;
    }
    const registered = await api.scripting.getRegisteredContentScripts({ ids: [BRIDGE_SCRIPT_ID] });
    if (registered.length) {
      return;
    }
    await api.scripting.registerContentScripts([{
      id: BRIDGE_SCRIPT_ID,
      js: [BRIDGE_SCRIPT],
      matches: ['<all_urls>'],
      runAt: 'document_start',
      persistAcrossSessions: true
    }]);
    await injectBridgeIntoOpenTabs();
  }
  catch (error) {
    void error;
  }
}

// Registering the script only covers pages loaded from now on. A tab that was
// already open -- the dashboard the user is looking at -- would keep posting to
// a bridge that is not there and every crawl would hang with nothing to say.
async function injectBridgeIntoOpenTabs() {
  try {
    const tabs = await api.tabs.query({ url: ['http://*/*', 'https://*/*'] });
    for (const tab of tabs || []) {
      if (typeof tab.id !== 'number') {
        continue;
      }
      try {
        await api.scripting.executeScript({ target: { tabId: tab.id }, files: [BRIDGE_SCRIPT] });
      }
      catch (error) {
        void error;
      }
    }
  }
  catch (error) {
    void error;
  }
}

async function openSetup() {
  try {
    if (await api.permissions.contains(HOST_ACCESS)) {
      return;
    }
    await api.tabs.create({ url: api.runtime.getURL('index.html') });
  }
  catch (error) {
    void error;
  }
}
