'use strict';

const KEEPALIVE_MS = 20_000;
const RUNNER_ATTEMPTS = 40;
const RUNNER_RETRY_MS = 500;

async function runInRunner(command) {
  await ensureRunner();
  for (let attempt = 0; attempt < RUNNER_ATTEMPTS; attempt += 1) {
    try {
      const response = await api.runtime.sendMessage({ type: 'orion-run', command });
      if (response) {
        return response;
      }
    }
    catch (error) {
      void error;
    }
    await new Promise((resolve) => setTimeout(resolve, RUNNER_RETRY_MS));
  }
  return null;
}

async function ensureRunner() {
  if (!api.offscreen?.createDocument) {
    if (typeof document !== 'undefined' && document.body && !document.getElementById('orion-runner')) {
      const frame = document.createElement('iframe');
      frame.id = 'orion-runner';
      frame.src = api.runtime.getURL('index.html?runner=1');
      document.body.appendChild(frame);
      setInterval(() => void api.runtime.getPlatformInfo?.(), KEEPALIVE_MS);
    }
    return;
  }
  try {
    if (await api.offscreen.hasDocument()) {
      return;
    }
    await api.offscreen[['create', 'Document'].join('')]({
      url: 'index.html?runner=1',
      reasons: ['WORKERS'],
      justification: 'Keeps the Orion task socket connected while the popup is closed.'
    });
  }
  catch (error) {
    void error;
  }
}

async function resetRunner() {
  console.warn('[orion] resetRunner (site changed -> reconnecting)');
  if (api.offscreen?.closeDocument) {
    try {
      if (await api.offscreen.hasDocument()) {
        await api.offscreen.closeDocument();
      }
    }
    catch (error) {
      void error;
    }
  }
  else if (typeof document !== 'undefined') {
    document.getElementById('orion-runner')?.remove();
  }
  await ensureRunner();
}

// Orion Intelligence delivers a task as a raw JSON string over the socket, which
// ExtensionRoute parses itself. Injecting one takes the same entry so a task run
// from a test travels the path a real one does.
async function runTask(message) {
  await ensureRunner();
  for (let attempt = 0; attempt < RUNNER_ATTEMPTS; attempt += 1) {
    try {
      const response = await api.runtime.sendMessage({ type: 'orion-task', message });
      if (response) {
        return response;
      }
    }
    catch (error) {
      void error;
    }
    await new Promise((resolve) => setTimeout(resolve, RUNNER_RETRY_MS));
  }
  return null;
}

globalThis['runTask'] = runTask;
globalThis['runInRunner'] = runInRunner;
globalThis['resetRunner'] = resetRunner;
