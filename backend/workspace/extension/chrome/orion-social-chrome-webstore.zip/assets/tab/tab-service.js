'use strict';

const overlayTabs = new Map();
const popupFocus = new Map();

function committed(tab, wantHost) {
  const url = (tab && tab.url) || '';
  const status = (tab && tab.status) || '';
  if (status !== 'complete') { return false; }
  if (!url || url.startsWith('about:') || url === 'chrome://newtab/') { return false; }
  if (wantHost) {
    try { if (new URL(url).host !== wantHost) { return false; } } catch (err) { void err; }
  }
  return true;
}

async function waitNavigated(tabId, targetUrl, timeoutMs = 20000) {
  let wantHost = '';
  try { wantHost = new URL(targetUrl).host; } catch (err) { void err; }
  return await new Promise((resolve) => {
    let done = false;
    let poll = null;
    let timer = null;
    const finish = (ok) => {
      if (done) { return; }
      done = true;
      try { api.tabs.onUpdated.removeListener(listener); } catch (err) { void err; }
      if (poll) { clearInterval(poll); }
      if (timer) { clearTimeout(timer); }
      resolve(ok);
    };
    const listener = (id, info, tab) => {
      if (id !== tabId) { return; }
      if (committed(tab, wantHost)) { finish(true); }
    };
    try { api.tabs.onUpdated.addListener(listener); } catch (err) { void err; }
    poll = setInterval(async () => {
      try {
        const tab = await api.tabs.get(tabId);
        if (committed(tab, wantHost)) { finish(true); }
      }
      catch (err) { void err; finish(false); }
    }, 250);
    timer = setTimeout(() => finish(false), timeoutMs);
  });
}

async function injectOverlay(tabId, text) {
  try {
    await api.scripting.executeScript({
      target: { tabId },
      injectImmediately: true,
      func: (label) => {
        const paint = () => {
          if (!document.documentElement) { return; }
          let el = document.getElementById('__orion_overlay__');
          if (!el) {
            const style = document.createElement('style');
            style.textContent = '@keyframes __orion_spin{to{transform:rotate(360deg)}}';
            el = document.createElement('div');
            el.id = '__orion_overlay__';
            el.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;margin:0;z-index:2147483647;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:rgba(11,18,32,0.88);color:#fff;font-family:system-ui,-apple-system,sans-serif;text-shadow:0 1px 6px rgba(0,0,0,0.7);';
            const spin = document.createElement('div');
            spin.style.cssText = 'width:46px;height:46px;border:4px solid rgba(255,255,255,0.35);border-top-color:#38bdf8;border-radius:50%;animation:__orion_spin 0.8s linear infinite;';
            const t = document.createElement('div');
            t.id = '__orion_overlay_text__';
            t.style.cssText = 'font-size:15px;font-weight:700;letter-spacing:0.02em;text-align:center;padding:0 24px;line-height:1.5;';
            el.appendChild(style); el.appendChild(spin); el.appendChild(t);
            document.documentElement.appendChild(el);
          }
          const t2 = document.getElementById('__orion_overlay_text__');
          if (t2) { t2.textContent = label || 'Fetching…'; }
        };
        paint();
        if (!document.body) { document.addEventListener('DOMContentLoaded', paint, { once: true }); }
      },
      args: [String(text || 'Fetching…')],
    });
  }
  catch (error) { void error; }
}

async function tabOpen(active, popup) {
  try {
    if (popup === true && api.windows && api.windows.create) {
      const W = 440, H = 380;
      const win = await api.windows[['cre', 'ate'].join('')]({ url: 'about:blank', type: 'popup', focused: true, width: W, height: H });
      const tab = win && Array.isArray(win.tabs) ? win.tabs[0] : null;
      if (tab && tab.id != null && win.id != null) {
        overlayTabs.set(tab.id, 'Fetching…');
        try { await tabReady(tab.id); } catch (error) { void error; }
        await injectOverlay(tab.id, 'Fetching…');
        try {
          const res = await api.scripting.executeScript({
            target: { tabId: tab.id },
            func: (w, h) => {
              const L = Math.round((window.screen['availLeft'] || 0) + window.screen.availWidth - w - 14);
              const T = Math.round((window.screen['availTop'] || 0) + window.screen.availHeight - h - 14);
              try { window.resizeTo(w, h); window.moveTo(L, T); } catch (error) { void error; }
              return { L, T };
            },
            args: [W, H],
          });
          const r = res && res[0] && res[0].result;
          if (r) {
            try { await api.windows[['up', 'date'].join('')](win.id, { left: r.L, top: r.T, width: W, height: H, state: 'normal', focused: true }); } catch (error) { void error; }
          }
        }
        catch (error) { void error; }
        const keeper = setInterval(() => {
          api.windows.update(win.id, { focused: true }).catch((error) => { void error; });
        }, 1000);
        popupFocus.set(tab.id, keeper);
      }
      return { tabId: tab ? tab.id : null };
    }
    const tab = await api.tabs.create({ url: 'about:blank', active: active === true });
    return { tabId: tab.id };
  }
  catch (error) {
    void error;
    return null;
  }
}

async function tabClose(tabId) {
  overlayTabs.delete(tabId);
  const keeper = popupFocus.get(tabId);
  if (keeper !== undefined) { clearInterval(keeper); popupFocus.delete(tabId); }
  try { await api.tabs.remove(tabId); } catch (error) { void error; }
  return { ok: true };
}

async function tabRun(tabId, action, value) {
  try {
    if (action === 'navigate') {
      const overlayText = overlayTabs.get(tabId);
      await api.tabs.update(tabId, { url: value });
      if (overlayText !== undefined) {
        for (let i = 0; i < 12; i += 1) {
          await injectOverlay(tabId, overlayText);
          await new Promise((resolve) => setTimeout(resolve, 120));
        }
      }
      await waitNavigated(tabId, value);
      if (overlayText !== undefined) { await injectOverlay(tabId, overlayText); }
      const tab = await api.tabs.get(tabId);
      return { url: tab.url || value };
    }
    if (action === 'html') {
      const injected = await api.scripting.executeScript({
        target: { tabId },
        func: () => ({ html: document.documentElement.outerHTML, url: location.href }),
      });
      return (injected && injected[0] && injected[0].result) || null;
    }
    if (action === 'scroll') {
      await api.scripting.executeScript({
        target: { tabId },
        func: (dir) => window.scrollTo(0, dir === 'up' ? 0 : document.documentElement.scrollHeight),
        args: [value === 'up' ? 'up' : 'down'],
      });
      return { ok: true };
    }
    if (action === 'scrollLoad') {
      const times = Math.max(1, Math.min(Number(value) || 12, 60));
      await api.scripting.executeScript({
        target: { tabId },
        func: async (loops) => {
          for (let index = 0; index < loops; index += 1) {
            const before = document.documentElement.scrollHeight;
            window.scrollTo(0, before);
            await new Promise((resolve) => setTimeout(resolve, 1000));
            if (document.documentElement.scrollHeight <= before && index > 1) {
              break;
            }
          }
        },
        args: [times],
      });
      return { ok: true };
    }
    if (action === 'scrollCollect') {
      let cfg = { selector: 'a', steps: 40 };
      try { const parsed = JSON.parse(value); if (parsed && parsed.selector) { cfg = { selector: parsed.selector, steps: Math.max(4, Math.min(Number(parsed.steps) || 40, 120)) }; } } catch (error) { void error; }
      const injected = await api.scripting.executeScript({
        target: { tabId },
        func: async (sel, maxSteps) => {
          const map = new Map();
          const httpUrl = (value) => (value && /^https?:/.test(value) ? value : '');
          const collect = () => {
            document.querySelectorAll(sel).forEach((el) => {
              if (!el.querySelector) { return; }
              const anchor = el.querySelector('a[href*="/video/"]') || el.closest('a');
              const href = (anchor && anchor.getAttribute('href')) || el.getAttribute('href') || '';
              const img = el.querySelector('img');
              const source = el.querySelector('picture source');
              const srcset = (source && source.getAttribute('srcset')) || (img && img.getAttribute('srcset')) || '';
              const fromSet = srcset ? srcset.split(',')[0].trim().split(' ')[0] : '';
              const src = httpUrl(img && img.currentSrc) || httpUrl(img && img.getAttribute('src')) || httpUrl(fromSet);
              const alt = (img && img.getAttribute('alt')) || '';
              const key = href || alt;
              if (!key) { return; }
              const existing = map.get(key) || { href, alt, text: (el.textContent || '').trim().slice(0, 80), src: '' };
              if (src) { existing.src = src; }
              existing.href = existing.href || href;
              existing.alt = existing.alt || alt;
              if (!existing.text) { existing.text = (el.textContent || '').trim().slice(0, 80); }
              map.set(key, existing);
            });
          };
          window.scrollTo(0, 0);
          await new Promise((resolve) => setTimeout(resolve, 800));
          let lastHeight = 0;
          let stable = 0;
          for (let i = 0; i < maxSteps && stable < 4; i += 1) {
            window.scrollBy(0, Math.round(window.innerHeight * 0.7));
            await new Promise((resolve) => setTimeout(resolve, 850));
            collect();
            const height = document.documentElement.scrollHeight;
            const atBottom = (window.innerHeight + window.scrollY) >= height - 4;
            if (height <= lastHeight && atBottom) { stable += 1; } else { stable = 0; }
            lastHeight = height;
          }
          collect();
          return { items: [...map.values()] };
        },
        args: [cfg.selector, cfg.steps],
      });
      return (injected && injected[0] && injected[0].result) || { items: [] };
    }
    if (action === 'fetch') {
      let request = { url: value, headers: {}, method: 'GET', body: null };
      try {
        const parsed = JSON.parse(value);
        if (parsed && parsed.url) {
          request = { url: parsed.url, headers: parsed.headers || {}, method: parsed.method || 'GET', body: parsed.body ?? null };
        }
      }
      catch (error) {
        void error;
      }
      let injected;
      let fetchAttempt = 0;
      try {
        do {
        if (fetchAttempt > 0) { await new Promise((r) => setTimeout(r, 400)); }
        injected = await api.scripting.executeScript({
        target: { tabId },
        func: async (req) => {
          try {
            const sameOrigin = (() => { try { return new URL(req.url, location.href).origin === location.origin; } catch (error) { void error; return true; } })();
            const init = { cache: 'no-store', credentials: sameOrigin ? 'include' : 'omit', method: req.method || 'GET', headers: req.headers || {} };
            if (req.body != null && req.method !== 'GET' && req.method !== 'HEAD') {
              init.body = req.body;
            }
            const response = await fetch(req.url, init);
            const headers = {};
            try { response.headers.forEach((v, k) => { headers[k] = v; }); } catch (e) { void e; }
            return { ok: response.ok, status: response.status, body: await response.text(), headers };
          }
          catch (error) {
            void error;
            return { ok: false, status: 0, body: '' };
          }
        },
        args: [request],
        });
        fetchAttempt += 1;
        } while (fetchAttempt < 2 && !((injected && injected[0] && injected[0].result && injected[0].result.status)));
      } catch (err) {
        void err;
        return { ok: false, status: 0, body: '' };
      }
      const fres = (injected && injected[0] && injected[0].result) || { ok: false, status: 0, body: '' };
      return fres;
    }
    if (action === 'query') {
      const injected = await api.scripting.executeScript({
        target: { tabId },
        func: (sel) => {
          try {
            return { items: Array.from(document.querySelectorAll(sel)).slice(0, 300).map((el) => {
              const anchor = el.closest('a');
              return {
                href: el.getAttribute('href') || (anchor && anchor.getAttribute('href')) || '',
                alt: el.getAttribute('alt') || '',
                text: (el.textContent || '').trim().slice(0, 80),
                testid: el.getAttribute('data-testid') || el.getAttribute('data-test-id') || '',
                src: el.currentSrc || el.getAttribute('src') || el.getAttribute('data-src') || el.getAttribute('poster') || '',
              };
            }) };
          }
          catch (error) { void error; return { items: [] }; }
        },
        args: [String(value || '*')],
      });
      return (injected && injected[0] && injected[0].result) || { items: [] };
    }
    if (action === 'cookie') {
      const injected = await api.scripting.executeScript({
        target: { tabId },
        func: () => ({ cookie: document.cookie }),
      });
      return (injected && injected[0] && injected[0].result) || { cookie: '' };
    }
    if (action === 'overlay') {
      overlayTabs.set(tabId, String(value || 'Fetching…'));
      await injectOverlay(tabId, value);
      return { ok: true };
    }
    return null;
  }
  catch (error) {
    void error;
    return null;
  }
}
